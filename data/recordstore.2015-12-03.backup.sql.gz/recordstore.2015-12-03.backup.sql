--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO adminbpcfu4q;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO adminbpcfu4q;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO adminbpcfu4q;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO adminbpcfu4q;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO adminbpcfu4q;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO adminbpcfu4q;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE auth_user OWNER TO adminbpcfu4q;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE auth_user_groups OWNER TO adminbpcfu4q;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_groups_id_seq OWNER TO adminbpcfu4q;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_id_seq OWNER TO adminbpcfu4q;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_user_user_permissions OWNER TO adminbpcfu4q;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_user_permissions_id_seq OWNER TO adminbpcfu4q;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO adminbpcfu4q;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO adminbpcfu4q;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO adminbpcfu4q;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO adminbpcfu4q;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO adminbpcfu4q;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO adminbpcfu4q;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO adminbpcfu4q;

--
-- Name: recordstore_album; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE recordstore_album (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    num_songs integer NOT NULL,
    release_date date,
    rating integer NOT NULL,
    artist_id integer NOT NULL,
    genre_id character varying(255),
    musicbrainz_id character varying(255)
);


ALTER TABLE recordstore_album OWNER TO adminbpcfu4q;

--
-- Name: recordstore_album_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE recordstore_album_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE recordstore_album_id_seq OWNER TO adminbpcfu4q;

--
-- Name: recordstore_album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE recordstore_album_id_seq OWNED BY recordstore_album.id;


--
-- Name: recordstore_albumreview; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE recordstore_albumreview (
    id integer NOT NULL,
    text character varying(500) NOT NULL,
    date_written timestamp with time zone NOT NULL,
    album_id integer NOT NULL,
    author_id integer NOT NULL
);


ALTER TABLE recordstore_albumreview OWNER TO adminbpcfu4q;

--
-- Name: recordstore_albumreview_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE recordstore_albumreview_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE recordstore_albumreview_id_seq OWNER TO adminbpcfu4q;

--
-- Name: recordstore_albumreview_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE recordstore_albumreview_id_seq OWNED BY recordstore_albumreview.id;


--
-- Name: recordstore_artist; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE recordstore_artist (
    id integer NOT NULL,
    country character varying(255) NOT NULL,
    date_start date,
    date_end date,
    name character varying(255) NOT NULL,
    musicbrainz_id character varying(255)
);


ALTER TABLE recordstore_artist OWNER TO adminbpcfu4q;

--
-- Name: recordstore_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE recordstore_artist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE recordstore_artist_id_seq OWNER TO adminbpcfu4q;

--
-- Name: recordstore_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE recordstore_artist_id_seq OWNED BY recordstore_artist.id;


--
-- Name: recordstore_genre; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE recordstore_genre (
    name character varying(255) NOT NULL
);


ALTER TABLE recordstore_genre OWNER TO adminbpcfu4q;

--
-- Name: recordstore_ownedrecord; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE recordstore_ownedrecord (
    id integer NOT NULL,
    album_id integer NOT NULL,
    owner_id integer NOT NULL,
    pressing_id integer
);


ALTER TABLE recordstore_ownedrecord OWNER TO adminbpcfu4q;

--
-- Name: recordstore_ownedrecord_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE recordstore_ownedrecord_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE recordstore_ownedrecord_id_seq OWNER TO adminbpcfu4q;

--
-- Name: recordstore_ownedrecord_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE recordstore_ownedrecord_id_seq OWNED BY recordstore_ownedrecord.id;


--
-- Name: recordstore_pressing; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE recordstore_pressing (
    id integer NOT NULL,
    artwork character varying(100),
    version_number integer NOT NULL,
    release_format character varying(255) NOT NULL,
    album_id integer NOT NULL,
    label_id integer
);


ALTER TABLE recordstore_pressing OWNER TO adminbpcfu4q;

--
-- Name: recordstore_pressing_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE recordstore_pressing_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE recordstore_pressing_id_seq OWNER TO adminbpcfu4q;

--
-- Name: recordstore_pressing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE recordstore_pressing_id_seq OWNED BY recordstore_pressing.id;


--
-- Name: recordstore_recordlabel; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE recordstore_recordlabel (
    id integer NOT NULL,
    label_name character varying(255) NOT NULL,
    label_address character varying(255) NOT NULL,
    musicbrainz_id character varying(255) NOT NULL
);


ALTER TABLE recordstore_recordlabel OWNER TO adminbpcfu4q;

--
-- Name: recordstore_recordlabel_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE recordstore_recordlabel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE recordstore_recordlabel_id_seq OWNER TO adminbpcfu4q;

--
-- Name: recordstore_recordlabel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE recordstore_recordlabel_id_seq OWNED BY recordstore_recordlabel.id;


--
-- Name: recordstore_recordstoreuser; Type: TABLE; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE TABLE recordstore_recordstoreuser (
    id integer NOT NULL,
    django_user_id integer,
    profile_picture character varying(100)
);


ALTER TABLE recordstore_recordstoreuser OWNER TO adminbpcfu4q;

--
-- Name: recordstore_user_friends_id_seq; Type: SEQUENCE; Schema: public; Owner: adminbpcfu4q
--

CREATE SEQUENCE recordstore_user_friends_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE recordstore_user_friends_id_seq OWNER TO adminbpcfu4q;

--
-- Name: recordstore_user_friends_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: adminbpcfu4q
--

ALTER SEQUENCE recordstore_user_friends_id_seq OWNED BY recordstore_recordstoreuser.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_album ALTER COLUMN id SET DEFAULT nextval('recordstore_album_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_albumreview ALTER COLUMN id SET DEFAULT nextval('recordstore_albumreview_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_artist ALTER COLUMN id SET DEFAULT nextval('recordstore_artist_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_ownedrecord ALTER COLUMN id SET DEFAULT nextval('recordstore_ownedrecord_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_pressing ALTER COLUMN id SET DEFAULT nextval('recordstore_pressing_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_recordlabel ALTER COLUMN id SET DEFAULT nextval('recordstore_recordlabel_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_recordstoreuser ALTER COLUMN id SET DEFAULT nextval('recordstore_user_friends_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add genre	7	add_genre
20	Can change genre	7	change_genre
21	Can delete genre	7	delete_genre
22	Can add record label	8	add_recordlabel
23	Can change record label	8	change_recordlabel
24	Can delete record label	8	delete_recordlabel
25	Can add artist	9	add_artist
26	Can change artist	9	change_artist
27	Can delete artist	9	delete_artist
28	Can add album	10	add_album
29	Can change album	10	change_album
30	Can delete album	10	delete_album
31	Can add pressing	11	add_pressing
32	Can change pressing	11	change_pressing
33	Can delete pressing	11	delete_pressing
34	Can add record store user	12	add_recordstoreuser
35	Can change record store user	12	change_recordstoreuser
36	Can delete record store user	12	delete_recordstoreuser
37	Can add owned record	13	add_ownedrecord
38	Can change owned record	13	change_ownedrecord
39	Can delete owned record	13	delete_ownedrecord
40	Can add album review	14	add_albumreview
41	Can change album review	14	change_albumreview
42	Can delete album review	14	delete_albumreview
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('auth_permission_id_seq', 42, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
14	pbkdf2_sha256$20000$xwoTSiyenIGt$O1KrUWuAq5SF/O+7WQHwjRahvmSuq+Hj5ipr6+domw4=	2015-12-03 06:09:16.965071+00	f	bennett				f	t	2015-12-03 06:09:01.420874+00
13	pbkdf2_sha256$20000$qIogtSaO4skr$niwwdG2vC5BEGfTqgcp11MOpM+NtdWbS/YKq2uUjsBI=	2015-12-03 06:40:40.347789+00	f	Timothywong				f	t	2015-12-03 05:56:55.3258+00
15	pbkdf2_sha256$20000$M975Iltm5HwI$BkcFuhiVFgRkeh9E7f4/v0nSxFYEGz39DaQRiwFXHIU=	2015-12-03 07:52:43.814531+00	f	bennett2				f	t	2015-12-03 07:46:04.989028+00
12	pbkdf2_sha256$20000$BgwI9pYG2pwm$KBF8WCDBfVfgc8XA6E6I8rsysOpzKMNsa8NqdxGYH2o=	2015-12-03 06:00:16.98548+00	f	Alphanskaia	Francis	Ng		f	t	2015-12-03 04:03:35.387736+00
16	pbkdf2_sha256$20000$HnM4NxGfV8tZ$JonwwNjpTBs2ABka+rv5L9VWvQrJTW/CkTCfsSn9OcE=	2015-12-03 19:04:57.43684+00	f	demo_user				f	t	2015-12-03 19:04:38.270722+00
5	password	\N	f	username	user	name	fake@email.com	f	t	2015-12-01 20:13:22.015503+00
6	fake	\N	f	super	fake	super	fake@email.com	f	t	2015-12-01 20:14:05.087556+00
1	pbkdf2_sha256$20000$KmiYS9idpi3I$voDXpEMEdQjs/Op57jWObUnYMZgF+hjovgu9BviaBU4=	2015-12-03 19:16:25.743378+00	t	jlagrou2	Jacob	LaGrou	jlagrou2@illinois.edu	t	t	2015-11-30 21:47:47+00
7	pbkdf2_sha256$20000$XMkUAhbb2AVS$atG/OLL2WKIJ34uZ8gu0VU9ptxqYSgeoad1tZg3xRtc=	2015-12-01 20:18:40.579612+00	f	superfake	user	name		f	t	2015-12-01 20:18:28.814075+00
8	pbkdf2_sha256$20000$I67IquMmNJkt$v39PHzRdlrlTCbuYnmxm6aHQoaqRueNYMj5G01HcfyE=	2015-12-01 23:05:36.216823+00	f	sample	sample	sample		f	t	2015-12-01 23:05:28.940649+00
17	pbkdf2_sha256$20000$fXSoUo3AqWEj$Ytqu6n0BMYBdHjQHe/nDciCh74zF5Irg6D/kIoalymw=	2015-12-03 19:48:11.200579+00	f	bill	bill	nye		f	t	2015-12-03 19:47:59.467181+00
9	pbkdf2_sha256$20000$WBuc0uPAmJ8H$unJE1q96uiPsji/xukheSNJcrAQDtRABi7xLl6uFXVA=	\N	f	cs411				f	t	2015-12-02 00:26:46.378627+00
10	pbkdf2_sha256$20000$G65LgGtc2U5h$cXL/apRq8YTK88eue9eUofUQ4gCYKcGYn+ER5bC/KT0=	2015-12-02 17:48:55.217688+00	f	test	Abc			f	t	2015-12-02 04:16:41.451825+00
11	pbkdf2_sha256$20000$FlzUOKSbVESp$Gdo2JFCYn9C859S4tSQokk+X4Z8I38Er447eP2xcKs0=	2015-12-03 04:09:11.399579+00	f	francisng	Francis	Ng		f	t	2015-12-03 01:44:56.024464+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('auth_user_id_seq', 17, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2015-11-30 21:50:01.332145+00	3	jlagrou2	1		12	1
2	2015-11-30 21:56:36.660154+00	1	jlagrou2	2	Changed first_name and last_name.	4	1
3	2015-12-01 19:11:22.546046+00	1	Further Out	2	Deleted pressing "Further Out : Vinyl - 12 inch".	10	1
4	2015-12-01 19:49:33.702122+00	2	username	3		4	1
5	2015-12-01 19:55:07.694182+00	3	username	3		4	1
6	2015-12-01 19:56:20.557774+00	4	username	2	Changed password.	4	1
7	2015-12-01 20:13:05.074912+00	4	username	3		4	1
8	2015-12-01 20:40:54.687579+00	3	EMI	3		8	1
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 8, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	recordstore	genre
8	recordstore	recordlabel
9	recordstore	artist
10	recordstore	album
11	recordstore	pressing
12	recordstore	recordstoreuser
13	recordstore	ownedrecord
14	recordstore	albumreview
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('django_content_type_id_seq', 14, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2015-10-23 16:20:53.411759+00
2	auth	0001_initial	2015-10-23 16:20:55.268496+00
3	admin	0001_initial	2015-10-23 16:20:55.881176+00
4	contenttypes	0002_remove_content_type_name	2015-10-23 16:20:56.347361+00
5	auth	0002_alter_permission_name_max_length	2015-10-23 16:20:56.681077+00
6	auth	0003_alter_user_email_max_length	2015-10-23 16:20:57.019879+00
7	auth	0004_alter_user_username_opts	2015-10-23 16:20:57.221041+00
8	auth	0005_alter_user_last_login_null	2015-10-23 16:20:57.56221+00
9	auth	0006_require_contenttypes_0002	2015-10-23 16:20:57.754595+00
10	recordstore	0001_initial	2015-10-23 16:21:00.522585+00
11	sessions	0001_initial	2015-10-23 16:21:01.033938+00
12	recordstore	0002_auto_20151023_1758	2015-10-23 17:58:14.349365+00
13	recordstore	0003_auto_20151023_1954	2015-10-23 19:54:25.877967+00
14	recordstore	0003_auto_20151026_1847	2015-10-26 18:47:25.587435+00
15	recordstore	0004_auto_20151026_1946	2015-10-26 19:46:48.705142+00
16	recordstore	0005_merge	2015-10-28 16:26:50.601505+00
17	recordstore	0002_user_friends	2015-11-30 20:48:26.339836+00
19	recordstore	0002_remove_recordstoreuser_friends	2015-11-30 21:26:56.923576+00
20	recordstore	0003_recordstoreuser_friends	2015-11-30 21:27:49.110436+00
21	recordstore	0004_auto_20151130_2128	2015-11-30 21:29:09.611975+00
22	recordstore	0005_auto_20151130_2129	2015-11-30 21:29:37.03949+00
23	recordstore	0006_auto_20151130_2140	2015-11-30 21:40:20.440765+00
24	recordstore	0007_remove_recordstoreuser_friends	2015-11-30 21:42:00.436569+00
25	recordstore	0008_auto_20151130_2143	2015-11-30 21:43:21.154322+00
26	recordstore	0009_auto_20151130_2215	2015-11-30 22:16:03.463872+00
27	recordstore	0010_auto_20151130_2219	2015-11-30 22:19:43.680226+00
28	recordstore	0011_auto_20151130_2220	2015-11-30 22:20:49.378009+00
29	recordstore	0012_auto_20151130_2303	2015-11-30 23:03:30.132645+00
30	recordstore	0013_auto_20151201_2040	2015-12-01 20:40:59.65042+00
31	recordstore	0014_auto_20151201_2105	2015-12-01 21:05:57.286535+00
32	recordstore	0015_auto_20151202_1617	2015-12-02 16:17:53.125025+00
33	recordstore	0002_album_musicbrainz_id	2015-12-02 16:50:24.572683+00
34	recordstore	0003_recordlabel_musicbrainz_id	2015-12-02 21:05:39.733839+00
35	recordstore	0004_albumreview	2015-12-02 21:24:00.015111+00
36	recordstore	0005_auto_20151202_2252	2015-12-02 22:52:18.520112+00
37	recordstore	0006_auto_20151202_2259	2015-12-02 22:59:28.665639+00
38	recordstore	0007_auto_20151203_0639	2015-12-03 06:39:35.204919+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('django_migrations_id_seq', 38, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
kahhvvcx7rxg3ylb8kzw60i077pez8np	ZjQzYzc4NDk4YzNjMzM5MTZiMmUwZmExMzc0YWY3NTRjZGVhMDdhNTp7Il9hdXRoX3VzZXJfaGFzaCI6IjVjMzk4YzIxNWRhYWE2YTY0NjQwYjE0NWZmMmNiZTE5MzVmNzQ0ZjkiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2015-12-16 00:30:54.818045+00
5gjbdidc3l6w6ngll4jq2jqonlfb5qum	NGE2OGVhNDQ4YWI1ZDhmNjI0MGZhYTI0ZjExZjEzYTJmMDM4Y2MzYzp7Il9hdXRoX3VzZXJfaGFzaCI6ImY4NGIyNjcwOWY0YTgyOTUzMmZjYzcwMDhkNjZjMmRjYmI3NmQyOGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2015-12-16 17:07:01.785629+00
hjvlj0jg04tx65j9povtrja90o95n0me	NGE2OGVhNDQ4YWI1ZDhmNjI0MGZhYTI0ZjExZjEzYTJmMDM4Y2MzYzp7Il9hdXRoX3VzZXJfaGFzaCI6ImY4NGIyNjcwOWY0YTgyOTUzMmZjYzcwMDhkNjZjMmRjYmI3NmQyOGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2015-12-16 17:48:55.222679+00
di342o0bpuglm6u0zvqhnoobxcbzrz0y	YWZiMTM3OTEyOWUyZjU2ZjRjZjFkODA2ZGYyNTc0ZWM2NTY0NjBjOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjY2ZjFlZTc3Y2VmYzE1Njg2MmQ0MWU4NGQ0OTNiNWRiNzg2ZjM5YzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2015-12-16 21:36:11.306509+00
ih4zirs0ppuzak29u191cq6o1cyb62iw	ZjQzYzc4NDk4YzNjMzM5MTZiMmUwZmExMzc0YWY3NTRjZGVhMDdhNTp7Il9hdXRoX3VzZXJfaGFzaCI6IjVjMzk4YzIxNWRhYWE2YTY0NjQwYjE0NWZmMmNiZTE5MzVmNzQ0ZjkiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2015-12-16 22:48:39.982435+00
4j9mmrwowmnk8jaa03q5jwc5lirr2y18	YmQyMGRmNzllZTlkNzQxZDg0MTFhYmVkMjAxYjhjMTgxY2Y0MDc5MTp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmMDRjM2QwNTk0YjQ2YTUzYTIzY2U0MjRhNjUyYTgzMzE4YmVjYzMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2015-12-17 01:45:41.450108+00
a8a48dp513c58n1ixzeedbgjeo4zbw04	YWZiMTM3OTEyOWUyZjU2ZjRjZjFkODA2ZGYyNTc0ZWM2NTY0NjBjOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjY2ZjFlZTc3Y2VmYzE1Njg2MmQ0MWU4NGQ0OTNiNWRiNzg2ZjM5YzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2015-12-17 01:48:33.693311+00
3iti23xui2ybfdv6jn9x8dr75mwnpc37	NGVjMzI2M2ZiMTI0Y2MzM2NlYmNjOTFhZjA1Y2JlOGIwYWUwZmU5Mzp7Il9hdXRoX3VzZXJfaGFzaCI6IjczNDhkNWM5Y2EzNGI4NWQzN2RiZDAwMzM1ZDVkYWY3YjIzZjEwMTAiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2015-12-17 05:58:56.140043+00
8l58lnf490iw2px360kbbczdbgnmjejt	ZjJlOGQ5Y2UxMWJjNmMxYmRhYzVhYjc0MjdmYjU5NDI3NzU3NDIzNTp7Il9hdXRoX3VzZXJfaGFzaCI6IjgwZjc2Y2I2M2ZkZWYzMDlkMDliNmUxODk2MzNlMGNhN2VlNGYwYTQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMiJ9	2015-12-17 06:00:16.990655+00
kr84fntjg51wxwejhwfzd92o1hfdfd4x	NGVjMzI2M2ZiMTI0Y2MzM2NlYmNjOTFhZjA1Y2JlOGIwYWUwZmU5Mzp7Il9hdXRoX3VzZXJfaGFzaCI6IjczNDhkNWM5Y2EzNGI4NWQzN2RiZDAwMzM1ZDVkYWY3YjIzZjEwMTAiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2015-12-17 06:40:40.351463+00
sft1gwsu6gmztbmf5df3g4tndfbdyhr2	ZDg3MmFkZDRlNzMzZjM1NzNiNTRiMDA4YzgzYjFkZDQ1YmJmOTM4ZTp7Il9hdXRoX3VzZXJfaGFzaCI6ImE0NzNhZDM5Y2M5YTNiOTM4ZjJkMTIzODI2ZGU0NzBjMWU1MzYwYTkiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2015-12-17 07:46:26.891188+00
dytrgdle9l7wlhr45bu16ed4m7nt4xub	ZDg3MmFkZDRlNzMzZjM1NzNiNTRiMDA4YzgzYjFkZDQ1YmJmOTM4ZTp7Il9hdXRoX3VzZXJfaGFzaCI6ImE0NzNhZDM5Y2M5YTNiOTM4ZjJkMTIzODI2ZGU0NzBjMWU1MzYwYTkiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2015-12-17 07:47:41.138449+00
3g0864njcl7mcysilbgseeocs3thnuuh	ZDg3MmFkZDRlNzMzZjM1NzNiNTRiMDA4YzgzYjFkZDQ1YmJmOTM4ZTp7Il9hdXRoX3VzZXJfaGFzaCI6ImE0NzNhZDM5Y2M5YTNiOTM4ZjJkMTIzODI2ZGU0NzBjMWU1MzYwYTkiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2015-12-17 07:52:43.817154+00
i5y3qeimho4k5xucntm58z4yxy41o5og	ZjQzYzc4NDk4YzNjMzM5MTZiMmUwZmExMzc0YWY3NTRjZGVhMDdhNTp7Il9hdXRoX3VzZXJfaGFzaCI6IjVjMzk4YzIxNWRhYWE2YTY0NjQwYjE0NWZmMmNiZTE5MzVmNzQ0ZjkiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2015-12-17 19:16:25.746362+00
\.


--
-- Data for Name: recordstore_album; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY recordstore_album (id, name, num_songs, release_date, rating, artist_id, genre_id, musicbrainz_id) FROM stdin;
1593	2009-10-23: Ivory Blacks, Glasgow, UK	0	\N	3	442	\N	557512b1-a747-4d54-9c85-a578e4e37351
1594	Another Language	0	\N	3	442	\N	63c2c235-892a-4bd5-8439-57a3357c7689
1595	Another Language	0	\N	3	442	\N	79baaa49-de8c-4444-a026-9f8e7426bae5
1596	Live in Reykjavik, Iceland	0	\N	3	442	\N	8062cedb-77a0-4eed-863e-452b45a6a6e0
1597	Another Language	0	\N	3	442	\N	9238e473-efcf-40e8-af90-c7752b08e3ce
1598	Tunnel Blanket	0	\N	3	442	\N	be65cd51-9d05-339f-8fd2-07c9f174c736
1599	This Will Destroy You	0	\N	3	442	\N	d0625be2-7d18-4ed8-a121-352ba282bd78
1600	Live in Reykjavik, Iceland	0	\N	3	442	\N	e65b0f7c-e280-45ca-84ed-492c43ed29c2
1601	Tunnel Blanket	0	\N	3	442	\N	fae38d4f-9bfb-4c72-bbfb-8d71b87e84a2
1602	Burn This Racist System Down	0	\N	3	444	\N	063bb9d7-a6d1-3a93-9aed-55c74ac080c9
1603	Necropolis	0	\N	3	444	\N	13b3f70a-691e-4771-b755-72d1b39b7fed
1604	Burn This Racist System Down	0	\N	3	444	\N	2c094643-a245-4aff-a6b5-7044480242cc
1605	Discography - 1990-1994	0	\N	3	444	\N	43cc71a0-0bc7-4242-91bf-e8f5486fe4ca
1606	Source Tags & Codes	0	\N	3	445	\N	07cd271a-ab03-454f-88f9-a159e14e4297
1607	Tao of the Dead	0	\N	3	445	\N	2c914e18-6ead-3c34-b8a6-5a474bde2d83
1608	…And You Will Know Us by the Trail of Dead	0	\N	3	445	\N	44eb8e85-acd8-48b8-b6c1-27130fc21abc
1609	Lost Songs	0	\N	3	445	\N	4ab66cc6-e922-478c-bb5c-15d24850940e
1610	Tao of the Dead	0	\N	3	445	\N	4b34f912-d62b-414a-bbb6-01a64f43d597
1611	So Divided	0	\N	3	445	\N	4f22f3a8-82ca-45ad-8aed-8d2a7f6a9f8e
1612	Tao of the Dead	0	\N	3	445	\N	5ddac5f1-f71d-4bbc-ba8c-b7fe2b8a0636
1613	Worlds Apart	0	\N	3	445	\N	625d8145-540f-4df3-b788-0b05563b30fd
1614	Tao of the Dead	0	\N	3	445	\N	6823f8c6-0bbc-348b-a079-2e5fdf9d49d2
1615	Worlds Apart	0	\N	3	445	\N	70353cd2-9753-3496-a644-8e559fe37ff7
1616	Tao of the Dead	0	\N	3	445	\N	891f78ff-dbc6-428d-86d2-9a3107505e30
1617	Worlds Apart	0	\N	3	445	\N	97f5b8de-4763-4777-808e-5fc093dabc4b
1618	The Century of Self	0	\N	3	445	\N	9def4bc2-28e2-45df-a024-e46b184ee1ca
1619	Source Tags & Codes	0	\N	3	445	\N	a3c87dab-0cef-3b25-a319-ebaa32629aae
1620	Source Tags & Codes	0	\N	3	445	\N	aced959c-ebf8-3466-8b23-e83b365ad4d2
1621	Worlds Apart	0	\N	3	445	\N	bd3160c4-ea4b-4c84-92e0-197b94ae5c7d
1622	Madonna	0	\N	3	445	\N	c0e08fe2-bdb1-3412-a459-bbe734369aa4
1623	…And You Will Know Us by the Trail of Dead	0	\N	3	445	\N	c28c3c27-d55b-4c42-a48a-891343814965
1624	Worlds Apart	0	\N	3	445	\N	ca5c5eee-3c1c-4186-a305-d7feebf1032b
1625	So Divided	0	\N	3	445	\N	d2833cf5-8e70-4633-a1f0-d300dadcd1d1
1626	The Century of Self	0	\N	3	445	\N	db71565d-11ad-3d2b-af48-ebb94f737e2b
1627	Source Tags & Codes	0	\N	3	445	\N	e129e1b3-d9b1-4cd2-9c93-586867fbbe4f
1628	Madonna	0	\N	3	445	\N	e358920c-4283-463e-ae0b-337fee7c843b
1629	The Century of Self	0	\N	3	445	\N	ec04b337-3f12-3c7b-bab2-c2ca31a42224
1630	Madonna	0	\N	3	445	\N	fe86aee9-c059-4c7c-ab52-073dcbaf8c18
1631	Devour the Power	0	\N	3	446	\N	5752d86a-8cf9-480e-8d0b-ad89baae574f
1632	Battle Sluts	0	\N	3	446	\N	6c0de770-7eb8-48fc-96e2-e07f6236ce64
1633	Gospel Crusade	0	\N	3	448	\N	185eda7f-ef24-40f7-9d6f-4ba1b5e7c561
1634	November 22, 1963	0	\N	3	448	\N	6a4a9487-3a04-48a3-99a2-8fdc64dfc803
1635	Bored	0	\N	3	448	\N	a67c0b11-bbb5-4e7d-bab5-7c72156ab872
1636	1974-1976	0	\N	3	448	\N	d3239450-2bb5-4ebf-80ef-3f4cbd37d8c5
1637	I, Lucifer	0	\N	3	449	\N	61196a70-453a-4336-9866-748445b2c2e9
1638	Saints	0	\N	3	449	\N	aaa52df5-e9c8-408b-9fc3-4f8588f6523e
1639	Welcome Oblivion	0	\N	3	450	\N	1cc16d20-60ae-4e40-858a-4114a59862c4
1640	Welcome Oblivion	0	\N	3	450	\N	48dbab8a-d014-4494-a864-d0a13f775098
1641	Welcome Oblivion	0	\N	3	450	\N	d5a47416-0b72-4d0f-84f1-feb2c270bcf0
1642	Welcome Oblivion	0	\N	3	450	\N	fd255089-2489-4a2c-af2f-ed8a4e98ccb2
1643	To Destroy a City	0	\N	3	451	\N	1d35ae35-a529-4d46-ada3-5ccf04d65784
1644	To Destroy a City	0	\N	3	451	\N	65e3d7ec-2ea7-475d-8502-f41e16947d7f
1645	Sunless	0	\N	3	451	\N	bfc0dcb4-94ad-443a-bb19-179a65433c12
1646	Live at Lincoln Hall, Chicago IL	0	\N	3	451	\N	d69b11f8-c067-455e-9fe6-4fed25d31258
1647	Rebuild	0	\N	3	451	\N	e1e6e31b-115a-4c29-9294-07e18dc41d2a
1648	D.R.U.G.S.	0	\N	3	452	\N	200d55ff-6df5-46f9-82c5-896196ab0f35
1649	D.R.U.G.S.	0	\N	3	452	\N	786fbfb2-c9ba-4c63-9e9b-baf5fb2ec794
1650	D.R.U.G.S.	0	\N	3	452	\N	e686b5d6-6325-4597-96f5-cb981c92fb01
1651	Walk Softly, a Dream Lies Here	0	\N	3	453	\N	0e75e7b6-eabc-433a-aa01-563b45ec0e4e
1652	Light and Shade	0	\N	3	453	\N	15c075c2-78a3-4724-b0ba-64e8e29a41ca
1653	Tears in Rain	0	\N	3	453	\N	49171a37-ef8a-4b3c-9a4c-4b4e18d826a0
1654	Tears in Rain	0	\N	3	453	\N	6bfca3e4-aa10-4ee2-b312-386dc49fc1c5
1655	Tears in Rain	0	\N	3	453	\N	aec2deab-68c0-4ec8-b72e-d6d719764991
1656	Sever	0	\N	3	453	\N	bb39ca06-62d7-46a4-867d-a66d9757fcd7
1657	Light and Shade	0	\N	3	453	\N	c4efefc4-aefb-4e51-9054-b1dfee72fcaa
1658	Tears in Rain	0	\N	3	453	\N	e1db81b2-a57a-4e3d-8c7e-8b721ba68d0c
1659	Our Worlds Divorce	0	\N	3	454	\N	0378c419-4d7a-45c6-bb22-97dfa252e519
1660	This Providence	0	\N	3	454	\N	536ee223-182b-401d-8cab-ef47a538d67a
1661	Who Are You Now?	0	\N	3	454	\N	b9d98619-bfa0-451e-8eff-28f88af3ae03
1662	Mambo This!	0	\N	3	455	\N	f49d371c-79e8-4941-947e-1b793edf8ba7
1663	Stories Never Told	0	\N	3	456	\N	736a1dd2-3be6-4087-93ac-4ba7923f3bcf
1664	Where No One Knows My Name	0	\N	3	456	\N	895c2193-0591-41ad-b237-6eb93f7c12ff
1665	West Side Horizons	0	\N	3	457	\N	bf39ba4c-70bc-478d-af84-364b29d7bca3
1666	rose ave.	0	\N	3	458	\N	4554277a-8b5a-4e27-a892-8796c6b1431d
1667	rose ave.	0	\N	3	458	\N	bf113f22-3534-4ffe-8e91-2c0cddb812d4
1668	rose ave.	0	\N	3	458	\N	fcd4f380-c584-461a-b8e6-1eeed896c746
1669	The Act	0	\N	3	459	\N	57795353-aa77-490a-8545-f363926cf7c8
1670	Carpe Diem	0	\N	3	460	\N	6e10e102-d535-4f7c-8ba5-a05f14a29682
1671	El Diablo	0	\N	3	460	\N	9d863bdd-3287-4e89-9845-07a022cfa522
1672	Voir Dire	0	\N	3	460	\N	b4bb39a0-2ee4-4526-be24-a909210ec93b
1673	WHVN	0	\N	3	460	\N	c7616f5d-a982-4938-bdd8-dea1b40ec268
1674	The Hierophant	0	\N	3	460	\N	ca3ac9c3-c4b1-480d-9905-105fecc6c3f8
1675	Megafauna	0	\N	3	463	\N	a25ed884-89ca-47ac-b6b7-acbac91344ce
1676	Fireworks	0	\N	3	465	\N	46fb053b-ba2d-42f3-9c25-cdfca5960e32
1677	Like Icicles	0	\N	3	465	\N	5810f2f6-3125-4cc1-b4ca-9cf2c1beaf8d
1678	In the Absence of Truth	0	\N	3	467	\N	0ba88c6e-cc27-4d6b-bf98-638464ec069e
1679	Wavering Radiant	0	\N	3	467	\N	13537703-ae59-46f1-a535-2b83a5a996e8
1680	Live.02	0	\N	3	467	\N	1633b07d-f40a-499f-9772-26a1ef24e0ca
1681	Clearing the Eye	0	\N	3	467	\N	32189b20-1f26-40da-a38c-f6889ba862fa
1682	In the Absence of Truth	0	\N	3	467	\N	3942d8f3-e483-4406-a7bc-29f3025f0297
1683	Panopticon	0	\N	3	467	\N	4ea5aeb9-ebc6-4ac6-ae05-182124612d54
1684	In the Absence of Truth	0	\N	3	467	\N	54798a91-1a23-32a4-8068-b99e139800a7
1685	Oceanic	0	\N	3	467	\N	5717403e-de11-4982-9016-39687be4b3b9
1686	Celestial	0	\N	3	467	\N	580f283b-4681-3364-ae35-92a85c59326a
1687	In the Absence of Truth	0	\N	3	467	\N	7033ba7e-2099-4e88-aa74-b9b38fd0345f
1688	07.23.06	0	\N	3	467	\N	7e4dcbd2-63a7-4a3c-8161-cc41010902b9
1689	Oceanic Remixes / Reinterpretations	0	\N	3	467	\N	86d61cd4-804e-377a-93bc-bc66eb395384
1690	In the Absence of Truth	0	\N	3	467	\N	8975f6d6-1776-4aa9-b997-cc9369c5ba5a
1691	Celestial	0	\N	3	467	\N	9d166e91-fd49-4887-9062-0e0357e405a9
1692	Wavering Radiant	0	\N	3	467	\N	a8337aad-00c2-3735-8ce9-d88626725837
1693	Live > 09.23.03	0	\N	3	467	\N	acfef296-9168-488d-be52-fa809da8fd32
1694	Live.03	0	\N	3	467	\N	b8c5a922-9bf7-4b3e-a1b8-5b8a9e707e85
1695	Celestial	0	\N	3	467	\N	cecd8c4e-2685-4b21-9044-015a147f66b4
1696	Oceanic Remixes / Reinterpretations	0	\N	3	467	\N	e19da8cc-73fa-46ae-b44c-eaeb3a334b67
1697	Panopticon	0	\N	3	467	\N	e27dc788-3911-4785-b39c-abed4ee2d1cc
1698	Wavering Radiant	0	\N	3	467	\N	e411ba3e-7a70-4336-9522-1d6c8cf0f044
1699	Oceanic	0	\N	3	467	\N	e41d013a-b455-4359-84c5-c14b6112bba8
1700	Wavering Radiant	0	\N	3	467	\N	f09ce65b-83f1-369a-a4e5-089627a5db6c
1701	Live 4	0	\N	3	467	\N	f14daca8-04c0-4caf-9edb-69c2a7be4137
1702	Wavering Radiant	0	\N	3	467	\N	fff40607-bc16-4b11-81b2-9257acb258cc
1703	Second Coming	0	\N	3	468	\N	29e9bc94-767b-42e4-95d9-5987f87fc74d
1704	Ain't No Backin' Up Now	0	\N	3	468	\N	76c88cfb-bd23-46e7-be6a-9e6f3cc543b5
1705	Isis	0	\N	3	468	\N	d27128f8-28c7-4429-9998-929ae599320d
1706	Isis	0	\N	3	469	\N	55f0c08d-4782-45a7-8eed-5d394e645905
1707	Rebel Soul	0	\N	3	471	\N	d027ed34-b767-4420-8100-4ce997542aa4
1708	100% Isis	0	\N	3	475	\N	10498630-5c6f-4f0d-a138-de4e8fe62d47
1709	100% ISIS 2	0	\N	3	475	\N	b7923765-db58-4b2c-a875-fe097216cf7a
1710	Reformation	0	\N	3	475	\N	f08b0ea1-cf63-476f-9a40-890ee64adbad
1711	Nos Montes da Adoração	0	\N	3	476	\N	2f6996a6-db96-4d16-b339-792216153b43
1712	heartbreaker	0	\N	3	479	\N	2669fce3-6cd7-469e-b990-4c3c01d48de4
1713	Electro Sensual	0	\N	3	479	\N	3992cc86-0f94-40a4-b558-0a59293bdd19
1714	Isis Moreira - pianista	0	\N	3	483	\N	0c9771ee-ba70-4741-b925-6b9b722990d8
1715	Gamma 3	0	\N	3	490	\N	09e956fd-76d7-4594-85a0-3740efcf6e7f
1716	Gamma 1	0	\N	3	490	\N	4979dc96-4621-49ce-8786-e25a7ac45b19
1717	Gamma 3	0	\N	3	490	\N	830f41f8-f555-47a2-8afe-3f8a31d7eeda
1718	Gamma 4	0	\N	3	490	\N	c17ae368-a8a8-449b-9d4d-9b3e2d381db0
1719	The Best of Gamma	0	\N	3	490	\N	cd94d9cf-a532-40df-873c-1b43421a1f79
1720	Gamma²	0	\N	3	490	\N	d4f67978-6a2b-45ba-a8ca-e949c127fcd0
1721	Gamma²	0	\N	3	490	\N	d6935795-03b2-4f9e-910a-8d82c709e60a
1722	Gamma 1	0	\N	3	490	\N	dd83d130-54f0-4d60-b9ac-abed7f094c89
1723	You Have the Right to Remain Silent...	0	\N	3	491	\N	9dcf160d-d73b-41da-b728-7cfafb5b2500
1724	Bleeder	0	\N	3	492	\N	90f35de7-5ec9-405c-8365-435f4e18cc73
1725	Bleeder	0	\N	3	492	\N	af40e91f-61e7-48a3-8c07-e58967666c6f
1726	Rabbit Habits	0	\N	3	494	\N	150fdfc7-5a74-446a-87f4-7bdd449023f9
1727	Six Demon Bag	0	\N	3	494	\N	21d33df2-e2a0-410f-b27b-6e9a942707f4
1728	Life Fantastic	0	\N	3	494	\N	29df48a4-81eb-43b5-801c-4e18d650c659
1729	Rabbit Habits	0	\N	3	494	\N	2a455936-91d2-4d2b-b6b4-97a04655f437
1730	The Man in a Blue Turban With a Face	0	\N	3	494	\N	33b32d59-9344-414a-ac70-a1f67231cfb8
1731	On Oni Pond	0	\N	3	494	\N	38f8fada-7172-46f4-ad12-e0e8abf5bc88
1732	Life Fantastic	0	\N	3	494	\N	3bcfd4b2-a2f4-4d9a-ae5d-bbe6f343b1c5
1733	Rabbit Habits	0	\N	3	494	\N	618dd6a7-61ba-4ced-818c-a3c7b2bb3aee
1734	On Oni Pond	0	\N	3	494	\N	8584f290-cad6-416b-bc85-e4a705da3f58
1735	Life Fantastic	0	\N	3	494	\N	96d71ab3-890c-4734-b93f-4691e9f884b5
1736	Life Fantastic	0	\N	3	494	\N	b7a74dff-b4e0-4e13-9289-df8700141b10
1737	A Spectrum of Infinite Scale	0	\N	3	495	\N	12207eee-d30f-3888-82c0-7a006dbd11be
1738	Made From Technetium	0	\N	3	495	\N	15526833-fec3-49eb-b587-3e2debd3ef67
1739	Destroy All Astromen!	0	\N	3	495	\N	1933de01-235c-4252-8acc-20bafbee6f23
1740	Experiment Zero	0	\N	3	495	\N	20532932-c1f1-4c78-9127-4d8cdc5ad7b4
1741	Is It … Man or Astro‐Man?	0	\N	3	495	\N	217c33f9-912c-4260-8430-5918cfb8bfef
1742	Intravenous Television Continuum	0	\N	3	495	\N	233c5f36-be54-42d8-bd57-899cf416995a
1743	EEVIAC: Operational Index and Reference Guide, Including Other Modern Computational Devices	0	\N	3	495	\N	247a4ca1-e24e-42e3-ba4a-11fb09dba0c2
1744	Beyond the Black Hole	0	\N	3	495	\N	2b812b53-d88f-4f69-b2e5-a0206b5b1da2
1745	EEVIAC: Operational Index and Reference Guide, Including Other Modern Computational Devices	0	\N	3	495	\N	3c10e62c-d2c2-46ba-83a6-c98dd143506a
1746	EEVIAC: Operational Index and Reference Guide, Including Other Modern Computational Devices	0	\N	3	495	\N	3d258602-a662-4a35-80d5-a98bd3129a70
1747	Project Infinity	0	\N	3	495	\N	59426b59-a04c-4d5a-907d-fb9fd58bf738
1748	1996-12-01: Exit/In, Nashville, TN	0	\N	3	495	\N	6ba1d017-e00a-48e4-99a9-526c1e1a2fe1
1749	Live Transmissions From Uranus	0	\N	3	495	\N	6beace7a-99c4-3332-b5df-7ec9c7df1fbf
1750	Project Infinity	0	\N	3	495	\N	880bc699-2472-41ed-83db-7c71593cad7f
1751	EEVIAC: Operational Index and Reference Guide, Including Other Modern Computational Devices	0	\N	3	495	\N	91121349-abd7-3d51-8495-a89113be5cf0
1752	What Remains Inside a Black Hole	0	\N	3	495	\N	9ab83a83-4e4f-45a3-b726-1545435a74f2
1753	Made From Technetium	0	\N	3	495	\N	a2aeb13b-230e-30a8-a802-412ad8266ed9
1754	Intravenous Television Continuum	0	\N	3	495	\N	a4539874-73b6-3bc0-97c0-36c43a8694af
1755	1998-09-26: The End, Nashville, TN	0	\N	3	495	\N	a6627b9f-6f66-4693-be55-7709464c4391
1756	A Spectrum of Infinite Scale	0	\N	3	495	\N	aa24e49d-b9ab-4775-a46c-762e8c3703ce
1757	A Spectrum of Infinite Scale	0	\N	3	495	\N	c6cd5df7-c433-4de2-8883-2045bf219126
1758	Made From Technetium	0	\N	3	495	\N	cad95328-ecae-4a9c-a6bc-d6db12b32253
1759	Intravenous Television Continuum	0	\N	3	495	\N	d2be3c08-e242-4839-bb26-358b3a36a342
1760	Experiment Zero	0	\N	3	495	\N	d7d7e6aa-29f7-4cbe-93ff-f68c9acc5417
1761	Live Transmissions From Uranus	0	\N	3	495	\N	e7396c78-beaa-4e83-96fd-2e507e36eb1e
1762	Automatic Man	0	\N	3	496	\N	98a4a944-f0d0-4344-b3e5-092b64e86aec
1763	Visitors	0	\N	3	496	\N	b61e7626-9d5d-45bc-a1ed-a435731e95e5
1764	Hunger Is All She Has Ever Known	0	\N	3	497	\N	4408e43e-b8ff-40b4-808d-8af148a03de2
1765	Sex With God	0	\N	3	497	\N	4a030b21-3d08-428d-be8f-9f254afc93e0
1766	The Shroud Of	0	\N	3	497	\N	689f92c8-d387-4854-acaf-6f8a7e6e8a6a
1767	Slave Lullabyes	0	\N	3	497	\N	e9f0b63b-1376-4a3c-981a-de4d138115b3
1768	Shroud	0	\N	3	497	\N	f786b41d-9865-4205-a4c1-c7163920d7af
1769	Safari	0	\N	3	497	\N	ff4707fa-9e18-44b1-b46d-e09b0613e80f
1770	Double Image	0	\N	3	498	\N	caea4402-cf07-38e9-af79-1069ffb48853
1771	Double Image	0	\N	3	498	\N	cf781f43-4baf-468e-8464-daef3dd2ae92
1772	Marginal Man	0	\N	3	498	\N	ea526afc-f2b4-44b4-bdab-2a706063381f
1773	Marginal Man / Discography / Double Image	0	\N	3	498	\N	f602362a-2683-4ab2-8055-7e5c85251aa6
1774	Generation Void	0	\N	3	501	\N	723c91a6-ba51-491b-b7cf-92891251ea09
1775	Black Night	0	\N	3	501	\N	730d068f-719c-4000-91d5-9428fcdc9446
1776	I Have Returned	0	\N	3	501	\N	83ce5e85-eea7-43ee-8e1f-4cbdf365a7db
1777	Generation Void	0	\N	3	501	\N	9d931957-94ff-40dd-a975-af07f48dbcb7
1778	Black Night	0	\N	3	501	\N	9e0ee8d3-148d-44d1-9923-1ed22a6ed98a
1779	South of the Earth	0	\N	3	501	\N	c56cbe33-2ec1-4959-b04d-8e4b4c7c41c5
1780	The Passage	0	\N	3	501	\N	dd41152d-15e2-4adb-b797-299619f5dace
1781	The Birth of Sol (The Demo Tapes)	0	\N	3	502	\N	0914e2a6-17dc-4e64-ab7e-421a10c272f0
1782	Rock Formations	0	\N	3	502	\N	1e201808-e71e-45a3-ba12-1e8ad137a0db
1783	Vista Point	0	\N	3	502	\N	400b626c-7d7c-4ea0-a7c0-fe391b9464a7
1784	Nomadic Pursuits	0	\N	3	502	\N	66651ac8-dbf7-4977-8d3f-61d9bb9bc5c2
1785	Rock Formations	0	\N	3	502	\N	869d60ae-5543-4f54-8498-e8dc263f8056
1786	Thank God You've Got the Answers for Us All	0	\N	3	503	\N	27fd8e14-c51e-4140-a2d5-c029316a203d
1787	Death Potion	0	\N	3	503	\N	2952f1a3-518e-4196-a9f0-6bf764e2d0f2
1788	Closing In	0	\N	3	503	\N	78933936-83b5-44a8-a26f-b749ec8fd322
1789	Street Fight!! Round Two	0	\N	3	505	\N	39c3bf23-29ee-4727-a546-60c34a27d9c7
1790	Street Fight!!! Round Three	0	\N	3	505	\N	df58b0ee-2a3d-4728-853f-29ce880603be
1791	Street Fight!! Round Two	0	\N	3	505	\N	e76db9ad-7c1f-4c4b-9661-d2377870e13b
1792	Street Fight! Round One	0	\N	3	505	\N	f457cfb6-6525-4b0f-84a0-c920e991db30
1793	Man Overboard	0	\N	3	506	\N	265650e9-43b7-4edd-91c3-508f0bb2b6f5
1794	Before We Met: A Collection of Old Songs	0	\N	3	506	\N	3545aac9-e3fc-4c47-81a1-6ddd902126d4
1795	Live at Leeds	0	\N	3	506	\N	37705358-3657-4c6d-8271-c609c03e36f0
1796	Real Talk	0	\N	3	506	\N	39773a74-7526-48d1-929d-e53a30c41188
1797	The Human Highlight Reel	0	\N	3	506	\N	4019a0ae-1be1-49ab-b21f-199d35fedd6c
1798	Real Talk	0	\N	3	506	\N	57dd8213-273c-404a-8713-4c9b77b63e2b
1799	Heavy Love	0	\N	3	506	\N	74a72ea5-54cf-4ba7-86f1-9ed0f77ef223
1800	Heavy Love	0	\N	3	506	\N	85f3643e-a3ff-4c9f-b938-b2d2fd11fdc2
1801	Real Talk	0	\N	3	506	\N	ce4c90a4-ae0d-4e04-a52f-f2745e1061e7
1802	Heart Attack	0	\N	3	506	\N	d9153205-d57d-4852-a375-d65c3d0d3262
1803	Before We Met	0	\N	3	506	\N	f37e3d70-8749-4587-97be-a1ce6857751b
1804	Real Talk	0	\N	3	506	\N	f9aa15b0-5cb8-4c90-9d76-1361a62a9034
1805	Mountain Man	0	\N	3	507	\N	c86db0cb-d2c8-4d6e-b09c-29c5e6b3948c
1806	Made the Harbor	0	\N	3	507	\N	e5d8a004-13b8-4162-8243-34d548391456
1807	The Wide Album - Live at the Bottom Line	0	\N	3	508	\N	410cbd7f-ea78-49fe-8a9f-568b371256f6
1808	Modern Immaturity	0	\N	3	508	\N	d74985ec-ec4a-45ef-8320-14166c53c6a1
1809	Music for Your Own Personal Drama	0	\N	3	509	\N	07eb4533-4c3d-4d1d-b132-20c28b77b141
1810	Old Man	0	\N	3	510	\N	ddd1d057-1c33-4aa9-b94c-1368ed3affae
1811	Drafted	0	\N	3	512	\N	3ef01e10-a93c-4fd5-a4f9-6226f6c022d6
1812	Don't Label Us	0	\N	3	512	\N	b9254f09-63d1-41f1-ac1e-890b7396ef23
1813	How to Be a Megastar Live!	0	\N	3	513	\N	05c50930-1189-43a0-94ad-3a716f28d03b
1814	The Complex	0	\N	3	513	\N	19553e96-ebae-4b3e-a5f9-57f2148c4e11
1815	The Complex	0	\N	3	513	\N	2b50bf67-8c3b-41b3-9c87-42ed8a3e9197
1816	Live at the Venetian, Las Vegas	0	\N	3	513	\N	36072a01-47d0-4ff1-ba70-b705ea355dd3
1817	Audio	0	\N	3	513	\N	5c273ad4-3469-48a7-8fb9-e5324b21ea16
1818	Limited Edition Las Vegas 4 Song Sampler	0	\N	3	513	\N	621a3211-f768-45a8-b650-2a2ebc26747a
1819	The Complex	0	\N	3	513	\N	6a898657-1932-487d-a12f-79be9729f726
1820	The Complex	0	\N	3	513	\N	759524c2-c669-39ba-8648-e30412db2495
1821	The Complex Rock Tour Live	0	\N	3	513	\N	7b8e5a11-c92a-4e4a-b962-4fe303ff9845
1822	The Complex	0	\N	3	513	\N	9ee76f3c-630d-44e1-ad92-670669f083c7
1823	The Complex	0	\N	3	513	\N	b14ce7b9-d973-33f2-b73a-2953253a4d11
1824	How to Be a Megastar Live!	0	\N	3	513	\N	b241e20d-d457-4272-9d11-ef30a42b0e86
1825	Audio	0	\N	3	513	\N	c8b2d5e5-505e-4aaa-acf9-034c3d604a0e
1826	Canta Conmigo	0	\N	3	513	\N	dacaedd8-43c0-4426-a398-e38c498a79db
1827	The Complex	0	\N	3	513	\N	fb8e5235-d058-4a4a-aaec-3062d5555518
1828	Canta Conmigo	0	\N	3	513	\N	fd3a5f23-1bd1-466b-8dd1-31ec0884c702
1829	Blackout!	0	\N	3	514	\N	19047da1-1af5-46dd-ac94-525d5e741010
1830	Blackout!	0	\N	3	514	\N	737a3d1e-5875-41c8-9cd2-c9d5c17f0b64
1831	Blackout! 2	0	\N	3	514	\N	81c72133-6fd3-4780-a850-3fee0e21336d
1832	Blackout!	0	\N	3	514	\N	8f734db6-836f-47bf-83af-a0ee19e97e22
1833	Meth & Red in da House	0	\N	3	514	\N	d829aec8-c2cf-439c-be9b-ba9d612dd8ac
1834	How High	0	\N	3	514	\N	f11fd464-85e0-4946-bf8e-acd80c718f6d
1835	Rumors and Headlines	0	\N	3	515	\N	451279f5-42b1-48af-9c40-7db3101edce1
1836	BYO Split Series, Volume V	0	\N	3	515	\N	60fe864c-e74e-427a-8716-ccc290ab7991
1837	Rumors and Headlines	0	\N	3	515	\N	63c07bcb-3ff2-459e-bf12-b5dfcd79cd40
1838	Dead End Stories	0	\N	3	515	\N	7720df69-aa77-42be-af2e-20e4ed06c817
1839	BYO Split Series, Volume V	0	\N	3	515	\N	f23d6b2a-a5d6-4287-a678-e55922a3c7bf
1840	Last Word Spoken	0	\N	3	515	\N	fdeaac53-3dc8-4da0-b66f-b18f78ede532
1841	D. I. Y. C. D.	0	\N	3	516	\N	19f88874-e6c4-4029-939a-c4ea1c2e3f66
1842	Man Is the Bastard / The Locust	0	\N	3	516	\N	7818dc3d-28ea-4b37-b0bc-adcea0b17a9e
1843	Capitalist Casualties / Man is the Bastard	0	\N	3	516	\N	c4d0761b-0b58-4a72-ae2f-0e4a00720f0c
1844	Sum of the Men	0	\N	3	516	\N	f4a36bcc-599f-4a19-930e-a34329464295
1845	Mancruel	0	\N	3	516	\N	f94f515a-d037-467d-bea0-f280ded7bfd3
1846	Thoughtless	0	\N	3	516	\N	ffe49a3e-601b-4715-9814-f59efa659e8c
1847	Blonde on Blonde	0	\N	3	517	\N	189efa45-def2-3b1c-b619-ba1640774705
1848	Blonde on Blonde	0	\N	3	517	\N	1b051a10-7268-3773-a9ba-660765056ae3
1849	Highway 61 Revisited	0	\N	3	517	\N	263a8ba4-cbc2-4fbd-9aa3-1de457c717a1
1850	Highway 61 Revisited	0	\N	3	517	\N	2c3938c1-896f-3963-8588-828e733e895c
1851	Subterranean Homesick Blues	0	\N	3	517	\N	2e707bfd-94f1-3885-8c7f-aea97258284f
1852	Blonde on Blonde	0	\N	3	517	\N	3020d468-48e7-36c7-8ae5-8cf7b139974c
1853	Bringing It All Back Home	0	\N	3	517	\N	33f63b52-23bc-3c29-946d-1c120d98e8c2
1854	Bob Dylan	0	\N	3	517	\N	4b5db958-0948-4151-8e1f-2d5b8cc35975
1855	Bob Dylan’s Greatest Hits	0	\N	3	517	\N	5b3ec538-cbe7-4f5c-8a79-4d3b1a550295
1856	Bringing It All Back Home	0	\N	3	517	\N	67e7ab93-d5c1-442f-b8c0-dbfad52e2d34
1857	John Wesley Harding	0	\N	3	517	\N	8e7e12b2-46ff-4e6b-8384-2ce538d90dcc
1858	The Freewheelin’ Bob Dylan	0	\N	3	517	\N	942be4b0-12a2-4264-93a3-b45fa94c95c0
1859	Bob Dylan’s Greatest Hits	0	\N	3	517	\N	9801918d-b912-4951-a7f3-21a9103c5ff8
1860	The Freewheelin’ Bob Dylan	0	\N	3	517	\N	a6558335-a869-4afe-a95d-dcbf34d98418
1861	Bringing It All Back Home	0	\N	3	517	\N	a8342f0e-d1a0-31bf-a643-20b2250ccad8
1862	John Wesley Harding	0	\N	3	517	\N	b20b9d53-aa07-395f-b129-0140c85bbbc8
1863	Bob Dylan	0	\N	3	517	\N	beb8751d-0aef-3b2f-89c2-4dc582b5a822
1864	The Freewheelin' Bob Dylan	0	\N	3	517	\N	c04dd1df-8cd6-4fee-9e97-cdb76c9fc86d
1865	The Times They Are A‐Changin’	0	\N	3	517	\N	c3662839-8729-4719-8494-bd9d30a8085f
1866	Bringing It All Back Home	0	\N	3	517	\N	c65242d0-596d-4ff5-9097-293dca0d4703
1867	Another Side of Bob Dylan	0	\N	3	517	\N	c70a68b7-8bd9-3eed-841c-54dca501f4d8
1868	Blonde on Blonde	0	\N	3	517	\N	c96d6546-25e4-4717-b514-62684245675f
1869	Subterranean Homesick Blues	0	\N	3	517	\N	ca754c1d-8254-4516-84b6-cb91559196e7
1870	Highway 61 Revisited	0	\N	3	517	\N	d61a2bd9-81ac-4023-bd22-1c884d4a176c
1871	Another Side of Bob Dylan	0	\N	3	517	\N	ec4cf6e4-4e24-49b8-9fd6-fad64393e3e5
1872	Re-Interpreted	0	\N	3	519	\N	801f73b2-9251-45ba-9665-18c984feb414
1873	More Adventures in Lying Down...	0	\N	3	519	\N	a2430f26-9c23-42bf-8460-92e3ad07a734
1874	It's All About (Rimshots and Faulty Wiring)	0	\N	3	519	\N	b35f14a8-4c6c-4632-a882-330d957b39d0
1875	Ur-klang Search	0	\N	3	519	\N	c83665ed-2fa3-44a4-a2f3-fab608cab510
1876	No One	0	\N	3	521	\N	da863854-3290-461e-a5fe-a1c227c5d6da
1877	Someone	0	\N	3	521	\N	f8f0f839-9f29-49e3-943a-515e2797cf4d
1878	Positively 12 Stiff Dylans!	0	\N	3	523	\N	f587c2a4-b363-4016-b6d4-6504f8a7864f
1879	The Bradley Suite	0	\N	3	524	\N	de47714e-6bd6-4ec2-bac3-1dd8f8cc09de
1880	With a Little Help From Our Friends	0	\N	3	525	\N	011e044d-ece5-4e71-875e-bad175450465
1881	It's a Wonderful Laugh	0	\N	3	525	\N	08fe278a-f387-4638-a404-2d4c91536f97
1882	Last Train to Whiskeyville	0	\N	3	525	\N	0abed966-2f68-4888-936d-5205e4ce9897
1883	Good Ol' Boys	0	\N	3	525	\N	1e46b645-27f3-4761-a736-d01e26f35dde
1884	Back in '98	0	\N	3	525	\N	1f4ea3b8-4d66-4466-a347-209cb1b535ff
1885	Twin Geeks	0	\N	3	525	\N	22b97878-fe56-4a8a-b23c-1b5f513cc227
1886	Planet Bob & Tom	0	\N	3	525	\N	3765888c-cad6-4491-8659-4f457e2d8709
1887	Factory Air	0	\N	3	525	\N	49b7f603-fc77-4f25-b5d5-f9cc6fe9e259
1888	Fun House	0	\N	3	525	\N	548ec574-d2e4-4e16-8877-4595bd79d2b9
1889	We Three Kings	0	\N	3	525	\N	6226b87f-8726-4c30-aa5a-e8da2650f785
1890	The White Album	0	\N	3	525	\N	8a6c29d4-b909-481a-9859-bc5eec4bd771
1891	Laugh in the Fast Lane	0	\N	3	525	\N	8a6c33ea-06a2-4474-b94f-5ee709e2b79a
1892	Find My Keys and We'll Drive Out	0	\N	3	525	\N	90fe8ed1-cb56-4450-b1b3-117a5ea5de39
1893	Gimme an "F"	0	\N	3	525	\N	a8c7bdc6-53cb-4e28-87db-fdd3c3b4bd1c
1894	A Day at the Race	0	\N	3	525	\N	ad5567c2-fcde-42a2-b1f9-de87c16d7736
1895	Motorheads	0	\N	3	525	\N	ae0d9a64-9f8a-4be3-8bcf-253a3dc91c8d
1896	Air Bags	0	\N	3	525	\N	ae7220b5-4e61-450f-9874-fd8d456a78ac
1897	Shabbey Road	0	\N	3	525	\N	afda798a-3a98-4836-be78-fc95a564129b
1898	Airheads	0	\N	3	525	\N	b763af28-6ab2-4f1a-951f-809e3119bf66
1899	Lollapaloozers	0	\N	3	525	\N	b7a3bdbf-7f75-4bf3-8821-1bd60cc878fa
1900	It's a New Track Record!	0	\N	3	525	\N	b9f90520-bc06-46e6-9037-dbb8c52a7c34
1901	Last Train to Whiskeyville	0	\N	3	525	\N	c2e89c08-b886-4377-8d09-dfe115548b63
1902	Checkered Past	0	\N	3	525	\N	c5e4e966-c7f4-44f5-9caa-f0dd8cc89474
1903	Canned Laughter	0	\N	3	525	\N	c83eb61a-5aca-45c2-8d73-6dc9657bf4df
1904	Just Skiddin'	0	\N	3	525	\N	e08d4e55-72de-4eb9-8f3a-64a4e4d32c59
1905	Harlem Shuffle	0	\N	3	526	\N	56752426-6fa2-4166-a6d4-cb5aa66a0123
1906	Harlem Shuffle	0	\N	3	526	\N	959edeec-4f6c-321d-8a29-3a4d2a065e83
1907	Bold Conceptions	0	\N	3	527	\N	087b7963-8ffe-4b63-8025-b32a62cdc008
1908	Take It From the Top	0	\N	3	527	\N	23a0f389-cd27-4182-980a-73d9c9cb768c
1909	Straight Up	0	\N	3	527	\N	41b1ad12-37d9-4803-8020-254e569e5ef1
1910	Take It From the Top	0	\N	3	527	\N	495fd4f7-f267-4353-82d6-e24b0ca36a6f
1911	Explosions	0	\N	3	527	\N	ce23927e-1b39-4b31-bb6f-bd2528ddb3e3
1912	Bold Conceptions	0	\N	3	527	\N	e994fca0-e160-4850-871c-245071ae68a1
1913	Train Man	0	\N	3	528	\N	04765f8b-1d1c-465e-8a1b-1db8999f70d2
1914	Ramblin' Gamblin' Man	0	\N	3	528	\N	43c7e6dd-c524-488d-888b-9a7b6f77f7ae
1915	Ramblin' Gamblin' Man	0	\N	3	528	\N	66496c37-d891-406f-b8dd-398ce898bc79
1916	Noah	0	\N	3	528	\N	6e249cd7-8fd2-406c-a068-4be9418a9e44
1917	Noah	0	\N	3	528	\N	6ea81664-16bd-4614-9c55-dce2953fcb21
1918	Mongrel	0	\N	3	528	\N	aeebd359-0de8-40a2-a718-80fe918f2048
1919	Ramblin' Gamblin' Man	0	\N	3	528	\N	d18b84ee-102c-46ae-b0cd-1a28d0486059
1920	Mongrel	0	\N	3	528	\N	ec5484de-e10e-3e43-bcc1-ef64ff7529b2
1921	Camouflage	0	\N	3	529	\N	04a84cd5-c92c-4ec0-97bd-1dcf103950c2
1922	Big Band Trane	0	\N	3	529	\N	2e1aea89-3808-4314-8f34-a4ebba050854
1923	Get Up!	0	\N	3	529	\N	4140195e-0c15-4d23-afe3-e46fdc38d96c
1924	Homage to Count Basie	0	\N	3	529	\N	423df871-67be-4aee-b1b6-7255996994c8
1925	Swing Out	0	\N	3	529	\N	4969d51a-f2d8-4be5-b0ff-4b499be59e50
1926	For the Moment	0	\N	3	529	\N	620b7d11-c302-4fc9-842e-effd052fa0d6
1927	Departure	0	\N	3	529	\N	77d608cb-751b-402b-b330-8cd8f4af16f2
1928	The 1st Decade	0	\N	3	529	\N	87b8fac7-707c-4fa2-9d17-15358854066e
1929	Old School: New Lessons	0	\N	3	529	\N	91c0572a-5778-44c2-916a-dd3614a26bde
1930	Incredible Journey	0	\N	3	529	\N	9714dddc-58ab-451e-8881-73cca11ac582
1931	Latin From Manhattan	0	\N	3	529	\N	b079b8ed-8d29-4ed2-990f-d6a713f5d0b7
1932	Gently	0	\N	3	529	\N	c36fe3d9-3d75-453b-a39f-767b185b790d
1933	Only in New York	0	\N	3	529	\N	cd0d9603-95ba-4694-ab35-d2ca4eac7c08
1934	Homage to Count Basie	0	\N	3	529	\N	d327405c-f2ca-461e-93f3-5e12d54eb8c2
1935	Music to Watch Girls By	0	\N	3	532	\N	9e6a70dc-215f-49f3-aa52-81759b67737d
1936	The Best of the Bob Crewe Generation: Music to Watch Girls By	0	\N	3	532	\N	a4e71eb8-9553-452c-b339-07ce52b18d54
1937	The Jazz Masters	0	\N	3	534	\N	1acec74a-3a6f-4a1b-9389-72f9dea0233f
1938	Live at ATP 2008	0	\N	3	535	\N	1ec603e6-f0f2-41f7-aa60-2c9c4fb2856c
1939	The Soap Operas, Volume 2	0	\N	3	537	\N	3ebb2cde-f04d-4e4d-a1fe-b4c9a4ea842e
1940	The Two And Only	0	\N	3	537	\N	6612f169-c80a-4141-8db1-bd77d3dff1d6
1941	The Soap Operas, Volume 1	0	\N	3	537	\N	c7dd8ef0-2c3e-4689-b7eb-e4781f39d795
1942	Vintage Bob and Ray, Volume 1	0	\N	3	537	\N	d65dbd6b-f8f9-4c36-9c98-c8c448eb51cb
1943	The Soap Operas, Volume 3	0	\N	3	537	\N	eb0c0d52-fddc-4bb7-b577-b8cd3c58bf0d
1944	Midnight Flower	0	\N	3	538	\N	6c8a99f0-4b52-431c-998f-a6ee94d516d2
1945	Live & Well	0	\N	3	542	\N	07eaa61a-4476-492f-a6bc-784e4eb160c2
1946	Blues for Me	0	\N	3	542	\N	09967936-9428-4bc6-a0c3-3e785048f724
1947	Swing Low Sweet Chariot	0	\N	3	542	\N	20e4115f-c06e-4ec7-bdf7-4fdbbe0d26ea
1948	The Soul of B.B. King	0	\N	3	542	\N	2d9edb03-6361-4951-9568-3900d23e0ddd
1949	Live at the Regal	0	\N	3	542	\N	31ea2414-6327-3b95-a17a-db06edb144d2
1950	The Blues	0	\N	3	542	\N	3abc74b2-42e4-4623-be09-0104bffe4e92
1951	Blues in My Heart	0	\N	3	542	\N	3b0df0be-ca2e-4c56-9bdf-ab982a29f8e9
1952	Live at the Regal	0	\N	3	542	\N	4c884d96-8e0e-34cf-8f75-b6db47687d5f
1953	Swing Low Sweet Chariot	0	\N	3	542	\N	4ca85731-fc12-4010-95a9-e51b78082af7
1954	Rock Me Baby	0	\N	3	542	\N	4e970320-3862-48df-bd48-bbe16510865f
1955	Mr. Blues	0	\N	3	542	\N	6358647b-0ac9-4d06-a18c-60032079f48b
1956	Completely Well	0	\N	3	542	\N	6fc0bdaf-2283-4819-b206-3fb0f7d1bb6f
1957	Blues in My Heart	0	\N	3	542	\N	7b1000cb-cf63-4b37-881c-ed2f619a67f8
1958	His Best - The Electric B.B. King	0	\N	3	542	\N	7b53251d-d03b-4732-880f-0ea9213374f4
1959	The Great B. B. King	0	\N	3	542	\N	8a76b6cb-dfc8-4403-ae1e-3fdb3aaa6b3b
1960	Easy Listening Blues	0	\N	3	542	\N	92140a1e-0230-42d2-9b96-19757782ed8a
1961	Lucille	0	\N	3	542	\N	9f04e934-302b-4bde-8712-f6a2e151d5c8
1962	Completely Well	0	\N	3	542	\N	a17b7bf0-c5ba-442f-b2d9-8728f7b6bd20
1963	Blues on Top of Blues	0	\N	3	542	\N	a46f0477-38f9-4824-8922-5df0217d58f4
1964	Blues Is King	0	\N	3	542	\N	b5ac9265-57b7-44f9-ac77-a99bf7b234e4
1965	Easy Listening Blues	0	\N	3	542	\N	c690a567-ada5-4b66-8f56-37c4ce347446
1966	Singin' the Blues	0	\N	3	542	\N	ce4dff9d-a364-476e-abfb-f365bb92d7fd
1967	The Jungle	0	\N	3	542	\N	db28abad-71d0-4fb6-ab10-9558b7b32c0f
1968	Easy Listening Blues	0	\N	3	542	\N	e6daa0d8-addf-41fd-bd68-3d76c239336b
1969	Sings Spirituals	0	\N	3	542	\N	fef41dbb-1a49-4e27-bacf-c95a29f3fc8b
1970	That Soul Sound of the 70s	0	\N	3	545	\N	161331b6-d56c-4433-9816-d4bf2dcf4b84
1971	Genie	0	\N	3	546	\N	105a86f4-b3f3-4cf7-a475-38816ee65196
2203	New York Town	0	\N	3	605	\N	40633eea-192b-41e0-b328-95e995dbf447
1972	The Best of B.B. and Q Band	0	\N	3	546	\N	114b8c68-f99b-4fa6-860b-9f256a6f9a98
1973	The B.B. & Q. Band	0	\N	3	546	\N	2f76241a-d6ce-4759-aa85-93038083bd5f
1974	Six Million Times	0	\N	3	546	\N	8442885f-426f-4974-af0d-b4a80243b2a8
1975	The B.B. & Q. Band	0	\N	3	546	\N	906a700d-dcc1-4ad2-8674-b49dbc130f8b
1976	The B.B. & Q. Band	0	\N	3	546	\N	99accd59-9fa4-4583-8246-430c3b9962c1
1977	The B.B. & Q. Band	0	\N	3	546	\N	db54805c-5d37-3772-834e-bb9ce16f4727
1978	All Night Long	0	\N	3	546	\N	f0700848-9884-403f-b822-0f1dd5787102
1979	Genie	0	\N	3	546	\N	f84f7986-6628-466c-be20-387ac5e04ca3
1980	B.B Plays Black Box Hits - Vol 2	0	\N	3	548	\N	652e64e0-4061-45ef-9212-aae21341ab88
1981	Busse Woods	0	\N	3	549	\N	4f424ff8-ade0-4d74-a440-df036e856b9d
1982	Free / The Father, the Son and the Holy Smoke	0	\N	3	549	\N	7a0e8d48-1cce-48b6-b31b-f960e15cb3ee
1983	The Early Years	0	\N	3	549	\N	838cd5c9-db84-4052-bc2f-edb777cef299
1984	Busse Woods	0	\N	3	549	\N	ade2b8b9-82ea-444f-83ff-0bf2880e025a
1985	III	0	\N	3	549	\N	b471e55e-68ef-4833-b3bb-c2a7417ee1f1
1986	Acid King / Altamont	0	\N	3	549	\N	cb83eb25-4e7b-4b71-a5cc-ea11955cf493
1987	Zoroaster	0	\N	3	549	\N	d2244a44-785e-47e7-8077-53a99413c53d
1988	Acid King / Altamont	0	\N	3	549	\N	e461ba47-fcf9-3ff6-9b88-30af0b536f08
1989	Busse Woods	0	\N	3	549	\N	edb31d46-c6c9-422a-94c4-72590a13adf1
1990	Middle of Nowhere, Center of Everywhere	0	\N	3	549	\N	ee53bf23-4e17-4f29-81a2-e4a1e1b7231e
1991	Mobile Estates	0	\N	3	550	\N	60ccbd50-2ed1-444a-a7b1-fa6d357e7c14
1992	Brown Bag LP	0	\N	3	550	\N	bba5c4c4-e475-436c-b077-0b0d3a8c119b
1993	The Body Has a Head	0	\N	3	552	\N	03e84ba3-e4a9-4df3-b0e5-40f92343fa0b
1994	Mystical Shit / Fluting on the Hump	0	\N	3	552	\N	1f7dc4c1-6cd2-3cc1-85fe-67cab373ba8c
1995	Royal Lunch	0	\N	3	552	\N	3f2ed2ee-a3ef-41db-94d0-db0a85cc6540
1996	Mystical Shit / Fluting on the Hump	0	\N	3	552	\N	4136bbb2-bdd7-454b-8def-abd122786c43
1997	The Way to Salvation	0	\N	3	552	\N	53c63cd3-518f-418b-ac30-2535d5485001
1998	King Missile	0	\N	3	552	\N	80887fa8-a162-4000-b038-1cb863d34a1d
1999	Mystical Shit	0	\N	3	552	\N	8ad83dbf-f817-4c64-a1c4-4dbaa2085c9c
2000	Happy Hour	0	\N	3	552	\N	8c45c5da-aaef-4c05-89c5-b54822f219b8
2001	The Psychopathology of Everyday Life	0	\N	3	552	\N	91107be0-a617-4940-8e8d-c658a65537f3
2002	King Missile	0	\N	3	552	\N	95983847-0a0a-4f63-a170-8a730120d212
2003	Live in Rochester	0	\N	3	552	\N	b4ea330e-4093-4cd5-9cd8-d276d05fc836
2004	Fluting on the Hump	0	\N	3	552	\N	d252500e-df60-4992-8ef3-c11a7357a191
2005	Failure	0	\N	3	552	\N	dffec7af-7eba-4cf5-a49c-e7e736f34f72
2006	They	0	\N	3	552	\N	ee62efaa-c17e-4e58-9ae5-7f0f17222a86
2007	Shoot the Messenger	0	\N	3	553	\N	1c299fde-fb15-4059-bc02-64aba0ead3f9
2008	Hollywood Trash	0	\N	3	554	\N	0b0315d9-a367-4284-a900-15aca2f7212d
2009	Ready to Strike	0	\N	3	554	\N	0bc873e0-f256-4c7b-90de-793c8a5eddc3
2010	II	0	\N	3	554	\N	22846c98-b0c6-4218-9c91-abea8709d82d
2011	King Kobra Ⅲ	0	\N	3	554	\N	5bfac3b7-4b33-4858-8606-261f31107a69
2012	Thrill of a Lifetime	0	\N	3	554	\N	7030fabd-ebe8-4897-a3c2-a3be2c10d432
2013	The Lost Years	0	\N	3	554	\N	a661319a-af47-4f7a-9ead-7a4c1f9c9284
2014	Thrill of a Lifetime	0	\N	3	554	\N	d045dc02-3784-4d37-9527-bbb411782e4b
2015	King Kobra	0	\N	3	554	\N	f020fdd6-53a5-4ccc-ac25-016412111213
2016	Dancing in the Moonlight	0	\N	3	555	\N	bf591a71-0149-4e04-8425-92326347c3ca
2017	The Big Bang	0	\N	3	556	\N	3a2438c8-989f-48fa-b184-b1b93b7059ca
2018	Funny Farm	0	\N	3	556	\N	4875bab6-cb38-30ca-99ce-5427cb466e8b
2019	Breeding Ground	0	\N	3	556	\N	5cd64980-c1a1-4630-8482-f99851b61d77
2020	Funny Farm	0	\N	3	556	\N	745eeb08-4360-30d5-947c-2f8aa54bbeb9
2021	Funny Farm	0	\N	3	556	\N	810e34e8-132d-49a0-be17-180ff9655036
2022	Me Hungry	0	\N	3	556	\N	d1ccdcf1-648a-4ce8-80af-8ccd1f243d01
2023	The Return of El Santo	0	\N	3	557	\N	0201ec62-7640-445f-b7a8-cf2fa487f0ba
2024	King Changó	0	\N	3	557	\N	27da4e91-f4ee-3d7f-84fc-5975e2838686
2025	King Changó	0	\N	3	557	\N	ba0196ac-0b9c-491b-a154-ebde36b49e39
2026	King James	0	\N	3	559	\N	37766900-48c4-4f16-82ab-89f0e24ad43d
2027	The Fall	0	\N	3	559	\N	a6b1a95b-1d1e-4ca8-815f-2f6f3bbd9d9e
2028	Finger Snaps and Gun Claps	0	\N	3	560	\N	005c92fb-5a9b-4a33-8438-5c9c98ce5583
2029	The Great Man Theory	0	\N	3	560	\N	7f84ae94-effd-4b08-819a-6401fb477702
2030	Secret Sauce	0	\N	3	561	\N	4d070dce-0456-4d56-81d6-d491db3c3f32
2031	Ruder, Better, Faster, Stronger	0	\N	3	562	\N	ce9fc8d7-a360-44d9-be2b-4d9dee021a00
2032	King Sparrow	0	\N	3	563	\N	e7f6098b-017c-4566-bf0b-4274a75b735f
2033	Memoirs of a Murderer	0	\N	3	566	\N	07667c3e-1caf-4832-80ca-7a2c01279e9a
2034	Memoirs of a Murderer	0	\N	3	566	\N	8bbaf0c6-9cdb-47e2-b2c1-b0660b33000f
2035	2009-04-29: Horseshoe Tavern, Toronto, ON, Canada	0	\N	3	568	\N	38324301-6ab4-4e4b-b2a4-de1e1d491e9e
2036	Elvis Perkins in Dearland	0	\N	3	568	\N	5c4004d0-6a6b-4846-b8c0-d04b2cd43b6c
2037	Elvis Is Back!	0	\N	3	569	\N	023c609b-2ccd-46fe-bb86-762e4b3a7fce
2038	His Hand in Mine	0	\N	3	569	\N	20a6f7ad-4634-4152-9bb0-69dffcaa7678
2039	It Happened at the World's Fair	0	\N	3	569	\N	262114e0-ced8-4df4-b399-2b7d5206c2e9
2040	No.2	0	\N	3	569	\N	2cf5e496-1aa4-4df8-a6c7-0182ec30b745
2041	Something for Everybody	0	\N	3	569	\N	368c3a62-977e-4ce4-ae59-cbb6c78f624e
2042	King Creole	0	\N	3	569	\N	4fe4e745-7ce5-43c6-9401-a036b66e45db
2043	G.I. Blues	0	\N	3	569	\N	513bc85d-e955-4ec7-9415-eb6972af47bf
2044	Blue Hawaii	0	\N	3	569	\N	551061cb-f598-41e9-9ecb-380e7f5d405f
2045	A Date With Elvis	0	\N	3	569	\N	5e5366ce-dff0-48e6-ab21-f6e514c2fd04
2046	Elvis' Golden Records	0	\N	3	569	\N	600f025a-bca9-4645-92ea-d15c89044f57
2047	Fun in Acapulco	0	\N	3	569	\N	660b05b6-883a-4d1f-a389-7393d0817a7a
2048	Blue Hawaii	0	\N	3	569	\N	6f5eec7b-3c43-43f5-9a0c-c68b158c940b
2049	50,000,000 Elvis Fans Can’t Be Wrong: Elvis’ Gold Records, Volume 2	0	\N	3	569	\N	739a5589-a0d0-4dab-bcc8-f3a74fd682cb
2050	G.I. Blues	0	\N	3	569	\N	7719bf03-f742-4e83-b0bb-d87aed5c6f91
2051	Elvis Is Back!	0	\N	3	569	\N	818b1b7d-0ee8-4840-a7b7-7ec9bd457071
2052	Pot Luck	0	\N	3	569	\N	842fd270-a0de-4d5f-964a-59e92923261f
2053	Elvis' Golden Records, Volume 3	0	\N	3	569	\N	876d8b53-678e-4449-a87d-6bead9444cf4
2054	Kissin' Cousins	0	\N	3	569	\N	8993d3f8-d567-48da-a1fd-eb354f0c4383
2055	Elvis’ Christmas Album	0	\N	3	569	\N	90673f6b-8306-4663-93d9-eb2c40c4356e
2056	Elvis Presley	0	\N	3	569	\N	a511fc89-91ff-4b4e-8ecc-cfcbc39d2ad6
2057	Girls! Girls! Girls!	0	\N	3	569	\N	a60ad2e8-fe3a-441c-8ed0-9769d451631d
2058	Loving You	0	\N	3	569	\N	b07ee81a-3e84-446e-a22c-7c2141fd1f3d
2059	Elvis	0	\N	3	569	\N	b699b9da-adc3-49e2-9473-58bf54ffdbed
2060	G.I. Blues	0	\N	3	569	\N	c2ae5cb7-c9b0-4390-8ea9-a6c5c1be37cc
2061	For LP Fans Only	0	\N	3	569	\N	f43f3c62-308e-4249-9a69-13db2f7b7c4d
2062	Ash Wednesday	0	\N	3	571	\N	27157703-90b5-31d6-8046-fb0e574704f7
2063	Ash Wednesday	0	\N	3	571	\N	9678c0ae-c307-44c2-9847-7ce0472e88e7
2064	Ash Wednesday	0	\N	3	571	\N	c40735d9-f565-437d-8bd8-744414bb9507
2065	I Aubade	0	\N	3	571	\N	ddd8c07b-9fa7-4543-8b08-882050895426
2066	Bài Tango cho em	0	\N	3	572	\N	038e8ee8-b2bf-4116-a1b0-28a286257ef8
2067	Chút ân tình mong manh	0	\N	3	572	\N	65cd8d46-22ad-4d5c-b6d0-8819cbc9880b
2068	Save the Planet Kill Yourself	0	\N	3	574	\N	14e75bee-1677-4956-85a8-9421802337ee
2069	Goner	0	\N	3	574	\N	362423e9-fad1-4cef-9ed4-29dc5810a95b
2070	hotter sadness	0	\N	3	574	\N	7e9184a9-1f31-4bd8-a61c-748cdfd8e290
2071	Mickey's Dead	0	\N	3	574	\N	84f78bed-a4d1-4987-b468-0356f21527ad
2072	New Alhambra	0	\N	3	574	\N	e5ca84aa-7a8b-4ec6-b1a2-12cdcad81762
2073	Go Home and Practice	0	\N	3	575	\N	258b1d82-cc51-4a77-88d3-c2bc7b29b3db
2074	Summer Edition	0	\N	3	575	\N	26e7f408-ed73-461b-bcbe-5f5c143a4a78
2075	Radio Unfriendly	0	\N	3	575	\N	3c7f0f2a-5807-4c96-a02c-66faf327150d
2076	Move Your Feet It's One O'Clock!	0	\N	3	575	\N	84ab7df8-26f6-49b1-9994-37fdd0f93d2a
2077	Against the Gravity	0	\N	3	575	\N	a3642c29-fe7a-4c26-844a-929a5d25ed0f
2078	Move Your Feet It's One O'Clock!	0	\N	3	575	\N	c9ce552e-01f9-421b-9ac2-eadd281fb712
2079	Hellbilly	0	\N	3	576	\N	1c819766-6468-4f46-aa96-00b855bea1c6
2080	Supersadomasochisticexpialidocious	0	\N	3	576	\N	66a0d175-12c8-40ad-a5bc-9c598c3bfc46
2081	Disgraceland	0	\N	3	576	\N	9728cbf5-24ab-4d11-aebc-8aca1bc27fa9
2082	We Are Not All Civilians	0	\N	3	577	\N	4f4eefa3-9e7e-49a8-b6d7-9a2359888d03
2083	Observe	0	\N	3	580	\N	8594b110-4dbd-4b3b-9ebb-2bbe06e987bb
2084	Velvet Elvis	0	\N	3	581	\N	1176e9c7-b5b7-4233-8b46-e343fb110535
2085	The Story so Far	0	\N	3	582	\N	310d2303-65d7-4b40-bf79-30d80d063916
2086	Crows Eat the Eyes From the Leviathans Carcass	0	\N	3	592	\N	1b2e1d4d-5e4a-4252-9fb4-152be0785697
2087	Bourtanger Moor	0	\N	3	592	\N	25666209-818e-4a0d-a26e-df7297f2bf94
2088	Planned Obsolescence / Obsolete	0	\N	3	592	\N	41efb949-2207-43f9-bf3c-05ac19109f10
2089	Blue Sabbath Black Cheer Pig Heart Transplant	0	\N	3	592	\N	4a7f4b9f-9a26-455e-ae98-fd01fa139892
2090	Bacteria Cult / Juhyo / Blue Sabbath Black Cheer	0	\N	3	592	\N	6372784a-001f-4752-916f-396f1f8d1fbd
2091	Mutually Assured Destruction, Part 1	0	\N	3	592	\N	80ca713f-ea94-4a2e-bfb0-a355acef73e4
2092	Doom Mantra	0	\N	3	592	\N	8490a44d-98f2-4380-8bd4-95f17a76b449
2093	For the Sickly Weaklings	0	\N	3	592	\N	99ef8b58-2d3c-43cb-aef8-42b3371c91b8
2094	Drowning Witches	0	\N	3	592	\N	dd528b06-0d2f-4cf7-b6fc-36c15cd8817a
2095	We Sold Our Soul for Rock 'n' Roll	0	\N	3	593	\N	002e0056-22a5-45c6-9804-6e3eab21e660
2096	Black Sabbath	0	\N	3	593	\N	069dc077-63e4-3ee8-903b-0dd53cf555bf
2097	Master of Reality	0	\N	3	593	\N	069e6e08-a1cf-4b94-bf1d-4acbe9473d49
2098	Paranoid	0	\N	3	593	\N	24d8c603-5262-31f0-96d2-531264117882
2099	Vol 4	0	\N	3	593	\N	257c6df7-26b8-4283-908a-3e625e41cdbe
2100	Wicked Wichita	0	\N	3	593	\N	3542c0e3-7b6b-49d5-bf0d-78148be46362
2101	Master of Reality	0	\N	3	593	\N	380913e2-bedb-4c62-a0cc-fab3c829a25c
2102	Master of Reality	0	\N	3	593	\N	45dca66f-6bed-4657-84ec-92a33cdf60fb
2103	Sabotage	0	\N	3	593	\N	49841934-b0e5-4dd2-b876-a0db0544a983
2104	Sabotage	0	\N	3	593	\N	5050e4d2-eda4-4d4d-a61b-be2a4d278d90
2105	Black Sabbath	0	\N	3	593	\N	6b52eae0-6de5-4b9f-b8d5-60632e84967c
2106	Sabbath Bloody Sabbath	0	\N	3	593	\N	78528b20-76de-304e-bac1-dec2ad995af2
2107	Black Sabbath	0	\N	3	593	\N	7bf735e8-d0aa-35b7-8e05-e1487ed17976
2108	Black Sabbath	0	\N	3	593	\N	8f4c556f-136a-47f6-9b05-3fcd957ee133
2109	Sabbath Bloody Sabbath	0	\N	3	593	\N	9a28f195-b7e7-3c63-be83-f6b4bf843a13
2110	Gr'ndlepol	0	\N	3	593	\N	a04cf2d7-2649-4c28-8ccf-238cc0e07dcd
2111	Master of Reality	0	\N	3	593	\N	ad6c6b58-23bd-471d-bafa-bf0e2b3f2636
2112	Sabotage	0	\N	3	593	\N	ad9d1798-e8b1-4211-a1a7-b999f6053e04
2113	Paranoid	0	\N	3	593	\N	bd3fea7a-81bd-49c0-bd3e-78f5235f1e4d
2114	Paranoid	0	\N	3	593	\N	d820f080-845a-4525-8e46-087ce9f8cdda
2115	Vol 4	0	\N	3	593	\N	e2f1366f-a112-45d2-84d3-db03ba5d4003
2116	Paranoid	0	\N	3	593	\N	e4279c51-62cb-3f62-a2e8-13e75e426fa1
2117	Master of Reality	0	\N	3	593	\N	ee44b6b8-dc9c-4545-b911-64c0b9ef10ad
2118	Paranoid	0	\N	3	593	\N	f001da3c-0b60-4938-b8bb-28b365dc4a75
2119	Sabbath Bloody Sabbath	0	\N	3	593	\N	fc198cf1-2c42-4f69-98c5-da2db23f7f98
2120	Eno ot Derotser	0	\N	3	595	\N	023b138d-2106-4550-92fb-4ec23c2ffefe
2121	Restored to One	0	\N	3	595	\N	0c4b8c87-583a-4112-9aff-b5f069a8fb49
2122	Restored to One	0	\N	3	595	\N	13082fba-4863-4f3c-9716-a3a8c823e767
2123	Sabbath Assembly	0	\N	3	595	\N	33092ceb-4767-4598-a390-682fcbedd5f5
2124	Ye Are Gods	0	\N	3	595	\N	5923e96b-8779-433b-a5b3-1f81b7235098
2125	Sabbath Assembly	0	\N	3	595	\N	7bb62b85-9179-4c87-afa2-4b17f5da3491
2126	Eno ot Derotser	0	\N	3	595	\N	81da1700-c471-4edd-99a5-51c5956a7e17
2127	Sabbath Assembly	0	\N	3	595	\N	a88f92b6-039c-4474-9b04-d3a52a3882f6
2128	Restored to One	0	\N	3	595	\N	b2c77017-d9a4-47fa-a7be-cc6632655489
2129	Quaternity	0	\N	3	595	\N	b6bf363b-de63-447c-9fa7-f5e18b029e03
2130	Ye Are Gods	0	\N	3	595	\N	fb459988-c4f6-4511-b071-71e911e4aab8
2131	Bar Slut	0	\N	3	596	\N	26e6f41a-63c3-4904-a5a9-3c58d266b2f3
2132	New World Plague	0	\N	3	598	\N	b719c14e-bdfc-49c4-a4f0-15ce98e8bb1e
2133	Brownout presents Brown Sabbath	0	\N	3	600	\N	5d346d92-b036-4637-8c83-5fd28c3f2196
2134	Brownout presents Brown Sabbath	0	\N	3	600	\N	bf5c3d07-babf-4d98-bddc-5689998f8496
2135	1986: Live in Heaven, Germany	0	\N	3	601	\N	0984367a-c6ad-4c64-a0ea-20a604fba8f5
2136	The Rich Man's Eight Track Tape	0	\N	3	601	\N	1447a79a-48c7-3707-aede-fd077125a197
2137	The Rich Man's Eight Track Tape	0	\N	3	601	\N	35824175-9451-39f7-9ad4-01a21dffd747
2138	Songs About Fucking	0	\N	3	601	\N	3a305ccf-b31e-347c-b139-9968282836e7
2139	Atomizer	0	\N	3	601	\N	4791aa3f-5c12-439f-9262-8d938af9a213
2140	Pig Pile	0	\N	3	601	\N	48accb03-51a8-34d7-8fd4-2360201dc4cf
2141	Songs About Fucking	0	\N	3	601	\N	4a89a2f8-f139-41d9-abb9-f1e553c7b030
2142	The Rich Man's Eight Track Tape	0	\N	3	601	\N	556979be-9568-337b-9c05-935783f64506
2143	1987-07-25: Death Wish: Manchester, UK	0	\N	3	601	\N	5783b683-0c71-455f-9b44-cf6f3302413d
2144	Songs About Fucking	0	\N	3	601	\N	675cb634-11b8-43b0-bfdd-afe632d43645
2145	Atomizer	0	\N	3	601	\N	6be884d7-d459-30ef-8616-7b9b8d0294fd
2146	The Rich Man's Eight Track Tape	0	\N	3	601	\N	70ac600d-f522-4858-8caf-74cea4ebfdf6
2147	Pig Pile	0	\N	3	601	\N	75ed1436-5344-4303-8cf6-19560d476e3b
2148	Songs About Fucking	0	\N	3	601	\N	843d0653-f15d-3d62-befc-ccc951e0db48
2149	Atomizer	0	\N	3	601	\N	a3442347-3e3d-3705-bae9-42c48d5b575c
2150	The Hammer Party	0	\N	3	601	\N	aa9c6b27-1843-4344-9300-2599faa4d88b
2151	Pig Pile	0	\N	3	601	\N	b008258a-fd8f-46e1-ba4c-4cab882aed6a
2152	Songs About Fucking	0	\N	3	601	\N	b5b20fe0-8a23-4b28-8adc-1d43752e904b
2153	Sound of Impact	0	\N	3	601	\N	c4304d7d-cd38-48f0-990f-de3557ff0c51
2154	Atomizer	0	\N	3	601	\N	d852becd-feba-4ce6-83c1-2970deddf906
2155	Sound of Impact	0	\N	3	601	\N	dc713ed8-89af-4491-823e-4b4549c4eece
2156	Atomizer	0	\N	3	601	\N	ed007f01-f804-39bc-b980-09ac36dd5f73
2157	The Hammer Party	0	\N	3	601	\N	f529290f-1a9d-3e81-97d0-088331f9ca6e
2158	Damaged	0	\N	3	602	\N	136a731b-8515-4023-9cca-722e6de4cf60
2159	In My Head	0	\N	3	602	\N	146db5c3-a7d6-42a0-bfbf-19b341f2972b
2160	What The...	0	\N	3	602	\N	1bdb7ebf-7616-4204-b864-6025cf2613d5
2161	Everything Went Black	0	\N	3	602	\N	22be5654-6142-491b-8504-2b0402ec1886
2162	The First Four Years	0	\N	3	602	\N	2615d3bf-a63f-4f35-ab48-9e22f7de100b
2163	Family Man	0	\N	3	602	\N	29888d56-d9f0-41d3-b77c-b42f46200d14
2164	Damaged / Jealous Again	0	\N	3	602	\N	41952c46-87c3-45c3-a4c5-a04cf6fb6d8e
2165	Everything Went Black	0	\N	3	602	\N	4a16d875-af74-3a72-bfca-2968098fdd99
2166	My War	0	\N	3	602	\N	5b63bc38-4819-304f-913e-ef0d5332d079
2167	The First Four Years	0	\N	3	602	\N	832e2ea3-13fb-3bb5-b928-f08a3eab2806
2168	Live '84	0	\N	3	602	\N	8ef9d0c7-3926-480d-99f6-1ebb87f6daf9
2169	Damaged	0	\N	3	602	\N	a3b1d148-d444-3f6a-84a6-add7c21b698d
2170	Slip It In	0	\N	3	602	\N	a6b9cba2-c995-43ee-b980-371a7fe91f6f
2171	Wasted Again	0	\N	3	602	\N	b25cbc8b-d4be-45f1-ab37-3e4341a33aee
2172	Loose Nut	0	\N	3	602	\N	bcd918ec-55aa-4c63-bc3d-49f54c50134b
2173	Damaged	0	\N	3	602	\N	beb5dfa5-355e-4fe6-9cd5-aadca1cb98d2
2174	My War	0	\N	3	602	\N	c41b896c-53eb-4551-be48-ae48c1289396
2175	In My Head	0	\N	3	602	\N	d1050ce1-b246-4fd5-9bd1-ec3c56473243
2176	What The...	0	\N	3	602	\N	d4a23183-b7d6-4771-a955-18c8ce43f1b0
2177	Damaged	0	\N	3	602	\N	d718298d-3b67-4538-8067-657058f4cfd0
2178	Who's Got the 10½?	0	\N	3	602	\N	dcaf0cab-da06-4ea7-86b5-66f0e9996bec
2179	Family Man	0	\N	3	602	\N	e071f8a7-5f2b-422f-8dfe-bd94b0f1b01e
2180	My War	0	\N	3	602	\N	e9ab350c-baea-4ef2-ad1a-ab65d3c13802
2181	The First Four Years	0	\N	3	602	\N	f9da70fd-88c3-36b4-b2b1-e504217f54cc
2182	Slip It In	0	\N	3	602	\N	fc00d3b3-dae6-4bec-8523-ea4a001a2d9d
2183	From the Black Pool of Genius	0	\N	3	603	\N	029f761d-c660-41c0-b4fd-f355f1bd0989
2184	A Wolf in Sheep’s Clothing	0	\N	3	603	\N	3c575b09-1bb5-4285-b738-1d0b97a3d17f
2185	Non-Fiction	0	\N	3	603	\N	3e065d1b-f688-47ee-a8f7-a419e0b89123
2186	8WM/Novakane	0	\N	3	603	\N	5d09acdc-06c2-43e9-a311-387c1eb64ba3
2187	A Wolf in Sheep’s Clothing	0	\N	3	603	\N	c0f8c76d-8a06-38c5-a26c-29c50fc0196b
2188	Love Is Love (Mixed by Bazooka Joe)	0	\N	3	603	\N	c2489a59-9fbf-496a-b755-f72407a353cd
2189	A Wolf in Sheep’s Clothing	0	\N	3	603	\N	cfa6513e-6f88-40eb-9016-6909b3144cc2
2190	A Wolf in Sheep’s Clothing	0	\N	3	603	\N	dad2bb56-11c6-4100-bcdb-c764056dfde1
2191	A Wolf in Sheep’s Clothing	0	\N	3	603	\N	dad56b0a-69d8-4eab-9931-2cdc09b5edd6
2192	Non-Fiction	0	\N	3	603	\N	f1374d07-2894-4ace-8fdd-6fdb01823be0
2193	Diggin' in Dah Vaults	0	\N	3	604	\N	1e325156-444b-4020-bf64-3b5dddb9ec66
2194	War Zone	0	\N	3	604	\N	56cfeb8c-e3d0-4351-91f7-73b582610210
2195	Enta da Stage	0	\N	3	604	\N	67bf4f85-0a36-4e17-8d9a-f404aaa9d235
2196	Enta da Stage	0	\N	3	604	\N	77fad998-2e9b-4e4f-a960-1c5b9d2a7b34
2197	Total Eclipse	0	\N	3	604	\N	98bdca15-b967-49de-956b-ba1dbe729719
2198	War Zone	0	\N	3	604	\N	d095f20e-001a-4606-95ff-821795b9edec
2199	Alter the Chemistry	0	\N	3	604	\N	f4066d32-e87f-4ce1-b508-6de2e22292ec
2200	War Zone	0	\N	3	604	\N	fdf72241-ce29-4bcd-9577-35696fb476a2
2201	1989-1999: Ten Bloody Years of Black 47	0	\N	3	605	\N	02c90dcb-4330-4e89-ab07-a7a24ee9f3af
2202	Iraq	0	\N	3	605	\N	33986255-9424-49d1-933f-b0644462ac8a
2204	Live in New York City	0	\N	3	605	\N	7b0b91ed-127d-47b0-a868-c6728fac4538
2205	Bittersweet Sixteen	0	\N	3	605	\N	89ec5c29-e440-4506-9d05-35b53b488b33
2206	Elvis Murphy's Green Suede Shoes	0	\N	3	605	\N	97dc38f1-0bc0-4587-b65b-e890759884ab
2207	Black 47	0	\N	3	605	\N	a7334e53-9217-49a9-b6ad-0f95676ef872
2208	Black 47	0	\N	3	605	\N	a9d66c9f-1b39-49f1-8612-163075a6af44
2209	Trouble in the Land	0	\N	3	605	\N	b30db545-cccb-4fcf-aff8-7828b1c9fa9e
2210	Green Suede Shoes	0	\N	3	605	\N	bd414b69-8349-432a-998a-b86c5321b4ef
2211	Bankers & Gangsters	0	\N	3	605	\N	d198c7c9-9a80-48d7-8f69-7d4acf015d48
2212	Fire of Freedom	0	\N	3	605	\N	e967538f-7828-4865-b111-544df1ddafb0
2213	On Fire	0	\N	3	605	\N	ec9eb529-276b-4b85-bd45-07b0388a69d3
2214	Home of the Brave	0	\N	3	605	\N	fc41d0ba-fadc-45ac-95d3-c138d9c7fccd
2215	Give Us Sugar: B-Sides Demos & Soundtrax	0	\N	3	606	\N	07016076-4bbe-4241-88d2-08cfe32f2cdc
2216	Your Body Above Me (Director's Cut)	0	\N	3	606	\N	1accd8c9-e927-4124-8571-25b6ce469c76
2217	Passion Leaves a Trace	0	\N	3	606	\N	31c84764-8e67-43c2-a2e4-140567c70d2d
2218	Your Body Above Me	0	\N	3	606	\N	37960ca2-3de0-4bcb-99b4-d411b6055411
2219	A Raven Has My Heart	0	\N	3	606	\N	43407695-ecdc-4e3b-91ce-4ef8fbe6a66f
2220	Your Body Above Me	0	\N	3	606	\N	511007cf-7328-4179-a89b-8e5ca558dd95
2221	Two Strangers	0	\N	3	606	\N	592cdffb-7df3-476a-a58e-cab70f8fb6f3
2222	Technologie	0	\N	3	606	\N	a4872d82-e1b7-448b-9e0a-fc32faa1443d
2223	See the Sun	0	\N	3	606	\N	bdf78e1a-673f-47ac-b3d5-9df224833b10
2224	Passion Leaves a Trace	0	\N	3	606	\N	d1ace823-c982-4b9c-b899-e4d8e2fe9ed2
2225	Unplugged	0	\N	3	606	\N	fa20805c-0284-4b3b-96ed-6b067e5e819c
2226	Mos Def & Talib Kweli Are Black Star	0	\N	3	607	\N	66df81d2-9787-3838-85fa-fa0de57990f3
2227	Three Definition (Hosted by DJ Lt. Dan)	0	\N	3	607	\N	76b3715f-d272-4cf6-a1ab-cf6f3230542b
2228	Mos Def & Talib Kweli Are Black Star	0	\N	3	607	\N	8d2645c7-8576-47ee-8827-80a887646fd8
2229	Redeem	0	\N	3	610	\N	885e100a-796c-4df9-bc7f-129d3b98b512
2230	Enrapture	0	\N	3	610	\N	fabbffae-dca3-43df-8a35-227d2e5c0075
2231	Tears of Blood (bonus disc)	0	\N	3	612	\N	0404b403-c53f-41c6-b980-3b3a2b7df8b2
2232	Tears of Blood	0	\N	3	612	\N	9a6eb48d-6122-4578-a031-1d7db08aa8fa
2233	Black Symphony	0	\N	3	612	\N	c3887e67-bc9c-3d83-85ae-d86891d4fb20
2234	Black Symphony	0	\N	3	612	\N	c45615df-9e65-4ef2-b2aa-acc0e78d98c3
2235	Black Tambourine	0	\N	3	613	\N	14cc25ef-24ed-4228-843f-9cabcb163636
2236	Black Tambourine	0	\N	3	613	\N	6541a365-b131-4e75-a434-ec5d4f402ba8
2237	Black Tambourine	0	\N	3	613	\N	a319e0e2-4801-407c-9c90-9709c32bb97e
2238	Black Tambourine	0	\N	3	613	\N	b7df8fa5-c29d-4048-8390-905b4561bddf
2239	Black Tambourine	0	\N	3	613	\N	e0754577-78fe-40e0-9b1e-71ef9d370c3f
2240	Complete Recordings	0	\N	3	613	\N	eeab25ca-5a8e-4fc7-bb2f-2af24b562fe1
2241	Complete Recordings	0	\N	3	613	\N	f250432d-e50a-4456-ab12-e41c69ae9fd0
2242	Stops a Beating Heart	0	\N	3	614	\N	5a0760d1-2dde-46ce-8bc3-3d3254476701
2243	No Time to Burn	0	\N	3	615	\N	083a431f-3578-4603-806e-08916930e883
2244	Keep On Runnin'	0	\N	3	615	\N	29fa4167-4411-4cb1-bce5-f0893f947dbb
2245	Black Heat	0	\N	3	615	\N	671f1a89-dfa3-4214-b730-f378dd957c4a
2246	Deuce	0	\N	3	616	\N	05f66b62-084b-4825-93af-95aa84423cac
2247	Deuce	0	\N	3	616	\N	1695dfb5-7195-4f23-bc41-87ae8e329dac
2248	Deuce	0	\N	3	616	\N	9262d5cc-8454-40c8-b45f-e4baef8e2658
2249	Black Nasa	0	\N	3	616	\N	b0614434-ecc5-45a5-a8b3-a800b7289287
2250	Deuce	0	\N	3	616	\N	d53682dc-bf3a-4874-9142-37eb83f5b47a
2251	Repeater	0	\N	3	617	\N	00baa173-29db-33a9-af6d-fe109e53a211
2252	The Argument	0	\N	3	617	\N	0e789eca-d5e5-469f-8648-9fe5c1ca68a9
2253	Repeater + 3 Songs	0	\N	3	617	\N	0ef1e5ad-33e1-3b27-8f02-ab790da70c85
2254	Red Medicine	0	\N	3	617	\N	1f62d07a-ff81-469f-ba61-1e7083055be2
2255	End Hits	0	\N	3	617	\N	27081b72-3dd6-4c1b-908c-d4151d7f9a75
2256	In on the Kill Taker	0	\N	3	617	\N	35704cbf-172f-30b9-b182-824eb9da6342
2257	End Hits	0	\N	3	617	\N	3c1d5669-ae58-33db-b98d-ef346b55acc7
2258	13 Songs	0	\N	3	617	\N	5f692216-1932-4cfa-ad6e-0e3c2304579f
2259	In on the Kill Taker	0	\N	3	617	\N	61ff02c0-f2a2-4751-8d6a-01a575b47b6c
2260	13 Songs	0	\N	3	617	\N	6f426cdf-6f8c-305f-92a3-4d9b551d8f31
2261	Red Medicine	0	\N	3	617	\N	7650d01d-ac63-3297-90a2-3e07eab18d4a
2262	Red Medicine	0	\N	3	617	\N	8ab4cc46-80e3-4090-bc04-a93c5cae54e4
2263	Steady Diet of Nothing	0	\N	3	617	\N	975991e7-41b6-4ada-965d-13c603db5dba
2264	In on the Kill Taker	0	\N	3	617	\N	9f67fda2-0bba-42ad-90c5-c1ee3614324c
2265	End Hits	0	\N	3	617	\N	ab275d55-3a35-4b21-9952-096fe692864d
2266	Repeater + 3 Songs	0	\N	3	617	\N	abc22131-315b-409d-8a8d-ed88f688fad4
2267	Repeater	0	\N	3	617	\N	b92a919e-6284-3849-bd8e-0e63d5b9e1a5
2268	Repeater	0	\N	3	617	\N	ba7338bd-58d5-46cf-b015-255b7491674b
2269	Instrument Soundtrack	0	\N	3	617	\N	c2b99ec3-2761-4874-bd22-8890ef358119
2270	Steady Diet of Nothing	0	\N	3	617	\N	cb1eec0c-50ec-3b1d-a432-7bd89605ece5
2271	Steady Diet of Nothing	0	\N	3	617	\N	deb8b340-8a6d-4416-8eb9-e4c7fa5d00e6
2272	Stage Dive Masters	0	\N	3	617	\N	e78e2f70-6beb-42e2-9f2a-c64a2f65afee
2273	First Demo	0	\N	3	617	\N	e93c6887-f71e-4feb-b05a-8ca49407891d
2274	Red Medicine	0	\N	3	617	\N	f6266c4b-ff11-4f6a-89f9-c9ece70d4e86
2275	The Argument	0	\N	3	617	\N	ff6225b3-2e83-494e-8605-e6b057a4eefe
2276	Money Feeds My Music Machine	0	\N	3	618	\N	b5c58706-7fca-4729-a1c2-94f05f63d5d1
2277	Tattoo of Blood	0	\N	3	618	\N	d271e565-0b1b-4ba6-a160-199f0f2cae27
2278	Gabardine	0	\N	3	619	\N	0d6f67c5-42bd-4359-84a7-8f2d4cac4e7a
2279	Ice Cycles	0	\N	3	620	\N	0d42d8c0-2638-43e9-b8cc-5bffb8e1803a
2280	When Pus Comes to Shove	0	\N	3	620	\N	0e346717-2ea9-4154-b402-bc8e7156e47f
2281	Ice Cycles	0	\N	3	620	\N	f16d8420-2cf7-465f-bbfc-cd218b241828
2282	Battle Cry	0	\N	3	621	\N	0d967a04-d537-4536-a666-2133d619a63a
2283	Eternal Black Dawn	0	\N	3	621	\N	16510a91-8bdb-4c67-a571-343f6032ccc6
2284	The Curse	0	\N	3	621	\N	34af0619-c868-4b1f-963b-772eb8f6ba43
2285	The Best of Omen: Teeth of the Hydra	0	\N	3	621	\N	44e4050d-9970-47d0-87dd-abfa44702090
2286	Reopening the Gates	0	\N	3	621	\N	4de146dd-fb10-419b-920c-b03f606eb100
2287	The Curse / Nightmares	0	\N	3	621	\N	5795757f-7aec-4cd1-bb14-556f73ce8bfd
2288	Battle Cry	0	\N	3	621	\N	59fa2c92-e673-449c-99f6-f5f4722f9e51
2289	Escape to Nowhere	0	\N	3	621	\N	5b8354b2-5e46-4156-8244-7a0cfbf01808
2290	Warning of Danger	0	\N	3	621	\N	6a31bd9c-8061-49aa-9627-790b78f52013
2291	Omen	0	\N	3	621	\N	c8960718-4a27-4011-9160-fd455ca8eedc
2292	Warning of Danger	0	\N	3	621	\N	ff6e21bd-ab71-4753-8536-ed3f65ef959c
2293	Right Between the Eyes	0	\N	3	622	\N	236135fb-f70f-4697-abb4-909c878c142d
2294	Icon	0	\N	3	622	\N	2da3b899-5864-4f95-9196-f121fb4d7cc8
2295	Night of the Crime	0	\N	3	622	\N	44291b31-da72-40f1-984f-40262e44e01f
2296	An Even More Perfect Union	0	\N	3	622	\N	c5d94643-576d-49ec-afea-30dccccaa482
2297	Caught Live	0	\N	3	623	\N	34ccae6e-5dea-4449-9a8f-f5ce326e1cd2
2298	Buick Men	0	\N	3	623	\N	5ef35e40-f4f2-4362-8ce4-ff5c291ccf86
2299	That Was Then, This Is Then	0	\N	3	623	\N	73d5b57e-5b01-4dfa-b625-fec289e2ad66
2300	Hagfish	0	\N	3	623	\N	830b9967-78aa-489d-b0d6-0438723aba70
2301	...Rocks Your Lame Ass	0	\N	3	623	\N	9102159d-8bf3-463f-b40e-b9e781605099
2302	...Rocks Your Lame Ass	0	\N	3	623	\N	97aea143-d742-473e-8f32-20015350f09e
2303	Simple Pleasures, The English Country Dance Collection Volume 3	0	\N	3	625	\N	011721a1-f3ca-4b51-af26-3506ff7ccf87
2304	Take a Dance	0	\N	3	625	\N	1d1ad180-55ec-4ef4-9cb7-d69020c53eec
2305	English Country Dances	0	\N	3	625	\N	1d537ea3-fb21-4255-a5d7-7914ffacb89c
2306	Nightcap	0	\N	3	625	\N	b2e1714f-b5d9-4f05-85cf-33ce81f458be
2307	Golden Rogues Collection	0	\N	3	626	\N	6b82c068-fb64-4cef-ba95-8312771c0e5b
2308	Mr. Downchild	0	\N	3	626	\N	ca1ef07a-6ab4-48a7-8bc6-e8fbf97f4cea
2309	A Bridge Too Fuckin' Far	0	\N	3	626	\N	fc978bb6-5a99-42b3-b04d-5758941cb549
2310	Five-Year Diary 1996-2000	0	\N	3	627	\N	18aa92b2-9028-4b3c-af5a-21b7b0ea3b94
2311	Exit 263	0	\N	3	627	\N	230adceb-bcd8-4db5-a09c-d5b3037898ff
2312	Fate's Got a Driver	0	\N	3	627	\N	8a88b18b-fd15-4eb5-bb41-4e24cde1e284
2313	The Moon My Saddle	0	\N	3	627	\N	a043487d-1156-4e9f-84c7-83d01b558ca7
2314	The Turning Tide	0	\N	3	628	\N	0d90a6c9-04ad-4f5c-9e01-f8030a91346b
2315	Another Day	0	\N	3	628	\N	1bb01495-461b-400c-93a3-ba7b64bbf001
2316	The Hour Before Dawn	0	\N	3	628	\N	30cda8fa-4b3d-479a-9c30-c497ba6f3fbc
2317	Shamrock City	0	\N	3	628	\N	4981a4d4-fbc4-48f6-80b1-cff5885364a2
2318	Shamrock City	0	\N	3	628	\N	59d061b7-c789-47ed-a7c7-f07457c40e8a
2319	Sunny Spells and Scattered Showers	0	\N	3	628	\N	5e9c58a0-26f3-4fd3-be6c-902d13d9085d
2320	The Words That Remain	0	\N	3	628	\N	a0b2c991-f610-400b-af2c-1cb13d4323e1
2321	The Edge of Silence	0	\N	3	628	\N	a325cd91-7117-47e1-83b4-b8e06647f854
2322	Reunion: A Decade of Solas	0	\N	3	628	\N	a4990fb9-5a46-4ae3-b58d-ec44a04afec6
2323	Solas	0	\N	3	628	\N	ad450d02-7faf-4833-8192-3c8ca5d89452
2324	For Love and Laughter	0	\N	3	628	\N	c0000d50-37f8-4b68-b55f-9b494658e9f2
2325	Live	0	\N	3	628	\N	eabd3d85-3546-4001-be20-cb7953623202
2326	Waiting for an Echo	0	\N	3	628	\N	fa0bdf87-6dae-4162-9165-afbadd9ce60e
2327	Further	0	\N	3	629	\N	124187a5-4df4-4d96-942e-26ee0a2d9b7e
2328	Formless	0	\N	3	629	\N	35f43468-8204-4b38-aac5-8ab6a49672b5
2329	Trace	0	\N	3	629	\N	3d08f7fd-612f-4502-9eaa-4d1bccbd21ea
2330	Live.Traces	0	\N	3	629	\N	5c42119d-ced7-453d-be67-455e5cad8c09
2331	Formless	0	\N	3	629	\N	69ec0567-a739-44c5-8774-52cf6d65106d
2332	Trace	0	\N	3	629	\N	bb40a671-715b-4c61-bbfa-22810badb537
2333	The Synthetic Form	0	\N	3	629	\N	e219b23d-b624-3962-aacf-835b50d86af8
2334	The Synthetic Form	0	\N	3	629	\N	e83ec649-9ede-4c76-b456-631c04768916
2335	5.25	0	\N	3	629	\N	ec074e87-3d36-4fc1-a3a0-c4990f1e9bef
2336	Bullwinkle, Part II	0	\N	3	630	\N	bb4e75f7-a3c0-46c5-89d4-e5f1f99462e8
2337	Surfers' Pajama Party	0	\N	3	630	\N	d1baed4a-2912-45a0-9134-3ee7ef6f06ef
2338	Complete Recorded Works in Chronological Order, Volume 1: 17 February to 12 June 1930	0	\N	3	631	\N	55bdd92e-c6e7-4aa7-b1e5-a797d07d4286
2339	Stop and Listen	0	\N	3	631	\N	b206be3c-26bd-4051-8973-cbbcb4af09f1
2340	Honey Babe Let the Deal Go Down: The Best of Mississippi Sheiks	0	\N	3	631	\N	b3c374fe-fb10-4261-83a2-6308bbfa3832
2341	Complete Recorded Works in Chronological Order, Volume 4: 26 March 1934 to 15 October 1936	0	\N	3	631	\N	c39ea401-c803-476e-b73c-9318802a6a8d
2342	Complete Recorded Works in Chronological Order, Volume 2: 15: December 1930 to 24 October 1931	0	\N	3	631	\N	ca8e095d-bbd6-44c8-b1e6-ce9555a92184
2343	Complete Recorded Works in Chronological Order, Volume 3: 25 October 1931 to 26 March 1934	0	\N	3	631	\N	cdb19f56-fb63-4b49-8ff9-9e0c1dc5dd7f
2344	Stop And Listen	0	\N	3	631	\N	e4740c38-b583-4b1e-9f67-b3fad3561037
2345	Rockin' the Juke Joint Down	0	\N	3	632	\N	694df855-cbbf-37c5-8a0c-c00d8b100c77
2346	Off Yonder Wall	0	\N	3	632	\N	b780b935-72c0-4922-9cd0-f3546cbd9182
2347	Rockin' the Juke Joint Down	0	\N	3	632	\N	eff616b7-940b-47d7-8a4f-861dc13c8b2e
2348	Live at Joe Segal's Jazz Showcase	0	\N	3	633	\N	52ae3abe-fc76-46f6-81d7-3410728775f7
2349	Everyone's Beautiful	0	\N	3	634	\N	16285968-533c-4806-980a-3b979ef17d0b
2350	2010-02-27: Harvest Hands, Nashville, TN, USA	0	\N	3	634	\N	2296f659-f13f-4baf-8519-9c10918bdc75
2351	Live 3.26.03 - Muncie, Indiana	0	\N	3	634	\N	26365456-bfe0-43d7-afea-1f86410627bd
2352	Live at the New Earth	0	\N	3	634	\N	2ab770af-136d-4048-b180-dcb1b28f29ff
2353	Pink & Blue	0	\N	3	634	\N	3c58a20a-ff2a-4779-95b0-d4739057edd2
2354	2010-02-25: The Rutledge, Nashville, TN, USA	0	\N	3	634	\N	48872bde-3764-4fe2-abe9-71629202b594
2355	No Doubt of Sunshine	0	\N	3	634	\N	69aa6a7f-8de4-48e8-851a-3a2bd20a45ef
2356	Cornerstone Music Festival (disc 2)	0	\N	3	634	\N	74e14408-1631-47df-8fad-029104250cfc
2357	In the Middle of It	0	\N	3	634	\N	79a081b1-8616-4f06-903c-4780f69a1fd2
2358	Waterdeep	0	\N	3	634	\N	79d441e9-3d7b-4f33-aefb-f6fed39cc42d
2359	You Are So Good to Me	0	\N	3	634	\N	9fbe12ad-8c92-4a0c-bb4f-f75b83aa1210
2360	Everyone's Little CD	0	\N	3	634	\N	afdff42c-e9bd-46fc-bd61-7be36999ac73
2361	Live at the New Earth	0	\N	3	634	\N	b14e5826-662b-404c-88d4-d2016a31e927
2362	Heart Attack Time Machine	0	\N	3	634	\N	b3b70a67-0e92-47ab-96d9-0941a929f4d8
2363	To Chase Away the Birds	0	\N	3	634	\N	bc4e2963-4343-40c1-a65f-cce1f54eedec
2364	Everyone's Beautiful	0	\N	3	634	\N	d3510760-5768-43d4-b974-4c880c9812ad
2365	Moment	0	\N	3	634	\N	e2822976-aa7b-4b75-958b-e96d17737133
2366	The Collection	0	\N	3	634	\N	e33801ff-2ca5-4027-b547-72c1c6d02e03
2367	Heart Attack Time Machine	0	\N	3	634	\N	e9f93c13-b397-4b01-aa92-ef5858febeb0
2368	Sink or Swim	0	\N	3	634	\N	f4d231b2-eedb-4090-9df4-d8924882d939
2369	Dommedagsnatt	0	\N	3	635	\N	11cd20fc-ba12-4ac1-8cfa-fa2c27bf2f85
2370	Dommedagsnatt	0	\N	3	635	\N	2044b42a-5f19-3f5f-876a-d770ac790f33
2371	Dommedagsnatt	0	\N	3	635	\N	d19b9cd7-f6ad-404b-9018-76ac17bf82a2
2372	These Cats Can Swing!	0	\N	3	636	\N	05444071-44c7-4c59-b719-77da37deeac7
2373	One More Trip to Birdland	0	\N	3	636	\N	11c4eb00-6716-4071-8eb9-43d0f9521fc4
2374	Burn Out at the Hydrogen Bar	0	\N	3	637	\N	2469e015-a48a-34d5-9011-7328e85bd422
2375	Oxidizer: Acucrack Versions	0	\N	3	637	\N	2e5e9f2a-1ebe-4722-b380-a7ddc1d58955
2376	Rock Whore vs. Dance Floor: Unreleased	0	\N	3	637	\N	37e81e22-0df5-4040-b8cd-ddbc116189cd
2377	Oxidizer	0	\N	3	637	\N	397810d5-e399-4d25-b8d8-cb3f0bf6a1e7
2378	Burn Out at the Hydrogen Bar	0	\N	3	637	\N	3f6dc4fd-2504-4631-9a30-68785240cf8a
2379	Rock Whore vs. Dance Floor	0	\N	3	637	\N	57af643a-b19b-4d28-8eb7-e976a2d213fe
2380	Suture	0	\N	3	637	\N	647b7925-c7f4-498c-b06b-f18fc6d94ba2
2381	East Side Militia	0	\N	3	637	\N	8994a2e1-594c-46cf-b93e-41437c76643a
2382	Burn Out at the Hydrogen Bar	0	\N	3	637	\N	a2d99cda-f3fc-3416-9eb7-09dd8c396818
2383	East Side Militia	0	\N	3	637	\N	a39b1648-b46b-4cff-82d8-4faefc42abb1
2384	Burn Out at the Hydrogen Bar	0	\N	3	637	\N	ae944921-a55b-4581-88dd-ba46e9cf3359
2385	Magnetic Field Remixes / 10 Ton Pressure	0	\N	3	637	\N	cfdb5e7d-f8c6-42d9-8bbe-5dfa0d2eaba6
2386	A National Health Care	0	\N	3	638	\N	5c9e2eb4-487d-45e5-a543-4fa4b338b1fb
2387	Black Date	0	\N	3	638	\N	c664bb5d-c478-4225-8133-c4e592af9f99
2388	Complete Discography	0	\N	3	639	\N	00534463-c7c2-4ffd-abc5-6c8de9c1be77
2389	Screaming at the Wall	0	\N	3	639	\N	2b26d737-bb59-4566-bef8-34f874ac6897
2390	Out of Step	0	\N	3	639	\N	507bb61e-c7fa-3dd5-ba2d-d6f0f6e2f792
2391	Complete Discography	0	\N	3	639	\N	65d5b49f-cf1b-3651-9fdd-ed54ce1a9a85
2392	Straight Edge Live 1982	0	\N	3	639	\N	9f0ef806-fb10-4082-84e1-ba28fa2296ed
2393	1982-04-29: 12XU: 9:30 Club, 930 F Street, Washington, DC	0	\N	3	639	\N	ac409a01-000b-48a4-a33f-820cf0371fd4
2394	Sometimes Good Guys Don't Wear White	0	\N	3	639	\N	e4f044bf-df69-433a-83d3-026b16ea254c
2395	Complete Discography	0	\N	3	639	\N	f1143034-fc69-313f-995e-5b11621505b0
2396	For God & Government	0	\N	3	640	\N	357c0b4f-0bec-4626-85f7-8438a2c9507c
2397	Last Dayz	0	\N	3	640	\N	a8201a04-d0ae-4d92-864b-a278e3402690
2398	Now Here Fast	0	\N	3	640	\N	aa20d846-b6ca-4924-b19b-5c75303bf1d7
2399	Now Here Fast	0	\N	3	640	\N	b64031c9-0c6d-4dc9-8c7c-7dc4287f8b08
2400	Many Styles	0	\N	3	642	\N	4513da5b-cb93-44c1-996b-d10548fced3e
2401	Into the Darkness	0	\N	3	643	\N	0352309f-1b2b-446a-a33e-bde6e86a322b
2402	Into the Darkness	0	\N	3	643	\N	37b8ca93-a041-4b7c-aca8-ed845df9e62e
2403	The Heat Death of the Universe	0	\N	3	645	\N	11b8e884-b2de-4f7f-bf5e-0e8db76c9221
2404	Off Minor	0	\N	3	645	\N	2fe01848-fd13-4840-ada5-4ad4bb0c44b7
2405	Off Minor / I Am The Resurrection	0	\N	3	645	\N	3296bc3e-eb0f-4dde-a768-957b24e11229
2406	Some Blood	0	\N	3	645	\N	8a029c66-7cc2-4188-85df-af300a147440
2407	The Heat Death of the Universe	0	\N	3	645	\N	d944483d-1016-4ee5-94e8-0fba396b2c6a
2408	Innominate	0	\N	3	645	\N	f92b8804-472f-484f-96bf-e30ae139f1b4
2409	American Minor	0	\N	3	646	\N	6f1775e0-4995-48ec-8464-2b4f69aa93e6
2410	2006-03-28: Elbo Room, Chicago, IL, USA	0	\N	3	646	\N	dd85cac7-59f8-44c3-a1e1-0609e08cfe5c
2411	The Rising Tied	0	\N	3	647	\N	1605a00d-2cd5-4632-a55e-653ad2afbaaf
2412	The Rising Tied	0	\N	3	647	\N	2260aedd-155d-33b0-a4bb-6db7ce3f6598
2413	The Rising Tied	0	\N	3	647	\N	36275e96-79e1-48a8-a207-6b8f592ac68f
2414	We Major	0	\N	3	647	\N	38b62ae2-d5c4-4759-bc92-a247abc5071d
2415	The Rising Tied	0	\N	3	647	\N	43626f9f-373f-451e-a0b7-b1b61172f786
2416	The Rising Tied	0	\N	3	647	\N	4b6ca48c-f7db-439d-ba57-6104b5fec61e
2417	Instrumental Album: The Rising Tied	0	\N	3	647	\N	641c4d37-95f2-48a0-938e-8f57f6334927
2418	The Rising Tied	0	\N	3	647	\N	8ab9e724-027c-35f3-a941-29efcf935528
2419	We Major	0	\N	3	647	\N	94ccfd71-4d41-47ff-8fbc-aae49465d432
2420	The Rising Tied	0	\N	3	647	\N	a8efe89d-8788-498d-af76-d5d643d3c4f4
2421	Where the Sun Never Sets	0	\N	3	648	\N	009ccb8c-35c7-4bd9-9d6f-f7dace37487c
2422	Here We Are	0	\N	3	648	\N	0166c27d-c406-41fe-949b-bebdf9a950e7
2423	What the Fuck Will Change?	0	\N	3	648	\N	23ec9570-9618-4c22-9592-ff44082ef750
2424	What the Fuck Will Change?	0	\N	3	648	\N	56acaa8b-59c6-413f-9998-07b1132de397
2425	Until We Die...	0	\N	3	648	\N	b17e7621-8692-4a58-aa9b-7e25aaa22472
2426	Mail Order Brides	0	\N	3	650	\N	1e38b471-03cf-4802-a344-5ecda4e861d2
2427	North College Hill	0	\N	3	650	\N	37ca6f20-e690-4c11-bce2-c04ec6a5342a
2428	Sometimes My Arms Bend Back	0	\N	3	650	\N	bf35f355-4a5a-4bbc-855c-5b391f72a7ea
2429	Be Kind to Beginners	0	\N	3	650	\N	c1e0c2fa-6bb5-4f4c-bd3b-02c57fc60937
2430	This Story Is Old, I Know, But It Goes On	0	\N	3	650	\N	cc7da011-a520-408a-ab9d-56d1ed9caf8b
2431	The Pestilence Is Coming	0	\N	3	650	\N	ec8b1e19-f84c-4434-af1c-64367772d6a9
2432	A Minor Swoon	0	\N	3	651	\N	f2c6f36c-785e-4769-b9d4-51c3985112f1
2433	Heaven to Overthrow	0	\N	3	653	\N	0a932a8b-1ac2-4872-97c9-70fd6703eda6
2434	Go, And Sell All of Your Things	0	\N	3	655	\N	b4113441-9a8a-4caa-8913-e31b52fc840e
2435	Shane Minor	0	\N	3	658	\N	2e9e662b-6c30-42c0-98bc-d31654606050
2436	Minorville	0	\N	3	661	\N	0a58cfda-091a-4e57-ad02-c541d89f457b
2437	PSA, Volume 3: Who Is Derek Minor?	0	\N	3	661	\N	19712433-3035-4227-92f4-a82be8dcc1a5
2438	Empire	0	\N	3	661	\N	42186dba-4660-4b9e-8191-93d4fd3ea466
2439	Empire	0	\N	3	661	\N	c92176e2-8423-4d4e-8987-afd02be27251
2440	No Heroes	0	\N	3	664	\N	04db6701-f59b-36bc-b729-0c125f1dc263
2441	Halo in a Haystack	0	\N	3	664	\N	07ac9ed8-7b0b-4b62-9f7b-bb2fdeac87a7
2442	The Poacher Diaries	0	\N	3	664	\N	16b55d8f-bd82-38de-9544-6a68bfcf693d
2443	Petitioning the Empty Sky	0	\N	3	664	\N	1af78661-4d13-4d2c-bad8-b4dc3c6ef1a8
2444	When Forever Comes Crashing	0	\N	3	664	\N	1bcfb75b-d86f-4134-ac22-01d28984b4f9
2445	Deeper the Wound	0	\N	3	664	\N	1fed1eea-22b6-4671-9b29-c05f0f7b55af
2446	Deathwish Live Series 02: Minneapolis, MN 09.21.05	0	\N	3	664	\N	289a83f2-828b-400a-94b0-bffa678b28d0
2447	The Poacher Diaries	0	\N	3	664	\N	2ff35caf-f40d-44a6-8365-31cd4ea269d9
2448	Petitioning the Empty Sky	0	\N	3	664	\N	3940d3ef-36ee-4485-8b14-70a65f3906b9
2449	No Heroes	0	\N	3	664	\N	447f03b1-b399-49f2-b7e3-c2f0dba4de40
2450	Caring and Killing	0	\N	3	664	\N	5b24f96f-53de-40c6-bf68-4cbc14653c79
2451	All We Love We Leave Behind	0	\N	3	664	\N	67800eea-3eee-4fc2-a14e-1f4a67286cd5
2452	All We Love We Leave Behind	0	\N	3	664	\N	6bed1426-4afa-4969-be07-51e5ba6b9c6f
2453	Petitioning the Empty Sky	0	\N	3	664	\N	7517f450-e1c6-3af0-9ef9-293e18f3655a
2454	Axe to Fall	0	\N	3	664	\N	84f8ae0e-8d40-409a-adc4-45147c427a3d
2455	Unloved and Weeded Out	0	\N	3	664	\N	87cc11ea-834d-4662-ae73-e070c2e247bd
2456	All We Love We Leave Behind	0	\N	3	664	\N	8904bd06-f081-4692-ae22-62a578af3d9a
2457	All We Love We Leave Behind	0	\N	3	664	\N	b8a0d7df-2d07-4b02-ace4-77bb584a41da
2458	Jane Doe	0	\N	3	664	\N	c0c80905-b460-4385-b84d-b068eb14bf5a
2459	Caring and Killing	0	\N	3	664	\N	c538b807-6bbf-45c3-b93f-e22bc11016d0
2460	When Forever Comes Crashing	0	\N	3	664	\N	db28c9b5-d24a-45cd-9223-32bde6f0a9b7
2461	You Fail Me	0	\N	3	664	\N	e3f3dd24-798c-4d2e-8f34-7e97d3ced433
2462	You Fail Me	0	\N	3	664	\N	e5682c1d-0d52-4953-8acf-fe7ab18b9ed5
2463	In Humor and Sadness	0	\N	3	665	\N	d7deb959-60c7-4185-ad00-1cc9645627b6
2464	Well Heeled, Volume One	0	\N	3	667	\N	851b8788-1e7a-448f-86e0-18349a4d8f55
2465	De allergrootste hits van	0	\N	3	669	\N	82ecd6e1-9836-4a74-ab24-9f22e7345221
2466	Superqueen	0	\N	3	672	\N	2bb35761-d6a4-44b2-9cc6-1d2a4f062113
2467	The Ape of God	0	\N	3	685	\N	018bf2e9-de1c-4274-856a-1887dd88bb1f
2468	The Ape of God	0	\N	3	685	\N	0f591b5d-6064-4bc5-a5a9-a1bdccfdab90
2469	The Ape of God	0	\N	3	685	\N	31dfcc67-bd94-45fa-bc6f-b162cc179cd9
2470	No	0	\N	3	685	\N	3d80e1ca-9eb3-4265-8989-8293c5310ebd
2471	Seminar II: The Holy Rites of Primitivism Regressionism	0	\N	3	685	\N	3f75e5f2-fbc4-4198-9339-f4d5b1563004
2472	No	0	\N	3	685	\N	40cd83ab-165b-4fc2-85aa-5f1c0a2a06a5
2473	Seminar III: Zozobra	0	\N	3	685	\N	56275d87-152a-44e9-81b5-9cfbb485bdb0
2474	The Ape of God	0	\N	3	685	\N	5cc44056-b47d-400c-8df2-cf4deb1f16a9
2475	Meditations in B	0	\N	3	685	\N	916d9a5b-b089-4eaa-8f14-c29993fe34de
2476	The Ape of God	0	\N	3	685	\N	93e92945-3a26-4283-9873-afe27f19ab2a
2477	Christmas	0	\N	3	685	\N	da2e11bc-924b-420e-8c94-395a68660cb6
2478	No	0	\N	3	685	\N	eb3cab5a-9176-4cb2-aa07-e20eb409aaed
2479	Meditations in B	0	\N	3	685	\N	ef9114b2-dcf9-4224-b488-ba610902fa09
2480	No	0	\N	3	685	\N	fc40096a-3a1a-4ad7-b227-7cace940c2e0
2481	Down Side Up	0	\N	3	686	\N	193a30cc-3209-4cf0-9bc9-de5c221ce1b8
2482	Down Side Up	0	\N	3	686	\N	5d67c449-9e3c-42dd-9c76-7d9acbb81640
2483	Guts n' Teeth	0	\N	3	686	\N	ac840d92-558d-30ff-bfae-10442a0bbad2
2484	Guts n' Teeth	0	\N	3	686	\N	cee21128-d31b-4f73-8485-bfbc46d16e4b
2485	Guts n' Teeth	0	\N	3	686	\N	f09b4e83-650c-392b-8160-f46a2ee93d7f
2486	Hold On to Your Face	0	\N	3	689	\N	00e24311-528f-4784-94d7-78d333d365c8
2487	Old Lady Drivers	0	\N	3	689	\N	155bb7e6-dd9d-4ac3-ac1d-13cd7773c882
2488	Lo Flux Tube	0	\N	3	689	\N	161c2cc8-4c0f-472d-87d2-c4f190e09a42
2489	Formula	0	\N	3	689	\N	45cb8899-7190-4fe0-9a53-78df3db5c48b
2490	The Musical Dimensions of Sleastak	0	\N	3	689	\N	8ead4ef8-aa33-4211-b5ac-776c30640b3c
2491	The Musical Dimensions of Sleastak	0	\N	3	689	\N	a1a721aa-4246-4801-bd3d-6dbcbbbc5a1e
2492	Hold On to Your Face	0	\N	3	689	\N	f150d0a6-eedb-459e-b927-8f7654cde5fd
2493	Nostalgia	0	\N	3	690	\N	2eef93e4-6562-4e08-8378-9cbc8f513339
2494	Old Man Savage	0	\N	3	693	\N	9dc5b8f5-69a2-48a8-acc4-b65a9f3c7a0f
2495	Unfavorable	0	\N	3	696	\N	1636aa9e-d1b3-4829-9114-80d34671b2c4
2496	Unfavorable	0	\N	3	696	\N	481c9562-758e-4a71-ba91-fd4226ae012b
2497	Unfavorable	0	\N	3	696	\N	74018cd6-706c-4e8b-b8ed-7a2b9975403e
2498	Visual Aids	0	\N	3	697	\N	43c9482d-0484-4414-9400-e4c378e96108
2499	Lone Wolf vs. Brown Bear	0	\N	3	698	\N	9b10831a-d96c-4906-b9b5-6a122cb733b2
2500	Old Man Lizard	0	\N	3	698	\N	cb492778-153e-4439-afaf-8cef70d32c59
2501	The Grand Theatre, Volume One	0	\N	3	699	\N	0497817c-3aff-4b2f-9fc8-1b4604d8b62f
2502	Fight Songs	0	\N	3	699	\N	10c88f6c-241e-483e-9020-694203e51ff8
2503	Most Messed Up	0	\N	3	699	\N	16402c39-9b43-4725-aebb-d1707e1c797a
2504	Hitchhike to Rhome	0	\N	3	699	\N	25465697-fd17-4504-8be3-1491eda1f197
2505	Wreck Your Life	0	\N	3	699	\N	26c723cd-2cd7-4b26-a55e-517d8bb663bf
2506	1999-05-29: Crocodile Café, Seattle, WA, USA	0	\N	3	699	\N	28131e64-d995-402b-a957-65b9229c195e
2507	Too Far to Care	0	\N	3	699	\N	39dd52a8-b266-4daa-8969-45de6e550a05
2508	Too Far to Care	0	\N	3	699	\N	4f011457-2953-4a80-a00d-cb5a22dfae5d
2509	2010-12-21: Daytrotter Studio, Rock Island, IL, USA	0	\N	3	699	\N	50e68ff2-d4b8-4264-a6fa-0573ef0422a6
2510	Blame It on Gravity	0	\N	3	699	\N	546a5081-9648-4ec6-a745-af0553269984
2511	The Grand Theatre, Volume One	0	\N	3	699	\N	6234b216-93d4-49a4-979b-73da74189a3d
2512	Hit by a Train: The Best of Old 97's	0	\N	3	699	\N	6bc3a475-cfae-458e-9987-c75a5cd8d190
2513	Satellite Rides	0	\N	3	699	\N	6d48892a-7e96-4301-bd59-b93ba8b9bce0
2514	Satellite Rides	0	\N	3	699	\N	6ef9522d-15d5-41e7-9120-d51297b8881c
2515	The Grand Theatre, Volume Two	0	\N	3	699	\N	a5da8f27-c448-4d40-97da-3028ae77f7a4
2516	Most Messed Up	0	\N	3	699	\N	a6533bda-f9ae-4baf-9cc5-224703383db4
2517	Hitchhike to Rhome (20th Anniversary Edition)	0	\N	3	699	\N	bf5e8694-6f56-49a4-8fa2-601edb5dcbaa
2518	Early Tracks	0	\N	3	699	\N	c012d2c7-76fe-4c65-bf99-5145e5790e70
2519	Drag It Up	0	\N	3	699	\N	c30f863a-d6b5-4660-88b0-8e1d43ef2a41
2520	Drag It Up	0	\N	3	699	\N	c450ead7-5f8a-496f-aea3-245c06ba2d8e
2521	1998-01-26: Austin City Limits, Austin, TX, USA	0	\N	3	699	\N	cae93100-a326-440c-b5d5-fa043c1245e4
2522	The Grand Theatre, Volume One	0	\N	3	699	\N	cc5de5d5-a65d-421e-a005-ae5e9aae196a
2523	Alive & Wired	0	\N	3	699	\N	e7d14f18-3950-4ddb-aa40-bb92c903eaf0
2524	Feral Harmonic	0	\N	3	700	\N	6c295cf5-3b66-3f47-b732-bdfae6b9927f
2525	Feral Harmonic	0	\N	3	700	\N	a324fd47-3977-45e5-81e8-eea9ed546922
2526	Early Morning Hymns	0	\N	3	700	\N	fc982a8c-50a1-4a5b-8eed-28377ad47525
2527	Old Dogs (disc 1)	0	\N	3	701	\N	3048a010-fcf7-475f-817f-9115a321bcf6
2528	Old Dogs (disc 2)	0	\N	3	701	\N	4491b7cf-d4f6-42e9-a101-dec5ac2dbd78
2529	Old Dogs	0	\N	3	701	\N	edbaf031-dfec-4a39-b2a8-a57e8e4fc2c3
2530	Old One	0	\N	3	702	\N	8d11851e-9635-4c53-9029-a9674238b791
2531	Split in Two	0	\N	3	702	\N	be9728db-208c-476a-8f78-ac317bddb575
2532	An Autobiography	0	\N	3	703	\N	2cdf4fd3-6426-44a7-8156-8c9b1bd1d7f4
2533	Old Soul	0	\N	3	704	\N	2033377b-6782-483f-bbcf-2b2b7b89666d
2534	Let Yourself In	0	\N	3	705	\N	5a1b2634-77e7-4c6e-ba93-30d11b39ef4b
2535	Old Shoe	0	\N	3	705	\N	b657dc89-b59b-4d0c-abf6-7b55e592ec5d
2536	Hello Citizen	0	\N	3	708	\N	7de97a82-dc19-4865-9bb4-5c51ea42f31d
2537	Play This at My Funeral	0	\N	3	708	\N	d448fee3-329a-4a07-8b72-4b015fef733c
2538	Manifesto for the New Patriot	0	\N	3	710	\N	ef05cb28-a97a-4cfe-873f-b0c8385c5318
2539	Everybody Is Going to Heaven	0	\N	3	711	\N	58427d1a-76b8-4e3e-998f-33de46e4eb08
2540	Youth	0	\N	3	711	\N	8b86e9f3-33ed-45e4-95c3-f2e8f57ae793
2541	Everybody Is Going to Heaven	0	\N	3	711	\N	b97872c1-5fe9-43f6-a977-237d32896a16
2542	Citizen Cope	0	\N	3	713	\N	1c382e7a-1efa-46fb-9fcf-fca60599fe71
2543	Mountain Jam IV, Hunter, NY	0	\N	3	713	\N	244a3356-16f4-42e0-ba94-6bd42121b4a7
2544	The RainWater LP (Initial Pressing EP)	0	\N	3	713	\N	2677bf86-ed2f-4e48-b566-aa91962485f1
2545	Every Waking Moment	0	\N	3	713	\N	2f9c5aec-c7e3-468a-8456-294a23b3cd41
2546	The Rainwater LP	0	\N	3	713	\N	575a4b6d-f4e7-4cc6-99aa-28baf54fe188
2547	The Clarence Greenwood Recordings	0	\N	3	713	\N	9b88cf3e-4077-4c1b-b5c2-148a7c7066c2
2548	The Rainwater LP B-Sides	0	\N	3	713	\N	bf74021c-7b6e-413d-8163-78f4bc5250ee
2549	One Lovely Day	0	\N	3	713	\N	c03c68ad-c978-435c-bbfa-36eb8513bc46
2550	The Rainwater LP	0	\N	3	713	\N	d7aeeb6f-ae7d-3912-8192-c0f31ddd339e
2551	One Lovely Day	0	\N	3	713	\N	e0e8e22c-b21a-4abd-9688-c704376fa868
2552	Live Fish	0	\N	3	715	\N	113c5d40-747d-4258-b216-b7d79636f12f
2553	Millennia Madness	0	\N	3	715	\N	1eb8da5b-ef82-4643-b438-82e3c389d2d3
2554	Life Size	0	\N	3	715	\N	473c8e41-78ae-4671-8d2c-44bcaedafab8
2555	Life Size	0	\N	3	715	\N	53c44e0c-1631-3ac4-8e77-48a242582bfb
2556	Active Ingredients	0	\N	3	715	\N	59938797-f815-413d-b62f-42efc23c8481
2557	Active Ingredients	0	\N	3	715	\N	5b641ae3-a740-4d17-bfb6-8eeade27a1a3
2558	Deadline	0	\N	3	715	\N	6533891a-7580-4ce8-b278-1c06c88bca16
2559	Wider Than a Postcard	0	\N	3	715	\N	69bc6e85-a2b8-4264-bf00-77a3eee22577
2560	Live Fish	0	\N	3	715	\N	6e017b15-5c3f-4bad-87b1-92fb9f17c4fe
2561	Free Souls in a Trapped Environment	0	\N	3	715	\N	78a7dd5f-913b-437a-b17f-00107c833b1c
2562	Psychological Background Reports	0	\N	3	715	\N	7a0c5e17-5b5d-4ec2-ab77-722039da5372
2563	Goods	0	\N	3	715	\N	7fa8cdda-cc55-4026-8746-51e8be175783
2564	Thirst	0	\N	3	715	\N	84fd487d-ccfd-3ca8-8add-d8b3e22d807b
2565	Wider Than a Postcard	0	\N	3	715	\N	90e84322-7248-4d48-8bd4-29ac1420ae5c
2566	Thirst	0	\N	3	715	\N	930abfdc-a7fd-4045-ad5c-14c5026d2ad1
2567	Deadline	0	\N	3	715	\N	9877c981-ef73-3625-8c71-f8f990f5e477
2568	Flinch	0	\N	3	715	\N	a0a2fc22-dc99-4aab-85ff-97bf626ce845
2569	Third Psychological Background Report	0	\N	3	715	\N	e280f489-248c-4362-8842-0421d407e8c7
2570	Flinch	0	\N	3	715	\N	ea4b777a-a133-4580-8006-d955bc33e8d9
2571	Millennia Madness	0	\N	3	715	\N	f5f731fd-9685-4f18-8ef7-0ce3e155ef88
2572	Free Souls in a Trapped Environment	0	\N	3	715	\N	fa79fd06-d0c5-3668-85cf-ce1818ff1e99
2573	What Time We On?	0	\N	3	715	\N	fb5d7572-6953-44e3-b456-3798306aa79c
2574	Rust In My Car	0	\N	3	717	\N	b2a3d4ef-2647-4c17-9ae5-511f7668a1da
2575	Scartown Unreleased Classics	0	\N	3	718	\N	1980eae8-0b50-47a0-9ef4-8d7369b17980
2576	Master Stroke	0	\N	3	725	\N	141b7892-7524-48be-87f1-b210acfe9c5f
2577	Nil by Mouth	0	\N	3	725	\N	97131915-cc90-4985-9f60-339cbe5d464d
2578	Everything's Changing and Nothing	0	\N	3	728	\N	480d23cb-cc4c-42da-87e9-ab597d099003
2579	Citizen Smile	0	\N	3	728	\N	5a264eed-6856-4c38-837e-d32b783d442d
2580	Sateen	0	\N	3	729	\N	0dab9498-4d8d-42b6-b21a-3061bebce25c
2581	Sateen	0	\N	3	729	\N	acddf89c-dba5-4247-b95a-46b627435562
2582	Love Is the Evidence	0	\N	3	730	\N	74f180eb-3d6c-4019-a74d-3e1665c3a92d
2583	The Blues Brothers	0	\N	3	731	\N	127bcbfe-7523-36f3-a8e7-1f392d54bab0
2584	Best of the Blues Brothers	0	\N	3	731	\N	1a367c34-a523-41a9-842a-5d7e27a8e0c2
2585	Best of the Blues Brothers	0	\N	3	731	\N	2322b02e-07bf-4921-918b-bda4e4ee79a0
2586	The Blues Brothers	0	\N	3	731	\N	2337f0d9-dc4e-483e-864c-0b92ed369e61
2587	Best of The Blues Brothers	0	\N	3	731	\N	250ead57-8fe6-43cf-aa21-c2011c7acb1f
2588	The Blues Brothers	0	\N	3	731	\N	2d425557-0359-3cd2-9c0b-bfe4eb6efc84
2589	Briefcase Full of Blues	0	\N	3	731	\N	32d28faf-e5da-4fda-bd3e-856857a12d3f
2590	The Definitive Collection	0	\N	3	731	\N	337459bf-c37c-4e9e-b375-08d665e0a2b7
2591	Best of the Blues Brothers	0	\N	3	731	\N	436cede3-4d66-3825-9eac-bedf8a0ccc16
2592	The Blues Brothers	0	\N	3	731	\N	4e7f7bfa-4dcc-3387-93d9-966a58017d49
2593	Everybody Needs Blues Brothers	0	\N	3	731	\N	514a45df-d1b5-49f9-b898-4cac64f33876
2594	Best of the Blues Brothers	0	\N	3	731	\N	55267c0a-d4ee-420f-8254-b3c8e17e31ec
2595	The Blues Brothers	0	\N	3	731	\N	696c61df-98a1-3914-a65d-d1a49bce4113
2596	The Blues Brothers: Music From the Soundtrack	0	\N	3	731	\N	6f9ef53c-fa18-35b6-96fc-6b1268e0ca0a
2597	Live at Montreux Casino	0	\N	3	731	\N	74f6aa4e-0bdf-38c2-95e6-a9096155363d
2598	The Definitive Collection	0	\N	3	731	\N	8603f0e0-41f1-4f54-8b97-ea1a9a47c912
2599	Made in America	0	\N	3	731	\N	8c3a5a46-c003-375b-8565-7cabae579f68
2600	Made in America	0	\N	3	731	\N	badaa3dc-5f33-458f-a4d2-c8d99a6bf067
2601	Live in Montreux	0	\N	3	731	\N	c07d9a07-2066-4817-8669-c6cb48e35eb9
2602	The Blues Brothers	0	\N	3	731	\N	c0e68133-66f8-487c-9b40-b215cf5f261b
2603	The Very Best of the Blues Brothers	0	\N	3	731	\N	db3f91a3-ac40-47fa-8fe0-340d393b7891
2604	Briefcase Full of Blues	0	\N	3	731	\N	dd608db4-bbd0-3d70-bef5-152efb79c337
2605	Briefcase Full of Blues	0	\N	3	731	\N	e96e80c3-5295-46be-80c1-c5dcd15f3ed5
2606	Briefcase Full of Blues	0	\N	3	731	\N	f7fd38d6-f428-46b6-8524-acf98db3658e
2607	The Blues Brothers	0	\N	3	731	\N	fb14f161-0003-3b20-9028-b96358ccd551
2608	the best of	0	\N	3	734	\N	217fa778-df39-43ce-896b-d89cde2c7e53
2609	Skriven od pogleda	0	\N	3	734	\N	8e339bb2-6c32-40c9-ab4f-a67a23041563
2610	On the Acoustic Side	0	\N	3	734	\N	aebf536b-cc35-4ab3-a94b-e65716f6db7e
2611	Blues Brothers 2000	0	\N	3	735	\N	230185e0-ff05-4e8a-9fb8-632cd08ed49c
2612	Red, White, & Blues	0	\N	3	735	\N	866e964b-a7f1-3e6d-bd43-46f03951951a
2613	Blues Brothers 2000	0	\N	3	735	\N	cc7d65ce-7de7-3acf-b9e5-7dae70aa9127
2614	Red, White, & Blues	0	\N	3	735	\N	ece80550-c6e6-48d1-b690-0483f4dc3124
2615	Another Cow's Dead	0	\N	3	736	\N	620c223a-d0c1-4544-9011-76daea2957b7
2616	Straight From the Woods	0	\N	3	737	\N	96ab8977-2b95-4eb9-a320-3f9fdc56f3ec
2617	Live	0	\N	3	738	\N	8ffe4061-da0d-4bf1-9bd8-9290b5a0fdab
2618	1997-10-25: Utica Memorial Auditorium, Utica, NY, USA	0	\N	3	739	\N	08c44b32-fce1-469c-80f5-49bc82301f64
2619	Cover Yourself	0	\N	3	739	\N	211b1383-d4b6-4321-9b9b-db2443bbc7ca
2620	Travelers & Thieves	0	\N	3	739	\N	29dd0cad-c0cc-4af1-8da0-e635d0b123d5
2621	¡Bastardos!	0	\N	3	739	\N	30035f6d-b54c-49e4-ae1a-2919111fd7c4
2622	Blues Traveler	0	\N	3	739	\N	3072eb02-f607-45d4-9ced-b3431eaf0a7e
2623	Four	0	\N	3	739	\N	3785ed44-d78a-4fc0-b9df-e770abce474c
2624	2008-07-28: Turfway Park, Florence, KY	0	\N	3	739	\N	43a63244-4de1-4ce3-9a07-4d9cd22a6680
2625	Voodoo Children: The Instrumentals	0	\N	3	739	\N	4d5713ee-f83f-495e-b866-0fe85e145593
2626	Travelogue: Blues Traveler Classics	0	\N	3	739	\N	563f6726-951a-494d-9c32-21f32c36123b
2627	Bridge	0	\N	3	739	\N	69cfdb4c-251e-42b8-a486-e7f60d0c1791
2628	Suzie Cracks the Whip	0	\N	3	739	\N	6da8b1e6-faa1-42a7-b20f-791643f938fc
2629	Live: What You and I Have Been Through	0	\N	3	739	\N	7d930367-3afa-4093-902d-bab832714f3e
2630	25	0	\N	3	739	\N	85cb41c7-df2d-4eb2-a195-f1bd4f21f009
2631	Save His Soul	0	\N	3	739	\N	8f662c2d-ca59-412a-afcb-36e50c626ae4
2632	Suzie Cracks the Whip	0	\N	3	739	\N	9efe1309-810a-471a-8da3-339cd054f49a
2633	four	0	\N	3	739	\N	afc5b46a-dd39-491c-ae84-823622a78133
2634	On the Rocks (live)	0	\N	3	739	\N	b30127c6-5d3a-417b-8133-b45d3e61c996
2635	Live From the Fall	0	\N	3	739	\N	c7a3d1ea-ffb0-4beb-9197-3163298f93f6
2636	Straight on Till Morning	0	\N	3	739	\N	d26129d0-b1a5-4fa6-aa22-a73ef6d294da
2637	four	0	\N	3	739	\N	dfb9f033-a023-4cfe-a993-51393c43afa2
2638	North Hollywood Shootout	0	\N	3	739	\N	e16d40cb-140c-46f8-a95a-047827a80d39
2639	four	0	\N	3	739	\N	ed60ca67-d135-4a6a-b526-215de10d57b1
2640	Truth Be Told	0	\N	3	739	\N	f7c60271-1756-46de-8399-9b2986d9d500
2641	Live From the Fall	0	\N	3	739	\N	fd9f4c7a-01fe-4a03-bcf5-29ce96368eed
2642	North Hollywood Shootout	0	\N	3	739	\N	ff4e5caa-d217-420c-b6a1-bb0142c4337f
2643	Never Goin' Back to Georgia	0	\N	3	740	\N	049ce891-7fcf-410b-856e-72c3868c2a43
2644	Electric Comic Book	0	\N	3	740	\N	0ac1a200-7ed2-4aaf-8abe-76860771ac05
2645	Psychedelic Lollipop	0	\N	3	740	\N	37d53840-9940-473d-bbff-b72c0d673ed1
2646	Gulf Coast Bound	0	\N	3	740	\N	4ee18960-db76-4206-81ff-131bf45dc98a
2647	Psychedelic Lollipop	0	\N	3	740	\N	515243b9-e3be-4086-a507-b2461289a7aa
2648	Psychedelic Lollipop	0	\N	3	740	\N	93c4cc87-0ade-46c5-ba36-3c53adbc990b
2649	Basic Blues Magoos	0	\N	3	740	\N	9a296337-4dca-4b21-8de2-cd72ce4a6c59
2650	Kaleidescopic Compendium: The Best of the Blues Magoos	0	\N	3	740	\N	ab480cad-d2b8-4365-872f-718c7ec3289a
2651	Psychedelic Lollipop / Electric Comic Book	0	\N	3	740	\N	c1a8fe54-0511-44a7-ac21-b580e4a9f702
2652	Electric Comic Book	0	\N	3	740	\N	df4625c6-7b56-45f6-b205-6fe3146eced7
2653	Electric Comic Book	0	\N	3	740	\N	e53cc4b0-0f8f-4f25-a9a5-1769fa1c69e9
2654	Color in Rhythm Stimulate Mind Freedom	0	\N	3	741	\N	96e40a26-4ffd-451b-92a2-b051cb8aba8f
2655	Blues Image	0	\N	3	742	\N	7adae5b2-b93c-4a91-ade7-c15a6d53924e
2656	Open	0	\N	3	742	\N	a4d78ae7-a502-3d68-96e9-cc204c3f8312
2657	Open	0	\N	3	742	\N	a7abdcc4-4aff-41dc-9cbf-870d5e238766
2658	Open	0	\N	3	742	\N	de13c571-a761-4ad2-8978-dc36f34382cf
2659	Red White & Blues Image	0	\N	3	742	\N	e086b2df-35f7-4005-b8fe-1467268ca578
2660	Is Here	0	\N	3	743	\N	25059e39-f834-4681-8412-bd275c75eac2
2661	Is Here / Do Their Thing	0	\N	3	743	\N	8708017b-bf14-4dc5-8823-8b68aef7ad0f
2662	The Pre ZZ	0	\N	3	743	\N	9052c234-1dca-4c9b-b0de-91978c71ab9d
2663	Do Their Thing	0	\N	3	743	\N	e1ef85dd-7dd9-4d42-b26c-901e0ad7889a
2664	Is Here	0	\N	3	743	\N	ee374a85-04db-3026-8aa1-7acfd0f3dffb
2665	Blues Dragon	0	\N	3	744	\N	6670f59e-6be9-4007-a893-af80b91dd64c
2666	I Hate My Boss	0	\N	3	745	\N	d32c2a10-082a-4603-82d8-ec9f8850f59f
2667	This Is the Jungle Brothers	0	\N	3	746	\N	0c2c9187-697d-4eb3-84c8-b37e23b17c50
2668	Raw Deluxe	0	\N	3	746	\N	1164f778-4e52-40b9-9fd8-9de1bc67ab81
2669	Straight Out the Jungle	0	\N	3	746	\N	173f1962-0328-3d79-8e81-73caa1e55fdd
2670	All That We Do	0	\N	3	746	\N	29c65850-1a8f-4cfb-9576-8bcdd98ca009
2671	Straight Out the Jungle	0	\N	3	746	\N	345e84d9-93c9-3d2c-adfa-db0e33acadfb
2672	J. Beez Wit the Remedy	0	\N	3	746	\N	42df27fd-82e3-4230-9723-ab3585ec0cce
2673	Straight Out the Jungle	0	\N	3	746	\N	495d836a-758c-4ebc-a86d-85d85ea37881
2674	Off the Hook	0	\N	3	746	\N	631cc2c5-bb3d-467a-96ba-8035e9ccca39
2675	Straight Out the Jungle	0	\N	3	746	\N	64164344-4dba-4682-92de-50d60b9740fd
2676	V.I.P.	0	\N	3	746	\N	6c41a584-37e5-4710-aa5d-1f75c50d61f0
2677	Raw Deluxe	0	\N	3	746	\N	6d2558b9-72df-399f-9b39-7f8684986909
2678	Straight Out the Jungle	0	\N	3	746	\N	6ed8c4e9-1223-40dd-8713-450aaea3240f
2679	Raw Deluxe	0	\N	3	746	\N	b0b9e7ae-0307-40aa-b19f-3176f0bab5b3
2680	Straight Out the Jungle	0	\N	3	746	\N	be0f88c0-eb75-4280-808f-4dba9e0d75d9
2681	I Got You	0	\N	3	746	\N	bf376cd4-b133-4863-a5c4-4b8fa74dcf24
2682	V.I.P.	0	\N	3	746	\N	c650c5cb-ff5b-4f76-94d5-77654d9e37f3
2683	Beyond This World: Best & Rare	0	\N	3	746	\N	cd461cc8-b0ba-44c9-8962-39eaf96a85cf
2684	Done by the Forces of Nature	0	\N	3	746	\N	d7d68e45-2b8c-4629-9c75-84a59bcc8a90
2685	Done by the Forces of Nature	0	\N	3	746	\N	db52cda1-11a2-47de-b647-862bf40d4615
2686	Jungllenium Remixes	0	\N	3	746	\N	e86ad638-5608-48d4-b2a5-d2d6580a9927
2687	You In My Hut Now	0	\N	3	746	\N	fdd5029e-0394-4a47-8f8c-01bce2c149c5
2688	Electric Waco Chair	0	\N	3	747	\N	058f6fce-2c4f-466c-86c2-5b1dc8db8bc9
2689	Cowboy in Flames	0	\N	3	747	\N	228c0445-e6d5-4302-bd03-3fa752857795
2690	Nine Slices of My Midlife Crisis	0	\N	3	747	\N	54ecd7fd-8d27-4aad-8a8b-d932379ee6f8
2691	Great Chicago Fire	0	\N	3	747	\N	8135445f-4f60-4b10-ab1e-5bd525add3ca
2692	Freedom and Weep	0	\N	3	747	\N	a1146af2-29a5-4b88-a16d-18a7745df506
2693	Wacoworld	0	\N	3	747	\N	a99a1267-eb72-4db7-825c-f5b61ca47ef8
2694	Do You Think About Me?	0	\N	3	747	\N	c97c23c8-a731-4ecc-baf1-3ef34fba8414
2695	To the Last Dead Cowboy	0	\N	3	747	\N	d701acdf-03cc-421f-a574-7855bcfe3826
2696	New Deal	0	\N	3	747	\N	e8ec7660-d1b0-41c7-b107-e9a77b3bf8ca
2697	Waco Express: Live & Kickin' at Schuba's Tavern	0	\N	3	747	\N	f6026bfd-3af2-4734-82b7-f581dc346423
2698	Goodbye, Killer	0	\N	3	748	\N	03b0ee5f-6e82-4806-ab6a-7d6bbea365eb
2699	Discover a Lovelier You	0	\N	3	748	\N	1589e167-a01e-4a13-adb7-ddd46ca1555f
2700	Overcome By Happiness	0	\N	3	748	\N	2559dc9e-0243-48c6-9c7c-c1d7ac1fd357
2701	Live a Little	0	\N	3	748	\N	41254cb3-6737-405d-95aa-3f288b1181f8
2702	Live a Little	0	\N	3	748	\N	51adf7e7-2ae1-481c-bdcd-6a6ca1de35de
2703	Live a Little	0	\N	3	748	\N	540ac21f-5a2b-36f0-a705-c3e0e2639329
2704	Yours, Mine & Ours	0	\N	3	748	\N	7bbed835-82e8-3182-a1c1-415360e1049c
2705	Yours, Mine & Ours	0	\N	3	748	\N	940a5617-739c-42e0-bd7f-2a235cc5d7e3
2706	The World Won't End	0	\N	3	748	\N	c4cdc67c-bb62-4adf-91e5-1354fb0ad42c
2707	The World Won't End	0	\N	3	748	\N	d16469f7-a6ab-4226-95d5-f79e852cfe39
2708	Nobody's Watching	0	\N	3	748	\N	e8988b6f-86b7-482e-b84c-a1267227fb1f
2709	Pimp to Eat	0	\N	3	749	\N	d7336a59-96e1-403f-b828-0295a01d46ca
2710	Ladder	0	\N	3	750	\N	3485ebaf-eef2-4437-8473-b6bb66839269
2711	Oxymoron	0	\N	3	750	\N	34d8f14b-5240-498b-b81f-b63761261ab5
2712	Coming of The New Messiah / Brother’s Keeper	0	\N	3	750	\N	387c1a24-aab2-481b-8616-3bb107ced77c
2713	Forever Never Ending	0	\N	3	750	\N	479ed09b-af4a-4341-b390-81eac6c5c306
2714	Self-Fulfilling Prophecy	0	\N	3	750	\N	4b70a9fa-ea8b-417a-b298-23fcfbbd4684
2715	Fantasy Killer	0	\N	3	750	\N	8234725f-3983-40b7-99b1-993f4dab9148
2716	Brother's Keeper	0	\N	3	750	\N	99c70a2d-e5fa-4220-aaf1-85bab71135e7
2717	The Continuum	0	\N	3	750	\N	d849894a-d5b1-45fa-8562-cf199344204e
2718	Cover Me	0	\N	3	750	\N	d87cf3d7-a8a6-449a-9e34-27a4238f8b13
2719	Recorded Live at the Gold Dollar 6/00	0	\N	3	751	\N	02460a4b-b6bb-46c4-b18b-6af04011c0e9
2720	The Hardest Walk	0	\N	3	751	\N	1ed91f79-ef4a-4d3f-a5fc-16f830189fa5
2721	Soledad Brothers	0	\N	3	751	\N	6bf0759a-5f52-4626-93fa-cac470fbd0be
2722	Steal Your Soul and Dare Your Spirit to Move	0	\N	3	751	\N	a2ae7cdd-cb4a-49e4-82d4-439f0b818f67
2723	Voice of Treason	0	\N	3	751	\N	b374b687-ced3-4488-a9ec-07d5a48808c9
2724	Buried in Your Black Heart	0	\N	3	755	\N	e060fca3-d21e-4a31-bc7f-cfe301897283
2725	Mercy	0	\N	3	755	\N	fe87dd6a-e6fa-4d6e-9c6c-861c759b104b
2726	Salvation	0	\N	3	756	\N	0cdfcab5-4ea8-3f67-a588-6456f9d76ce3
2727	Cult of Luna	0	\N	3	756	\N	127403b1-3b2e-3c37-a1b7-f743bdff190c
2728	Eternal Kingdom	0	\N	3	756	\N	154bdebf-9bc8-3c27-9089-c42ed5e7aa2b
2729	The Beyond	0	\N	3	756	\N	1af0cdb9-5e40-3e0c-97b8-68d98b828a77
2730	Somewhere Along the Highway	0	\N	3	756	\N	1fde8540-59cf-4c8d-8429-eb076d03fb05
2731	Cult of Luna Remixes	0	\N	3	756	\N	3161b25b-2b84-4bd4-9162-9d307fb2a3a4
2732	Salvation	0	\N	3	756	\N	4e7f8492-38be-43ef-80d2-809b998c4592
2733	The Beyond	0	\N	3	756	\N	5b10a599-927f-449d-ae95-6f1115297be7
2734	The Beyond	0	\N	3	756	\N	649d1c49-3018-4a0b-b0cc-3ed64c39e373
2735	Vertikal	0	\N	3	756	\N	683516c1-2389-4061-81a8-fc6fa3576d9d
2736	Eternal Kingdom	0	\N	3	756	\N	7db4428f-f950-496a-a2c8-5773f0b42529
2737	Vertikal	0	\N	3	756	\N	835b42b0-ddc5-47d5-ad26-1c75be3d381f
2738	Fire Was Born	0	\N	3	756	\N	8f70056f-657a-48f8-bd0f-017ea9468547
2739	Eternal Kingdom	0	\N	3	756	\N	9ac290b5-dc92-4ea9-b9d2-ffce214ac8d3
2740	Vertikal	0	\N	3	756	\N	ca88ef67-66c1-4c4c-ac3e-66d178d575d6
2741	Somewhere Along the Highway	0	\N	3	756	\N	cc67b1a1-7e25-3c43-875f-35a72aea21ec
2742	Salvation	0	\N	3	756	\N	d3ca9ff2-df78-4f53-accf-c679dc63737b
2743	Live at the Scala	0	\N	3	756	\N	d97ef898-d2f6-45a2-8901-f10399acdde0
2744	Cult of Luna	0	\N	3	756	\N	e3bbfe46-b196-49e1-8d1a-6357f0f0aa5c
2745	Cult of Luna	0	\N	3	756	\N	f71cce3e-215d-4127-b10b-8ae919d42097
2746	Cult of Luna	0	\N	3	756	\N	f87ae542-1e3b-3833-aa6a-1634f9d48929
2747	Pup Tent	0	\N	3	757	\N	14c79fb5-794c-340e-83f9-1dc6dc90d843
2748	Bewitched	0	\N	3	757	\N	1aeee612-59ea-475b-8a2b-9fe953889554
2749	Romantica	0	\N	3	757	\N	223b9778-1fcc-4c47-bfbb-5e3e65ad85a7
2750	Pup Tent	0	\N	3	757	\N	2590e3b1-58ce-4d45-a95a-dbfc60b11227
2751	Best of Luna	0	\N	3	757	\N	2faec6df-1b64-461a-bbdd-d19f1238a6b8
2752	The Days of Our Nights	0	\N	3	757	\N	3bb68f22-a3b8-43dd-b80d-b56503d32d40
2753	Live	0	\N	3	757	\N	454fedec-c942-37fc-8e24-8f409f03b0f4
2754	Rendezvous	0	\N	3	757	\N	4ed35c81-8350-4771-97da-5fb6092efaa6
2755	Penthouse	0	\N	3	757	\N	742967ce-dd8c-4f93-94b5-77c5098d95ae
2756	Live	0	\N	3	757	\N	77fe163f-1a57-47ad-97e3-da51519a2866
2757	The Days of Our Nights	0	\N	3	757	\N	7d428035-d036-4796-acb8-069cfe74b03a
2758	Bewitched	0	\N	3	757	\N	7ebbaf2c-c5dc-4bd9-98e2-386b162bb5c6
2759	Lunapark	0	\N	3	757	\N	85ab53fa-f2b0-4445-8cd2-3830b15c4e8f
2760	Bewitched	0	\N	3	757	\N	87566439-8639-4047-b888-95229cad895f
2761	Best of Luna	0	\N	3	757	\N	8b35da17-36eb-4e2c-a7d5-21e769a36db1
2762	Pup Tent	0	\N	3	757	\N	911bb70e-2504-3cb4-8ff5-c512ab28bcb2
2763	Rendezvous	0	\N	3	757	\N	a665b23e-6703-4872-84cb-b523f1647e87
2764	Romantica	0	\N	3	757	\N	a9459c4d-774a-362c-a3a6-479e0acf192f
2765	Live	0	\N	3	757	\N	b60cca28-ff49-4d82-810d-631b1224822f
2766	Romantica	0	\N	3	757	\N	c41618e4-f42d-4eec-855b-5bc6a6692677
2767	Lunafied	0	\N	3	757	\N	ce66ec99-2046-42bd-88ea-9f4d54842e84
2768	Lunapark	0	\N	3	757	\N	de523765-e0f3-4798-9a8b-9e4a917596a7
2769	Round Up	0	\N	3	757	\N	e8b7d286-23ef-47f3-9649-98f48d3dd047
2770	Penthouse	0	\N	3	757	\N	ea8ee7d5-8651-4656-a4d4-66228079b6be
2771	Who Killed Puck?	0	\N	3	758	\N	2a526331-7bc4-4208-878b-76ed51bfb7e9
2772	Lost Songs from the Lost Years	0	\N	3	758	\N	30fb5d1e-538c-488e-bdf8-f8b08575e4a5
2773	Feel Good Ghosts (Tea-Partying Through Tornadoes)	0	\N	3	758	\N	3d1e2666-2609-414f-9a88-cd0ab15186bd
2774	Who Killed Puck?	0	\N	3	758	\N	3eceb3ed-7757-4979-9397-e2d88be02bc2
2775	Unplug	0	\N	3	758	\N	58dd3f77-8efb-401b-96ab-25ba61c0d4fa
2776	Unplug	0	\N	3	758	\N	62fa0cfb-ed08-4940-9812-ade55ff9a67d
2777	The Shade Project	0	\N	3	758	\N	74c23e64-072f-4563-a599-a5be8411661a
2778	Aurora Borealis	0	\N	3	758	\N	a8227440-61c6-46c8-bd1e-b8bc53c94982
2779	Light Chasers	0	\N	3	758	\N	ab23c23f-52ec-4c7b-84a4-1d73c2dff64c
2780	Aurora Borealis	0	\N	3	758	\N	aca3ee7e-5646-4e06-9188-c502300d6507
2781	Advice From The Happy Hippopotamus	0	\N	3	758	\N	c1763434-9ff0-43ea-baf6-0e9ab607e752
2782	Advice From the Happy Hippopotamus	0	\N	3	758	\N	c80fc1a9-1e57-42de-8d89-5a7b2bebb299
2783	Lost Songs From the Lost Years	0	\N	3	758	\N	c8a09415-fb5f-4425-a76f-0943c971491b
2784	They Live on the Sun	0	\N	3	758	\N	e3c7ce09-db90-4072-a5a6-79b90cbff198
2785	The Meaning of 8	0	\N	3	758	\N	e8e2a5eb-dd78-428f-bce9-78ce600dc171
2786	Love	0	\N	3	758	\N	ed1610e5-3ac6-4684-9c27-04c4b0a4fee9
2787	They Live on the Sun	0	\N	3	758	\N	f154d532-3779-4ed3-b62a-7530b0a5b656
2788	Ex-Cult	0	\N	3	760	\N	33a75665-23bb-4902-b632-34c2d0cf5f90
2789	Lightless Walk	0	\N	3	761	\N	b3c17743-9de6-48d1-9f4d-9156008994a2
2790	Shimmer	0	\N	3	763	\N	3d52ef10-a0bb-4cd7-94af-77ffa29bf056
2791	Thank You... Goodnight	0	\N	3	763	\N	c205eaa5-d5db-41c1-aa73-3b0b6dc934cc
2792	Luna Halo	0	\N	3	763	\N	f96d78e4-e41c-47af-aba3-4c29b154ae63
2793	The Absence	0	\N	3	765	\N	c6754f5c-c5ba-415b-9158-f9c1a7e705b6
2794	Agents of Fortune	0	\N	3	766	\N	0537990e-7f0d-4f5d-a68e-77e73b364f0a
2795	Fire of Unknown Origin	0	\N	3	766	\N	1529a274-676a-4ed0-9c68-46775e59e969
2796	Extraterrestrial Live	0	\N	3	766	\N	192b2fb9-5182-4596-a932-e5e2a7aba252
2797	Agents of Fortune	0	\N	3	766	\N	1b470ab5-5e43-4987-836d-fedbb4572a71
2798	Spectres	0	\N	3	766	\N	237d0f7d-4a0e-34a9-9096-e9426d4cf181
2799	Blue Öyster Cult	0	\N	3	766	\N	30c6ec9f-3aba-4f06-9528-d4f116498998
2800	Tyranny and Mutation	0	\N	3	766	\N	310d25e5-660c-4ea4-b3fa-f348454da0c6
2801	Mirrors	0	\N	3	766	\N	31faafcb-9f91-32c5-ab11-d2549b6dc0fd
2802	Secret Treaties	0	\N	3	766	\N	3430dda2-353a-48cd-919d-983be7a2a4a9
2803	Secret Treaties	0	\N	3	766	\N	34c60e53-9469-476f-a430-1863fd2a54f6
2804	Don't Fear the Reaper: The Best of Blue Öyster Cult	0	\N	3	766	\N	3a847343-bade-369d-8039-8b2c2ebeec80
2805	Mirrors	0	\N	3	766	\N	42e9f2f0-1b51-3be8-920e-c7a7cab5abbb
2806	Tyranny and Mutation	0	\N	3	766	\N	451b69c7-64a0-3396-b0eb-e4360e9d5a19
2807	Spectres	0	\N	3	766	\N	75d41550-ca5f-3607-83de-ec6a5fcd0978
2808	On Your Feet or on Your Knees	0	\N	3	766	\N	90daf78f-2908-493c-8352-eee024475276
2809	Some Enchanted Evening	0	\N	3	766	\N	953e298d-5ea6-309f-a6ec-f0010e2807ce
2810	Nail You Down	0	\N	3	766	\N	a905bd80-d523-4830-b43e-4b380f620d3f
2811	Agents of Fortune	0	\N	3	766	\N	b8a6b43f-95f1-4551-9dba-b2dce21add9b
2812	Tyranny and Mutation	0	\N	3	766	\N	b8cef516-24b6-30d2-b30a-be1ebee96989
2813	Extraterrestrial Live	0	\N	3	766	\N	cc798a8f-ea72-411d-a7f0-1177336d1027
2814	Fire of Unknown Origin	0	\N	3	766	\N	e33c8b19-6fd7-31ba-ad13-66c5a9938067
2815	Cultösaurus Erectus	0	\N	3	766	\N	e33d92db-a987-3c3e-8697-78dd15f4ac68
2816	Secret Treaties	0	\N	3	766	\N	ed47229e-00fe-33ba-ae28-8785130c233d
2817	The Revölution by Night	0	\N	3	766	\N	f27f74e8-8732-46ee-bb52-ee468efbc317
2818	Tyranny and Mutation	0	\N	3	766	\N	fabb5260-b01b-47a1-8ba6-41fd90ded82a
2819	Cult to Follow	0	\N	3	767	\N	b717dc93-4fa9-4dda-9cdc-f0a4c7bc0e22
2820	Lisa Lisa & Cult Jam With Full Force	0	\N	3	769	\N	0ebafcdf-82a8-4ab9-8c89-2b877d9c0842
2821	Past, Present, Future	0	\N	3	769	\N	178e63b8-2711-47d7-81fd-6515537fc385
2822	Straight Outta Hell's Kitchen	0	\N	3	769	\N	281ef635-2482-414e-b332-0c7a89bc2d9d
2823	Head to Toe	0	\N	3	769	\N	309ef97d-e60c-482c-80be-b69f14a36203
2824	Lisa Lisa & Cult Jam With Full Force	0	\N	3	769	\N	38c5dd4f-570c-4dce-88ce-074463d1d72d
2825	Super Hits	0	\N	3	769	\N	55a040de-5e3f-4e6c-8430-b977e812be10
2826	Spanish Fly	0	\N	3	769	\N	8603ea7e-26b0-4f5d-a9a3-b240b834972f
2827	Straight to the Sky	0	\N	3	769	\N	8f0bc89a-da39-4e09-aac1-2dd1efaf8d29
2828	A Place to Call My Unknown	0	\N	3	772	\N	20f267f0-2f9d-4bcd-8f89-29594b55a2a5
2829	Blessed Extinction	0	\N	3	772	\N	7bf0be8b-9242-4cd7-ae0c-aeafc8871580
2830	Cult of Erinyes / Zifir	0	\N	3	772	\N	83872f95-0524-437d-b0e4-c4507526fda5
2831	Electric Ruins: Remixed and Warped Surroundscapes	0	\N	3	773	\N	31e5c482-40d0-4417-8952-b387d8fca6bd
2832	The Second Bardo	0	\N	3	773	\N	8164c238-122e-4db9-9bf0-c4abb9577941
2833	The Seed: Relics and Rarities	0	\N	3	773	\N	a37235aa-c98a-4f26-ab86-bb03d25a6263
2834	Cult of Dom Keller	0	\N	3	773	\N	e9a9bbb4-ee3c-4817-a6b9-63896c728c85
2835	Love Will Prevail	0	\N	3	774	\N	52dae404-213c-41b3-b8bb-00befc5e66d6
2836	Final Days	0	\N	3	774	\N	5dee99d2-0c6c-4227-b16e-e6738a2da15b
2837	A Stick to Bind, a Seed to Grow	0	\N	3	774	\N	9ff73651-0b04-429a-88d4-81034263bb61
2838	Cult of Youth	0	\N	3	774	\N	bf77c91c-a439-410f-8245-fc07d75816e7
2839	Final Days	0	\N	3	774	\N	d6159e76-2ee0-4ed6-a7c8-ac893cac538c
2840	Cult of The Cobra	0	\N	3	775	\N	5af7c40f-9920-4e28-a9d7-c67cb4b955e4
2841	Hic Est Domus Diaboli	0	\N	3	776	\N	5dd502ef-cb32-4f39-ad62-5d19aba7e7a2
2842	A Vow of Vengeance	0	\N	3	777	\N	009e3994-a299-402c-bbaa-58e193a2a8f5
2843	Angelsbane	0	\N	3	777	\N	08674657-7eae-4750-9aed-ec87190bb6eb
2844	Dance of the Seven Veils	0	\N	3	778	\N	24193819-4544-4a40-9137-76b30b394c9d
2845	Antevorta	0	\N	3	778	\N	b5e8ae51-d314-4f0d-910f-e37db71a7ebd
2846	Times of Darkness	0	\N	3	779	\N	7a634759-01c2-42b8-9f88-6a001f18b70e
2847	Triumvirát	0	\N	3	780	\N	2b495082-0495-4ce3-afcb-00ca1696efdb
2848	मृत्यु का तापसी अनुध्यान	0	\N	3	780	\N	43da55bb-f52c-48b8-863a-d097ce2accb9
2849	मृत्यु का तापसी अनुध्यान	0	\N	3	780	\N	6547097f-30d9-4cea-9b91-1c857bcfebbb
2850	मृत्यु का तापसी अनुध्यान	0	\N	3	780	\N	85194058-a9e8-4400-ac4a-f410173776c0
2851	मृत्यु का तापसी अनुध्यान	0	\N	3	780	\N	d45cd9c7-029f-47bf-b73f-a85b5b3086a2
2852	Triumvirát	0	\N	3	780	\N	e77377fb-5a50-4a72-83ce-dd3fbf9b1109
2853	Ascetic Meditation of Death	0	\N	3	780	\N	f6949846-ca2d-4e88-80b6-3099cdaa2bdc
2854	"Ecce Fiat "- The Annunciation/Benedictine Monks of Clear Creek Abbey	0	\N	3	781	\N	f8ce86a1-fa38-4db6-a3de-d9c6a047d719
2855	Woodstock '99	0	\N	3	782	\N	0bcbd152-8594-411a-a0ca-31383dff98ce
2856	Curve	0	\N	3	782	\N	2314ce85-ccc1-413d-80d2-fb234e95ed71
2857	Spiritual Machines	0	\N	3	782	\N	35cb268d-d123-32a4-bcf1-36cf0ffcdccd
2858	Clumsy	0	\N	3	782	\N	3f3e2d4a-6fcc-473e-b6a0-7be7bac78944
2859	Healthy in Paranoid Times	0	\N	3	782	\N	4824fe45-0015-3140-a4e5-e90f98642a4f
2860	Happiness… Is Not a Fish That You Can Catch	0	\N	3	782	\N	4a81c79f-24ca-4a5c-9bfd-22d4b66ebbc5
2861	Happiness... Is Not a Fish That You Can Catch (bonus disc)	0	\N	3	782	\N	5e4fc7a1-f0c7-4800-9abc-df14d40dbbe7
2862	Clumsy	0	\N	3	782	\N	60e2f500-b11c-4275-b9a8-81b9adca2ee7
2863	Playlist: Very Best of Our Lady Peace	0	\N	3	782	\N	6d05efb3-678c-4df4-a865-6a80e13b8ae3
2864	A Decade	0	\N	3	782	\N	77f8b7a1-0dc8-4e63-a0e7-a7ed7de61646
2865	Happiness... Is Not a Fish That You Can Catch	0	\N	3	782	\N	78dfe1c5-3882-3fac-80e4-3958dddbdfc8
2866	A Decade	0	\N	3	782	\N	81293beb-b2b1-39d5-80dd-e066d88fba3b
2867	Burn Burn	0	\N	3	782	\N	86b7271a-f041-4e3a-a530-9a832b3ab3d4
2868	Burn Burn Burn	0	\N	3	782	\N	8b2a564e-6988-4a74-9a05-fbb2540e6cf6
2869	Healthy in Paranoid Times	0	\N	3	782	\N	8c770f2b-c0a6-3e38-941a-cb87641bfc01
2870	Happiness... Is Not a Fish That You Can Catch	0	\N	3	782	\N	923d5667-058b-456e-9e97-c573cfd0ebe3
2871	Healthy in Paranoid Times	0	\N	3	782	\N	967cf524-53dd-4dfb-920b-79a6d82fbac0
2872	Clumsy	0	\N	3	782	\N	a0221aa1-793d-3445-ad68-490bc3b7cec7
2873	Happiness… Is Not a Fish That You Can Catch	0	\N	3	782	\N	af7a568b-6ba4-44a3-8411-dcf1b8268375
2874	Gravity	0	\N	3	782	\N	af8ad488-072b-479a-a332-060ba2fd16c5
2875	Spiritual Machines	0	\N	3	782	\N	bcd6816a-5c7f-47d9-ac61-2e2e3252c374
2876	Happiness... Is Not a Fish That You Can Catch	0	\N	3	782	\N	dc16a6b2-57da-3112-a451-1da2dc767fb2
2877	Naveed	0	\N	3	782	\N	f0ef568c-758d-478a-8111-a2a1687c6608
2878	Naveed	0	\N	3	782	\N	f56feb1d-4a73-327f-8868-48d4a71dafa8
2879	Curve	0	\N	3	782	\N	f825d514-566e-4be4-a342-dbea0a74a920
2880	Forgetting the Way Home	0	\N	3	783	\N	73d08206-990f-43e4-8bbd-3a63744ecfd8
2881	Lady	0	\N	3	784	\N	491f3104-483d-4c85-91bf-c50edd0c4528
2882	Beauty Won't Save Us This Year	0	\N	3	785	\N	b6bd7237-8c56-42cf-9ee3-6364929c4b13
2883	Own the Night	0	\N	3	787	\N	16021c03-bb93-4dc0-8d18-45bc74866569
2884	On This Winter’s Night	0	\N	3	787	\N	17fd1401-103b-40de-b08d-141a33e12a84
2885	Golden	0	\N	3	787	\N	18979456-0c40-4062-a20d-3dc27515ed43
2886	Lady Antebellum	0	\N	3	787	\N	46e5e062-a32f-44f9-800e-3ea59ce048c6
2887	Golden	0	\N	3	787	\N	4bb43fbf-69d2-4652-9921-e1f48bb514ce
2888	Golden	0	\N	3	787	\N	5cbfdcf3-b886-4119-a9ca-76723e61d9df
2889	On This Winter's Night	0	\N	3	787	\N	6409f293-c62e-465a-930e-d3cb0ae44b3c
2890	Need You Now	0	\N	3	787	\N	6b463349-e26a-4706-880d-3b182f97f0a6
2891	Own the Night	0	\N	3	787	\N	6e709b21-50a0-43ce-bd76-afffe3c792f9
2892	747	0	\N	3	787	\N	6fd2e1f4-462f-414c-be05-9e9053fbad52
2893	747	0	\N	3	787	\N	7310873c-c773-405f-8ca7-fffa2925e0cf
2894	Need You Now	0	\N	3	787	\N	77ed9b0e-7ef8-42fe-b861-9b8d1a7c4c08
2895	Golden	0	\N	3	787	\N	87054562-3270-4b91-9d17-c6ef8a51b2ef
2896	747	0	\N	3	787	\N	962e7052-ebea-4841-b490-ba24de403652
2897	Golden	0	\N	3	787	\N	a8cb48ce-65ce-4929-8a54-ee9c6b4e676a
2898	747	0	\N	3	787	\N	cd38949a-059d-4e87-9fe9-8644b1f19b02
2899	Lady Antebellum	0	\N	3	787	\N	cee460c0-4987-4708-a429-412a0324b159
2900	747	0	\N	3	787	\N	d88ca9f2-6f8b-486a-ba7e-e65050567961
2901	Need You Now	0	\N	3	787	\N	f143288b-3b88-421d-a4a2-c06752cf5e04
2902	Life in Between	0	\N	3	790	\N	7a5bebfe-634e-4917-bdfd-86e8a2b781ef
2903	Hisses and Kisses	0	\N	3	792	\N	6048d6ee-ee54-48e3-a7e4-dccc5a58cd0c
2904	American Dirt	0	\N	3	792	\N	7881df9a-11c3-469c-9a38-a131835afcbc
2905	Couture, Baby!	0	\N	3	792	\N	85283c29-2e1c-4ea4-bb08-6314ed12709f
2906	Enchanted	0	\N	3	793	\N	d698343b-7461-4978-b4ad-e146850f19a6
2907	Nightlife: The Collection	0	\N	3	794	\N	02519613-9cde-41b4-91a1-be003dcfabbe
2908	Moving Windows	0	\N	3	794	\N	d1bfc8fb-08f3-4619-ae08-966b23c51229
2909	Back Home Americana	0	\N	3	795	\N	1a1c1597-ad47-463c-96dd-0e357f6fb481
2910	Spanky and Our Gang	0	\N	3	795	\N	2a2fd5dc-b0e1-4f33-8b58-2be993117c79
2911	Greatest Hit(s)	0	\N	3	795	\N	3a501304-2b1c-4eb4-bdde-d76b9caea959
2912	Like to Get to Know You	0	\N	3	795	\N	58970844-7d7d-4daf-a2b0-1e2ac34f077f
2913	The Complete Mercury Recordings	0	\N	3	795	\N	863d8f73-d5aa-4bc5-a0e5-548029656433
2914	Spanky’s Greatest Hit(s)	0	\N	3	795	\N	86b587ab-9ec3-34bd-9200-7302c03a1090
2915	Greatest Hits	0	\N	3	795	\N	af68cc26-70c7-4997-bc5c-689c796ccc9b
2916	Without Rhyme or Reason	0	\N	3	795	\N	eb905e78-270c-441e-9a56-7b12f4b51235
2917	Without Rhyme or Reason	0	\N	3	795	\N	f5f90b11-1726-4f86-a1e1-5e92d252cbdb
2918	We Will All Evolve	0	\N	3	796	\N	0eb83bb8-aa29-4957-a5da-99ce0a2b0a32
2919	The Ghosts Among Us	0	\N	3	796	\N	2f2d4486-3aa5-4463-a91f-9e2aa994d14c
2920	Younger Dreams	0	\N	3	796	\N	6c5b1969-87ff-4d34-b819-35f76be4d055
2921	Age of Ignorance	0	\N	3	796	\N	a0916036-6768-46df-991c-48d8eba6fbc5
2922	Age of Ignorance	0	\N	3	796	\N	c5d57628-fec9-44a5-9a84-878096a5dc16
2923	Sacred Psalms	0	\N	3	797	\N	35e1d729-31ce-453f-8e29-aa4a618a4ae6
2924	Make Amends for We Are Merely Vessels	0	\N	3	797	\N	a4400c93-20c7-4caf-aff5-133f683aafbf
2925	Tooth and Claw	0	\N	3	797	\N	e1a87658-9b75-41a2-9928-7083091d491f
2926	Hard to Be Human	0	\N	3	798	\N	5a6a8a29-f504-480a-9db8-410b0a4eba14
2927	Are We Innocent?	0	\N	3	798	\N	f2539cc5-b48a-4d4c-a56a-238dd7292c62
2928	The Darkest Storm	0	\N	3	800	\N	ce62d6e0-38ff-43fc-b226-36a2e7903a9d
2929	First Lady Assassins	0	\N	3	804	\N	7f1187d2-1ec9-4521-9989-b80289ee9500
2930	The Lady Crooners	0	\N	3	805	\N	784d8887-d610-4369-8ab2-74c43f863d63
2931	Things We Can See and Things We Cannot	0	\N	3	806	\N	58d7b43b-73ae-4c7e-b0ab-f047e931e716
2932	Beneath Our Noble Heads	0	\N	3	806	\N	f49be3e2-8d0b-4344-a48d-e93072243ec4
2933	All the Things You Said...	0	\N	3	807	\N	498c198d-4ffa-4b5b-8422-b040e651361e
2934	Standing Room Only	0	\N	3	807	\N	51c1ebf8-9e3f-40dd-b04c-b0561ee9934f
2935	In All Honesty	0	\N	3	807	\N	cd83ae81-c886-4839-94b2-9d08f0861220
2936	The Singles Collection	0	\N	3	809	\N	2842b197-bed8-40bd-9c1e-083373a9df50
2937	Control Me	0	\N	3	809	\N	6224bbe7-0898-4b0c-9ae0-65b65554a2de
2938	The Forgotten	0	\N	3	809	\N	a30e5c8b-8962-4684-a22c-675be90fbef1
2939	Keep the Corpses Quiet	0	\N	3	809	\N	a59234a6-10de-45a3-a16d-514998ef2e40
2940	Out of Print	0	\N	3	809	\N	bcc7f2a7-7240-449c-b975-01d760aee825
2941	Veni Vedi Vici	0	\N	3	809	\N	d713f9db-9326-4c08-a15d-d1fcf79406fc
2942	Tourism / Terrorism	0	\N	3	813	\N	65e882c3-571f-4a6b-ac02-a2e4ce59fb88
2943	The So So Glos	0	\N	3	813	\N	d5b9bcc4-d6f5-4372-8d5c-4434bbaa3a4f
2944	Blowout	0	\N	3	813	\N	dad2237f-6949-4f2e-a97e-9282f1579069
2945	Amid the Noise	0	\N	3	815	\N	31abeb77-e2ee-4ed9-b815-347345e6f27a
2946	Paul Lansky: Threads	0	\N	3	815	\N	cd309817-a210-4527-a728-838bd141cf30
2947	Where (we) Live	0	\N	3	815	\N	d6852fb5-c318-4fe0-8aab-4903426ed239
2948	Treasure State	0	\N	3	815	\N	e31b9bbd-da92-4c6c-afca-0ce545b34cfd
2949	So Percussion	0	\N	3	815	\N	ecb2c994-4086-4fe5-b55b-8bd482b3e70e
2950	Steve Reich - Drumming	0	\N	3	815	\N	f39c44dd-eddd-4e60-a744-4c609b9b59b7
2951	Sleepwalker	0	\N	3	818	\N	88675311-06c8-4e2a-b6cb-c8faf74a5ddc
2952	Rough Night in Jericho	0	\N	3	819	\N	65f2e413-e7e7-47a9-b4c4-9d0032aaec47
2953	Rough Night in Jericho	0	\N	3	819	\N	6902adb2-1b85-40ce-85d2-6b865a0a31d0
2954	Gloryline	0	\N	3	819	\N	fa0779e8-18fe-46b2-a694-5b81b9c03fe5
2955	What You Don't See	0	\N	3	820	\N	1907fc90-db86-4e51-9411-a78aba1084f8
2956	Under Soil and Dirt	0	\N	3	820	\N	46721ca0-b386-437a-a8ff-06e83e3e1cf1
2957	The Story So Far	0	\N	3	820	\N	a201f07f-28b7-4a69-a856-47f2c413bc16
2958	The Story So Far	0	\N	3	820	\N	efcd7ca3-71f1-413c-b319-80a681f243d5
2959	Receiver	0	\N	3	821	\N	315a6435-ecf6-483b-b0fe-4df061a7b6c3
2960	Farmer Not So John	0	\N	3	821	\N	92a82d14-594d-49c8-96ca-71664aa98114
2961	Van Full of Pakistans	0	\N	3	822	\N	c931591c-7ea5-439f-a0b2-6f4248dea425
2962	Antidote for Irony	0	\N	3	823	\N	56b5d090-5b4e-4f16-ba0c-4b1e9aa6182b
2963	Life in Surveillance	0	\N	3	823	\N	71131b7a-e1d0-4f1c-9e0a-c8097bc1aec0
2964	The Loud Wars	0	\N	3	824	\N	44ece3d1-c698-4f0e-8f8c-7a11632c1188
2965	Safe With Sound	0	\N	3	824	\N	4d91204f-bf84-402f-88bb-136044a6390f
2966	When I Explode	0	\N	3	824	\N	eaa1aedc-0e4e-4140-9259-1693d3f1931f
2967	The Loud Wars	0	\N	3	824	\N	f0e2384d-7d6e-4aff-a4e4-f4c650d09a87
2968	Flashlights	0	\N	3	824	\N	f43f415b-2638-4ad0-b933-f1705978b2b8
2969	Felt Not Seen	0	\N	3	826	\N	8eddeb67-8e02-455e-a955-ff7ec7689fae
2970	Smoke n' Tats	0	\N	3	827	\N	056b4217-5f92-4aa3-afcd-e4b52b9748a6
2971	LBDA and Friends	0	\N	3	827	\N	87c0d6b9-1994-49fc-ba78-4ede1c279bab
2972	Wonders of the World	0	\N	3	827	\N	a286919f-5b13-4516-8b86-2952b1cf9391
2973	Wonders of the World	0	\N	3	827	\N	e30e2795-d3ee-4506-b1ed-80b1618d7411
2974	Right Back	0	\N	3	827	\N	fbfac649-0ebe-4801-b80c-f24bf29acfb1
2975	Before the Dawn, So Go the Shadows of Humanity	0	\N	3	828	\N	7ac83292-4360-4921-9216-0e5cb082df20
2976	The Tears of Odin's Fallen	0	\N	3	828	\N	c36e2ed7-7235-4a34-929d-e3ba5deb6511
2977	Native Sons	0	\N	3	829	\N	039ef0c0-59b5-328f-af17-170fb5fa7afa
2978	The Best Of	0	\N	3	829	\N	0d2dc3b1-248a-4a67-a915-7e0188e0ee56
2979	Native Sons	0	\N	3	829	\N	173dec2b-5f0b-40d7-80d7-822a1d49c87e
2980	Metallic B.O.	0	\N	3	829	\N	1db48757-a96a-4249-8e6f-14ef4a4d1b0a
2981	Anthology	0	\N	3	829	\N	2d2f81c8-ded3-4fab-a508-23e1b2b631b9
2982	End of the Trail	0	\N	3	829	\N	6f3f0aec-26b1-477d-8bd0-11d42b35f7f1
2983	Native Sons	0	\N	3	829	\N	886bdbdf-ab62-41b5-9292-b0a53ccf3129
2984	State of Our Union	0	\N	3	829	\N	88fad8e0-9cbf-4677-ae45-285aa68fe5e5
2985	Two Fisted Tales	0	\N	3	829	\N	93af0079-d9b0-4fd1-ad63-f012f681167c
2986	10-5-60 / Native Sons	0	\N	3	829	\N	94256299-3573-4aa7-9fb4-2f37b75cf987
2987	State of Our Union	0	\N	3	829	\N	b0bb8529-b54e-47a2-a3c0-5d06a07c64e1
2988	Three Minute Warnings: Live in NYC	0	\N	3	829	\N	cd2491e3-0cb5-425e-8ecd-25c44fbd461c
2989	Putting the Days to Bed	0	\N	3	830	\N	3227a16c-e06e-4185-98db-e775c5bb28b6
2990	The Long Winters Live at Cat's Cradle	0	\N	3	830	\N	33344065-204e-409f-ae3e-c70285eea9fc
2991	When I Pretend to Fall	0	\N	3	830	\N	3e5e8698-8ed5-4807-ba58-dc91e1685a37
2992	The Worst You Can Do Is Harm	0	\N	3	830	\N	61dfc0c1-9057-41c5-b788-a8cfe26c633a
2993	2006-10-04: Lee’s Palace, Toronto, ON, Canada	0	\N	3	830	\N	b798a8f4-8e50-439d-82b7-63c2db3cbc3a
2994	When I Pretend to Fall	0	\N	3	830	\N	d9842097-0c7a-4825-8719-ddb0ffc66b0f
2995	Putting the Days to Bed	0	\N	3	830	\N	e1f75d97-4bb0-40ae-a16d-da168a7e45da
2996	Take It to the Floor	0	\N	3	831	\N	7aa687a2-1a29-4f6a-8d95-5d730c9e56c1
2997	Love or Lust	0	\N	3	831	\N	ee5ba864-4a7f-4d80-9128-16c5b74de440
2998	Baller Blockin	0	\N	3	836	\N	77bb7662-4ad6-4d0f-84fb-6eedd50961e4
2999	Walk Alone	0	\N	3	840	\N	28ac7652-3f4d-4b9a-a38e-3412d30164da
3000	Road To Texacali	0	\N	3	840	\N	2ab5b34e-c663-4fc5-8a51-13a549a77362
3001	Distance Between	0	\N	3	840	\N	7ba64492-809d-4303-a53d-badcbdf56135
3002	Mile Markers	0	\N	3	840	\N	c2f65c6a-9eca-4d0e-9126-481e0ebf470f
3003	Walk Alone	0	\N	3	840	\N	e366df4e-6240-4799-a0b0-3a945969fda4
3004	Newport Folk Festival 1964	0	\N	3	841	\N	046648db-d893-4b59-8bfd-0f28d27a3e02
3005	Hymns by Johnny Cash	0	\N	3	841	\N	0f886717-25b1-414c-9501-66414e349ecd
3006	Hymns From the Heart	0	\N	3	841	\N	1b0000e0-66de-45bc-ae78-e18350cd66a7
3007	Ride This Train	0	\N	3	841	\N	25483e71-dd4b-4285-be08-16122a79baee
3008	The Sound of Johnny Cash	0	\N	3	841	\N	27660dcb-1817-42e7-86f5-e787c2163009
3009	The Fabulous Johnny Cash	0	\N	3	841	\N	2b9ade93-a77f-4b6f-ba55-659690648bbd
3010	Songs of Our Soil	0	\N	3	841	\N	33770ccc-a714-42f3-8f53-8762a2818e8b
3011	Bitter Tears	0	\N	3	841	\N	4a9fc881-79aa-4304-a3a6-3aa75d041dfe
3012	Johnny Cash With His Hot and Blue Guitar	0	\N	3	841	\N	5434e59f-b666-43b3-8503-081bfca307eb
3013	Sings Hank Williams	0	\N	3	841	\N	6014e45e-4b1f-402b-a02a-d20ceff916d0
3014	Sings the Songs That Made Him Famous	0	\N	3	841	\N	62120f48-62e9-4745-8ca6-3e7ac1b7052c
3015	All Aboard the Blue Train	0	\N	3	841	\N	6ca452fe-e53f-4314-bbd0-9ef95447d120
3016	The Lure of the Grand Canyon	0	\N	3	841	\N	72202a29-a685-4a0b-9487-475f32ea5839
3017	I Walk the Line	0	\N	3	841	\N	73999e32-4739-485a-a96f-819fd7f69fe5
3018	Original Sun Sound of Johnny Cash	0	\N	3	841	\N	74790204-ca62-49fa-b647-02382486db44
3019	Greatest!	0	\N	3	841	\N	7e6cb4cb-83b6-48f6-8b1b-451286ed6d8a
3020	Now Here's Johnny Cash	0	\N	3	841	\N	8810ac93-e31c-4f68-af63-902eb42d12fb
3021	Blood, Sweat and Tears	0	\N	3	841	\N	89984638-5af3-47d0-a1f5-a02c03d7e13a
3022	Now, There Was a Song!	0	\N	3	841	\N	96e4b253-1d0d-43ea-8e78-18352acfd439
3023	Ring of Fire: The Best of Johnny Cash	0	\N	3	841	\N	9c18f70b-bd0a-4cc2-b317-15a8c778f5ef
3024	Sings Hank Williams	0	\N	3	841	\N	b7cd7102-174a-458e-8ed8-994ee76bf044
3025	I Walk the Line	0	\N	3	841	\N	b889cbcd-c618-3c8f-87f1-3f4133d70da9
3026	The Christmas Spirit	0	\N	3	841	\N	cbfe0a1d-5f0b-4a9d-8768-90ec56c487f2
3027	The World of Johnny Cash	0	\N	3	841	\N	e5f62cf7-0f6a-4fce-a9f6-11feb0a73218
3028	Keep on the Sunny Side	0	\N	3	841	\N	e97235dc-f49c-4f48-9163-ee3c4049fd69
3029	Rules of Travel	0	\N	3	842	\N	0b2646a5-fe87-49e8-aaf5-b875e9cce57d
3030	Interiors	0	\N	3	842	\N	0c0a7278-90d9-4b96-a175-a10b82cf81de
3031	King's Record Shop	0	\N	3	842	\N	0dae598b-683b-499e-acbc-cd8b43444642
3032	Rhythm and Romance	0	\N	3	842	\N	13decb90-56a2-475c-8f79-49cc19e5f06e
3033	Rosanne Cash	0	\N	3	842	\N	1646387f-39da-494a-8474-75911781432f
3034	Super Hits	0	\N	3	842	\N	37c4d1ad-13f4-4938-bb63-2e904660a275
3035	Right or Wrong	0	\N	3	842	\N	381df899-43e6-4fa9-83c5-cae3659a5426
3036	Right or Wrong	0	\N	3	842	\N	3ba6e352-3184-484c-8b0b-20da184e6f38
3037	Favorites	0	\N	3	842	\N	5159e4c4-8028-48b0-be1b-40075a5cbafc
3038	Hits 1979-1989	0	\N	3	842	\N	52ec97f4-1d1a-4f2e-8e9a-12e0a59e4f1b
3039	Seven Year Ache	0	\N	3	842	\N	575ef5cf-1f02-4325-a7b4-5b89edd980d8
3040	Somewhere in the Stars	0	\N	3	842	\N	677dc6a5-430f-4d33-a04f-56529a281099
3041	Seven Year Ache	0	\N	3	842	\N	77fc797a-d7c6-4e34-bb28-09458a0745a1
3042	Blue Moons and Broken Hearts: The Anthology 1979-1996	0	\N	3	842	\N	94163d20-4530-45a7-8f48-51b3c9e9831c
3043	Somewhere in the Stars	0	\N	3	842	\N	95f5819f-d13a-428b-aa10-4ab162f28d3c
3044	King's Record Shop	0	\N	3	842	\N	98fbd341-031e-481c-85ff-7a662d82f4ce
3045	The Wheel	0	\N	3	842	\N	a17243ba-a0d7-4d86-8fb2-fdc2bae07bc7
3046	Rhythm and Romance	0	\N	3	842	\N	a849e961-0da3-4c38-8e64-aa971f9a6e65
3047	Rules of Travel	0	\N	3	842	\N	b15707b9-5d0c-4349-a884-a0730216239f
3048	Retrospective	0	\N	3	842	\N	b7e60e7b-f0da-4e71-bb6f-2ae992e5d025
3049	Right or Wrong	0	\N	3	842	\N	b93d42d4-f582-49fc-a2bf-4ff516f10b21
3050	Right or Wrong	0	\N	3	842	\N	cbf33435-c119-4cd9-9d4f-509afcb12334
3051	The Wheel	0	\N	3	842	\N	e131c951-ed13-4e71-abe4-62a6724e6613
3052	The Very Best of Rosanne Cash	0	\N	3	842	\N	e18ed670-b624-4611-a92d-f6eb589d275c
3053	10 Song Demo	0	\N	3	842	\N	f3293d60-db10-4ea7-9cc3-7c551bd5ac8a
3054	Travellin' alone	0	\N	3	845	\N	245a809a-afda-453c-8b7b-a16fd1e87d9e
3055	The Vintage Room	0	\N	3	845	\N	50e204cc-e7de-4641-ad6c-49041272410b
3056	Cash Up Front	0	\N	3	845	\N	b9924a85-562e-42a4-aa95-a661bd543984
3057	A Musical Tribute: "My Brother Johnny Cash"	0	\N	3	846	\N	098ae8ee-a63f-43ca-af7a-979ad8f60387
3058	The Very Best of Tommy Cash	0	\N	3	846	\N	692ba0ca-c3a0-4cc5-901b-8e5b8f64a964
3059	Cash on Delivery	0	\N	3	848	\N	45562d89-0c2a-481d-a367-9977891e32bd
3060	How Will I Know If I'm Awake	0	\N	3	850	\N	65e2948f-e853-4748-bb4f-e32493843b13
3061	Music for Pets	0	\N	3	856	\N	0a3d639c-85f4-352a-887e-a2879df83249
3062	Shampoohorn	0	\N	3	856	\N	1739ebbe-4c64-4c5b-be0c-be1dd10a1eab
3063	Music for Pets	0	\N	3	856	\N	ce149725-5102-4150-8921-428c1a89867f
3064	Shampoohorn	0	\N	3	856	\N	d1a9e4a9-21a3-40cf-87ba-8d9c3ceaa9bd
3065	Shampoohorn	0	\N	3	856	\N	d1c58a91-a37c-40af-9bd2-f4f2fd8a5450
3066	Music for Pets	0	\N	3	856	\N	e69de65b-6904-4691-ba23-8bbcc36f4a9a
3067	Music for Pets	0	\N	3	856	\N	edea9056-e39d-4414-85ed-fcb0567fadc3
3068	Tearing At Your Mind	0	\N	3	857	\N	4ac9e500-40dd-4af0-bd40-bb80f999899c
3069	Soul Existence	0	\N	3	857	\N	c24461f2-9470-4d60-ac82-09bc71d5314f
3070	The Machine	0	\N	3	858	\N	5148962d-8a4e-407b-b1cb-483508286a8b
3071	Doodle’s End	0	\N	3	860	\N	86e806fa-4496-49db-80bb-284a516c2555
3072	Revo	0	\N	3	860	\N	e2b54e9f-a65c-4b3c-92d1-7017925bac8c
3073	It Takes Two	0	\N	3	862	\N	95eff70c-d32b-36da-ac66-0c4a7715f3c4
3074	It Takes Two	0	\N	3	862	\N	9fe0341e-f80a-3ec0-afab-1511363cbcf9
3075	Break Of Dawn	0	\N	3	862	\N	a427b255-3003-4039-a6c9-88e5bf5ecb64
3076	It Takes Two	0	\N	3	862	\N	b5fe6c0b-9793-4ece-892a-1b1080ea26c9
3077	Vol. 3... Life and Times of S. Carter	0	\N	3	863	\N	06355f9d-12a7-4d08-aa10-5ad271b83625
3078	Rocafella Mixtape	0	\N	3	863	\N	0bd50ba0-a2fb-4bf7-93ca-db295c8e93ec
3079	The Blueprint	0	\N	3	863	\N	189fcd86-27f0-4c60-9c7c-51c8eaf3668c
3080	In My Lifetime, Vol. 1	0	\N	3	863	\N	2e2275ab-b93c-45ff-b76c-9e0153599758
3081	In My Lifetime, Vol. 1	0	\N	3	863	\N	313cf6ad-2899-4769-b5c4-211d99890f11
3082	Reasonable Doubt	0	\N	3	863	\N	37c0a6b5-f723-4e70-92b8-805a569bc436
3083	Reasonable Doubt	0	\N	3	863	\N	3cf3b73a-10e2-31ad-852a-02f9f5bae5c4
3084	The Blueprint	0	\N	3	863	\N	3d3b0245-6bfb-3b89-9232-e9108e6cbdd3
3085	Vol. 2... Hard Knock Life	0	\N	3	863	\N	53b9bb76-b151-4e45-ba51-316ada3f724e
3086	Vol. 3... Life and Times of S. Carter	0	\N	3	863	\N	6d7c9826-8631-4805-9632-580ba525a2cb
3087	In My Lifetime, Vol. 1	0	\N	3	863	\N	756210c6-33c5-4093-8ffc-8aa89b5f3ce4
3088	Unplugged	0	\N	3	863	\N	7d56a02e-3ed5-4bcc-a218-98c3cda45665
3089	UnPlugged	0	\N	3	863	\N	904e0d41-d49c-429e-8568-235bedbec612
3090	In My Lifetime, Vol. 1	0	\N	3	863	\N	94fd4091-916d-4d90-acb0-64e80b98635a
3091	Vol. 3... Life and Times of S. Carter	0	\N	3	863	\N	9618f3dc-b057-40aa-9062-e92a0ec78455
3092	Reasonable Doubt	0	\N	3	863	\N	97d1b9b9-bde6-3fb3-bc6e-c899608946cf
3093	The Hits & Unreleased, Volume 1	0	\N	3	863	\N	98d338dc-2979-4e76-8492-050e9281e210
3094	Vol. 3... Life and Times of S. Carter	0	\N	3	863	\N	9b0bf4a4-c3e8-457f-bad3-a7895a78d807
3095	The Dynasty: Roc La Familia	0	\N	3	863	\N	9d1da9b6-c9e1-4787-81a5-eea806ecf470
3096	In My Lifetime, Volume 1	0	\N	3	863	\N	d09eea3c-1871-48f1-975f-6193a6bcaf1f
3097	Vol. 2... Hard Knock Life	0	\N	3	863	\N	d63e3bc1-f00c-4dd8-abb1-cbc014ad2063
3098	The Blueprint	0	\N	3	863	\N	ddf74bde-72d0-456c-a772-6f5c2840eac4
3099	Reasonable Doubt	0	\N	3	863	\N	e9a5f123-447f-4430-8efb-0921e1761ddf
3100	The Dynasty: Roc La Familia	0	\N	3	863	\N	f1816299-b745-3e1c-9d52-ca935e553a8f
3101	Vol. 3... Life and Times of S. Carter	0	\N	3	863	\N	ff7001c4-d7d7-4581-929b-bed1c2488029
3102	All Pro Soundtrack	0	\N	3	864	\N	3b470375-8ebb-48e1-b443-002ece0e49f0
3103	Uneasy Listening, Volume 1	0	\N	3	864	\N	506360a6-2e7d-47b4-af32-cfc1521c7f7c
3104	Ahead of the Curve	0	\N	3	864	\N	7060f81c-46a6-43b5-8ed0-083a6fcf91fe
3105	Urban Revolutions: The DJ Z-Trip Megamix	0	\N	3	864	\N	75ff182e-3087-468b-a5b6-715f3e41a9f1
3106	B-Boy Breaks, Volume 3 (disc 1)	0	\N	3	864	\N	8af3f627-5b6b-43c1-9c61-965787dd8350
3107	Live at the Future Primitive Soundsession: Volume Two	0	\N	3	864	\N	9b07494e-ae0a-469e-ab4a-cfe7f04a2a23
3108	Shifting Gears	0	\N	3	864	\N	a3bc7998-a11f-414e-9d84-babf2696133e
3109	Ahead of the Curve	0	\N	3	864	\N	b91e6446-fb72-44b0-ad62-b73e2f72d6de
3110	Anytime...Anyplace!	0	\N	3	865	\N	73e95079-fa23-4958-bd1f-7ac6dfa95852
3111	Basic Need to Howl	0	\N	3	866	\N	516632c2-bf63-4651-80f1-bb9c2561c12b
3112	Live & Bumpin'	0	\N	3	866	\N	6fefcb99-6daa-480b-a56c-4897fb1799b4
3113	Up on the Hill: Live in Athens, Greece	0	\N	3	866	\N	997aa963-6415-44e5-8b00-19ca459e0a8c
3114	Life (Slowed & Chopped)	0	\N	3	868	\N	08bcb617-3691-4440-8809-56900e263966
3115	4/20: The Smokers Anthem	0	\N	3	868	\N	0adc98d7-68c3-4ca0-bb6f-07e29e38130e
3116	I'm Still Livin' (Chopped & Screwed)	0	\N	3	868	\N	13e9aafe-fdb0-4c36-98c3-ee8b3703c2dc
3117	Z-Ro vs. The World	0	\N	3	868	\N	14dee7ac-f275-4395-9223-854c0ae9fec2
3118	Life	0	\N	3	868	\N	1beca1b9-9878-4710-80da-5ed40786f081
3119	Z-Ro Tolerance	0	\N	3	868	\N	1f79a409-604c-438c-8c5d-53d12e4eb691
3120	Limited Edition 1 Deep: Slowed & Chopped	0	\N	3	868	\N	3fbc3d21-be6f-477f-8a0c-276c09f04976
3121	Underground Railroad, Volume 1: Street Life	0	\N	3	868	\N	45b3ba43-312e-4458-ad43-683a03ef4cc5
3122	Kings of the South	0	\N	3	868	\N	4a1e0388-2799-483e-bde1-fde75ed2d011
3123	Z-Ro's Underground Railroad, Volume 2: Thug Luv Hulled & Chopped	0	\N	3	868	\N	5936f4ef-1a19-43ae-b902-8f5003a3dd1e
3124	The Life of Joseph W. McVey	0	\N	3	868	\N	5ca957cd-9d8e-4371-bf74-9b4ff639505a
3125	Screwed Up Click Representa' (Slowed and Chopped)	0	\N	3	868	\N	6e2d5b9b-c674-4f6b-a634-6a3308c198ff
3126	Gangstafied	0	\N	3	868	\N	7f2b2d3f-1594-4ede-ab26-5e73f3ad7bb3
3127	Z-Ro Tolerance (Slowed and Chopped)	0	\N	3	868	\N	81d73a5b-2cbc-490a-939e-2ae7facec0bb
3128	The Life of Joseph W. McVey: Screwed & Chopped-A-Lot	0	\N	3	868	\N	93dc8be7-fe88-45b3-9e00-3cf899749c0a
3129	Southern Lean, Volume 3	0	\N	3	868	\N	9da44ccf-0a3f-48b9-ab5b-a639b568e51a
3130	Limited Edition 1 Deep	0	\N	3	868	\N	a749cd31-9378-47f6-9d8c-35078df94bef
3131	King of Da Ghetto	0	\N	3	868	\N	a7725bce-d7ec-41ac-84ab-d8c8891ac2eb
3132	Look What You Did to Me	0	\N	3	868	\N	ae048377-0bfb-4aa0-970d-d77c660314db
3133	Let the Truth Be Told (Chopped and Screwed by DJ Paul Wall)	0	\N	3	868	\N	b1f3768e-87ab-4159-af72-cd64e82393d7
3134	Screwed Up Click Representa'	0	\N	3	868	\N	c853e6f6-8935-4686-9ea9-d597631800d6
3135	Let the Truth Be Told	0	\N	3	868	\N	eb164b35-ef7b-4180-b964-4dfce35225ca
3136	King of Da Ghetto	0	\N	3	868	\N	ec1c0002-b22c-4360-ab08-5e612f1a3295
3137	Z-Ro	0	\N	3	868	\N	ef9d16aa-e974-4996-a76b-d88d3c807657
3138	I'm Still Livin'	0	\N	3	868	\N	fe7cd793-2db0-4e8c-b76e-43ec056b3010
3139	Room of One's Own	0	\N	3	872	\N	03445d5a-7b28-4380-ace2-3291ef51833b
3140	First Time Ever I Saw Your Face	0	\N	3	872	\N	2c0929d2-2050-411c-8c01-3bf6f6f8784d
3141	Grace	0	\N	3	872	\N	4782efd3-656a-3663-84b0-77b93e24bbae
3142	Grace	0	\N	3	872	\N	6b15384c-afc7-4a5c-976c-4826d5e312b1
3143	Love Is the Power	0	\N	3	872	\N	9dabfa3d-cafe-4688-b259-f873ac801702
3144	Everlasting	0	\N	3	872	\N	bf4d62fe-54da-410d-b02e-e23a818f0605
3145	Moon at the Window	0	\N	3	872	\N	e728386e-697e-4e46-a9aa-abe2c62801c7
3146	Trust the Universe	0	\N	3	872	\N	ef25bc27-3c96-4d72-80d2-c03dbb57a126
3147	Grace	0	\N	3	872	\N	f58dc4e8-aaaf-4138-974e-aaa01503eb08
3148	Heart of the Holidays	0	\N	3	874	\N	58c67444-d906-4173-9f7e-27bf8ea6d720
3149	Roots: The Solo Piano Album	0	\N	3	874	\N	781ec79b-9964-42c9-a103-aabb0db25b0f
3150	Life Between The Lines	0	\N	3	874	\N	853119fd-3d44-4f2a-adf9-1c2a11c2c163
3151	Window To The World	0	\N	3	874	\N	9d08874a-db8a-4561-ab52-dfd1c2c2fb3c
3152	The Vegetable and the Ferret	0	\N	3	875	\N	063e202d-d5bb-4528-90ae-8801e6bc6fec
3153	Dope or Dog Food?	0	\N	3	875	\N	87ad7c18-200d-4803-b1a0-5ad6dd1cbf3b
3154	Don't Forget to Brag	0	\N	3	875	\N	b54e339e-b054-4039-afba-adcd7c11be7f
3155	Anti Nerd	0	\N	3	875	\N	ef24c537-aa98-4096-9679-a2ccc54b88ee
3156	Dance Party Album	0	\N	3	876	\N	178d9ea0-40d6-4927-b524-a1e54eaf74d0
3157	Dance Party Album	0	\N	3	876	\N	7e7e89c0-506a-4842-9305-606887c047c0
3158	Summer in Andyland	0	\N	3	878	\N	2f118ea5-7bc6-45cd-b336-23a180834bb8
3159	Summer in Andyland	0	\N	3	878	\N	44f24b2a-430d-42f1-98eb-9e3518ca124c
3160	The Grand Scream of Things	0	\N	3	878	\N	89068360-1a5e-45a3-8c45-1ccbaeb1b354
3161	Welcome to Andyland	0	\N	3	878	\N	b699954b-b19f-47fd-a135-24df9c22c046
3162	Return to Andyland	0	\N	3	878	\N	d154c571-e8ca-4238-821e-773da9a47a51
3163	Pockets	0	\N	3	878	\N	dce2fff1-8e73-4e1c-9a9d-1abe4ac7b461
3164	Classic Songs & Traditional Tunes	0	\N	3	878	\N	e7db24bf-16f5-4009-a3ef-3864a6252719
3165	Word Pimpin 2: We Don´t Need You	0	\N	3	879	\N	230b8dd0-c54c-471d-adb0-f819baaa4864
3166	Word Pimpin'	0	\N	3	879	\N	7c551006-c08a-491b-98c2-6124aa26dafa
3167	Via veneficivm	0	\N	3	880	\N	9296013d-4f89-4ddf-9c60-adb2af0427a0
3168	Too Tough to Die	0	\N	3	881	\N	131fccf2-74a5-480c-b786-6bef1ab1f73e
3169	It’s Alive	0	\N	3	881	\N	18fa7f05-6417-4fda-9750-9ffe905de3d3
3170	Road to Ruin	0	\N	3	881	\N	1f40b8b2-dd27-4554-8e64-0139a6b5bb39
3171	Too Tough to Die	0	\N	3	881	\N	222815f5-60d7-4dd9-a13f-fcc1a587fbce
3172	Animal Boy	0	\N	3	881	\N	29dffb41-a823-4986-ac33-0eb617f981c2
3173	End of the Century	0	\N	3	881	\N	3894823e-fd0f-499a-b070-c732c3380983
3174	Pleasant Dreams	0	\N	3	881	\N	443bf970-9955-4ca2-b883-6b2e165c1b2c
3175	End of the Century	0	\N	3	881	\N	58dcd354-a89a-48ea-9e6e-e258cb23e11d
3176	End of the Century	0	\N	3	881	\N	5abd37ec-212d-4e91-8daf-0bbd8c4a349e
3177	Ramones	0	\N	3	881	\N	627e3a2a-2df4-46c3-afb3-f734dcc90100
3178	Subterranean Jungle	0	\N	3	881	\N	6ab75ca9-acf5-4780-9ee9-b3a366892aea
3179	Subterranean Jungle	0	\N	3	881	\N	6bc092cc-1ca1-4343-88c4-bc32b6c2d937
3180	Pleasant Dreams	0	\N	3	881	\N	6d4dcb7b-724b-4eb8-a795-a653566f17ca
3181	Too Tough to Die	0	\N	3	881	\N	71f1e338-5d93-33bd-8146-bf150d729d36
3182	Animal Boy	0	\N	3	881	\N	767128a5-bab2-3dda-a733-0c72d7ae4908
3183	March of the Pinheads	0	\N	3	881	\N	78d10f57-4d66-4524-ba24-a24008e783f0
3184	It's Alive	0	\N	3	881	\N	855d6a21-b30f-4e7d-a68d-0ed3b6b92e30
3185	It’s Alive	0	\N	3	881	\N	912c080c-92b4-31ed-86d6-42340fdbd963
3186	1976-05-15: CBGB's, New York, NY, USA	0	\N	3	881	\N	b9844929-ba1d-47a4-b789-19753bad52cf
3187	Ramones	0	\N	3	881	\N	dbebf0d3-0b65-30a5-a3be-296709c5d3df
3188	Rocket to Russia	0	\N	3	881	\N	dd7b900f-d365-408b-bb05-9a91b9cd89b7
3189	Leave Home	0	\N	3	881	\N	e7bc233e-4aa4-4d7d-9960-6bd3d2472d92
3190	Leave Home	0	\N	3	881	\N	f0e1924d-3160-478e-aa93-dbf5fedfd012
3191	Blitzkrieg ’76	0	\N	3	881	\N	f8edd6ed-2919-4970-a891-69ca09fcf5c7
3192	Rocket to Russia	0	\N	3	881	\N	fe855f90-57ac-4227-9d4c-dc9223a89cbb
3193	Así nomás	0	\N	3	886	\N	bae7b573-e89e-4676-80bc-e3b850c92e4d
3194	The Downward Spiral	0	\N	3	893	\N	0d9e2d13-3a3b-4823-b7bf-1f992697c527
3195	Pretty Hate Machine	0	\N	3	893	\N	11707c8f-3359-3ea9-a932-91a8ed7f2293
3196	Pretty Hate Machine	0	\N	3	893	\N	1bef5a7f-8736-3f06-b973-e06cd75fa48e
3197	Pretty Hate Machine	0	\N	3	893	\N	24019d61-f0bb-30e3-b54a-2cedbd67052b
3198	The Downward Spiral	0	\N	3	893	\N	299d12ca-adee-4730-80df-61f4be276754
3199	The Downward Spiral	0	\N	3	893	\N	2d410836-5add-3661-b0b0-168ba1696611
3200	Pretty Hate Machine	0	\N	3	893	\N	32bd8089-32b8-3b54-bf11-fb079aa47a2e
3201	Demos & Remixes	0	\N	3	893	\N	4dda94c6-d2ff-3b81-990c-3c3be26a2498
3202	Solid Gold Hell	0	\N	3	893	\N	59a58946-e411-41b7-9839-c0c1c44648f4
3203	Pretty Hate Machine	0	\N	3	893	\N	5b5d00e8-3d90-3da7-9c17-c9e0e0376076
3204	Pretty Hate Machine	0	\N	3	893	\N	60a04a88-3956-49f5-9d0f-b2603be9f612
3205	The Downward Spiral	0	\N	3	893	\N	624e8731-83b3-3d23-b9da-50e559ab3554
3206	The Downward Spiral	0	\N	3	893	\N	6473ff12-496f-3fb8-a94a-65d565487885
3207	1991-07-12: Slaves: New Orleans, LA, USA	0	\N	3	893	\N	70dae3b7-8535-40e5-ab23-98987bef9717
3208	The Downward Spiral	0	\N	3	893	\N	86ee5682-f27b-3e11-ac8c-01872a7c45ce
3209	Pretty Hate Machine	0	\N	3	893	\N	8c0328e1-1172-3a02-bc32-833c810d32bb
3210	Pretty Hate Machine	0	\N	3	893	\N	8f156938-6462-3b3e-84ba-bfc7dd232c34
3211	Pretty Hate Machine	0	\N	3	893	\N	95e2508f-e830-4a79-a85c-ad5db1ae64cd
3212	The Downward Spiral	0	\N	3	893	\N	95f6f6a0-24f0-3f73-8546-d5a62eb2a666
3213	1990-03-10: Killer Instinct: Citi Club, Boston, MA, USA	0	\N	3	893	\N	a6d6d4cf-9064-41db-9295-f72154bbfa58
3214	The Downward Spiral	0	\N	3	893	\N	bbcaa2e5-56fe-43f5-8bd0-c5b64ca8b7c0
3215	The Downward Spiral	0	\N	3	893	\N	c2186639-2db4-4129-8927-39b86d5fb57a
3216	The Downward Spiral	0	\N	3	893	\N	caa753a6-93f9-39b4-a432-62fb31ee02a2
3217	The Downward Spiral	0	\N	3	893	\N	dceb6a01-3431-36af-b2e1-6462193bd67c
3218	The Downward Spiral	0	\N	3	893	\N	f0b2e95f-1cfa-3656-b192-6f3ee5cc2af3
3219	Unsilent Death	0	\N	3	894	\N	1f57f1bb-e0d3-435a-9297-1a28ef49e599
3220	Abandon All Life	0	\N	3	894	\N	c20668c5-0a48-4d4b-907a-ad76e5f1cb9d
3221	Abandon All Life	0	\N	3	894	\N	f2ed8752-3a26-4caf-a108-676f4f89c857
3222	This Will Fall on Dead Ears	0	\N	3	895	\N	77737db9-89db-4b11-a3df-bb63354b6355
3223	DOT Class "C"	0	\N	3	895	\N	cc3eb720-86da-4dc2-a8e6-ea77ad1ddd92
3224	Stresser	0	\N	3	895	\N	e3ea0a00-92ae-4666-9758-736730451f0a
3225	Corpus Christi	0	\N	3	897	\N	3a130765-eece-40ea-b6ce-f39ce20d488f
3226	Dangerous Dreams	0	\N	3	897	\N	6006942f-577f-44c7-bec1-3ae905cc188b
3227	Mood Swing	0	\N	3	897	\N	613c0169-dd4f-4bd3-9f1b-636d862437bf
3228	Mood Swing	0	\N	3	897	\N	6df99ed0-9227-4835-9066-ad830375c6bc
3229	Corpus Christi	0	\N	3	897	\N	c6804c13-ea28-4da0-881e-0cab51aff41c
3230	Dangerous Dreams	0	\N	3	897	\N	d8217064-ad80-4cc2-ba7b-242066540781
3231	Icons Above All Others	0	\N	3	899	\N	f14be701-96be-47bd-8bb3-28b82ae15974
3232	Flying the Corporate Jet	0	\N	3	902	\N	0292554c-477e-40af-b1ce-9b78c136791b
3233	The Madding Crowd	0	\N	3	902	\N	73bf440a-5c61-4d8c-89d6-cf6c1cfc842c
3234	Something Out Of Nothing	0	\N	3	902	\N	a34ab190-d48b-4991-a889-cecc2677c018
3235	So Happily Unsatisfied	0	\N	3	902	\N	b4ec84b3-0092-4444-b43d-913a7d13370f
3236	Three	0	\N	3	902	\N	d57806b3-51c2-4613-9e3f-c06c45efa18b
3237	Something to Listen To	0	\N	3	902	\N	dbf092ec-e221-4697-89a6-99e25ed30333
3238	Monday Songs	0	\N	3	902	\N	e6d0cce0-1e87-403d-98f5-cbbbcd5ef85e
3239	So Happily Unsatisfied	0	\N	3	902	\N	f9c9b3fa-ea1e-4f44-aee1-b62637e7c0d5
3240	Blastin' Away!	0	\N	3	903	\N	552909cc-5bd8-43b5-a5d6-1e96d0f3b676
3241	What Are You Afraid Of?	0	\N	3	903	\N	555cac16-af6c-4129-8c09-b9812e0bde0d
3242	Heavy Weighs the King	0	\N	3	905	\N	6b0c34b0-1a9b-47bc-8d98-e620b72c5c58
3243	Playing Dirty	0	\N	3	908	\N	435de41d-ef33-4dba-91b8-3fe793c857e8
3244	Swing Is Dead	0	\N	3	908	\N	5a7d8f02-2fb1-4612-90f8-2c357ee056e4
3245	Jump Swing From Hell: Live at the Hi-Ball Lounge	0	\N	3	908	\N	ab0be014-20f4-47a7-a05a-94aeeb63f00f
3246	El Bando En Fuego!	0	\N	3	908	\N	c3fb6ca0-8a63-464e-afe5-72dfef709a9a
3247	On a Mission	0	\N	3	909	\N	139aac23-46c9-4f88-99e2-713cfc3845da
3248	Sustain	0	\N	3	909	\N	1e3c8418-2ae6-423f-a4db-e2f2b11c74b1
3249	Libido	0	\N	3	909	\N	1f7f82a1-4a24-4524-9652-f0ba173978cf
3250	Songs in the Key of Bree	0	\N	3	909	\N	487e18b9-471c-43a4-a240-3b3efed9a7f7
3251	Twenty-Eight Teeth	0	\N	3	909	\N	4b006db3-2efc-4743-a74b-8658e10e65bd
3252	Barfly	0	\N	3	909	\N	7342e4b0-281f-4c01-b70e-98b94298f762
3253	Songs in the Key of Bree	0	\N	3	909	\N	749c3335-07ea-4a67-b813-8e16adb12e4d
3254	Hellos and Goodbyes	0	\N	3	909	\N	81052f64-c42e-4bc3-bad9-b3e5e41a6c12
3255	Barfly	0	\N	3	909	\N	e8a9af21-8038-4186-aaf1-6f445dacc97e
3256	Country Classics	0	\N	3	910	\N	6478e810-a733-4111-9c50-48976270bab0
3257	Kentucky Breakdown	0	\N	3	910	\N	70f92cfd-0c66-4268-8cf9-798937fa6684
3258	Live At The Vera	0	\N	3	910	\N	7357a71b-a744-4d74-a158-2943e6b0d975
3259	Sex, Drugs and Bill Monroe	0	\N	3	910	\N	7f931d0e-81b7-390a-9fe6-7717111d1684
3260	Hayseed Timebomb	0	\N	3	910	\N	9a6e9f44-0502-4e70-9768-4da41a1dd803
3261	Sex, Drugs and Bill Monroe	0	\N	3	910	\N	b116840f-45be-407b-8e6f-0624162a358c
3262	Mulebite Deluxe	0	\N	3	910	\N	e971cfd1-82d5-4dd6-b2de-b69c1bd615a1
3263	Smokin' Taters	0	\N	3	910	\N	f7561408-2339-4529-b3a8-8e17ca0d6ca0
3264	The Wrong Things	0	\N	3	913	\N	eaca4e7e-a863-4082-8bf0-4251c674dccf
3265	Recognize	0	\N	3	914	\N	a09d6fed-b949-4d4f-8337-330f33ea3670
3266	Thirty-Nine Thieves	0	\N	3	916	\N	bd78306f-3e88-43fa-b939-4e34da1fc183
3267	Undeniable: Evolution and the Science of Creation	0	\N	3	917	\N	51505590-7cde-469e-8746-903db44fe7d8
3268	Bill Me Later...	0	\N	3	918	\N	bce0476c-39fe-4428-862f-3cad8ccdfe70
3269	Downtown the World	0	\N	3	919	\N	15f6c480-955b-446b-a63b-63ec31766279
3270	PASSION 79	0	\N	3	920	\N	820143f2-7117-411b-a0de-b4940b784d50
3271	Explorations	0	\N	3	921	\N	03a16344-efb3-48f8-baa6-2ec53cb53782
3272	Portrait in Jazz	0	\N	3	921	\N	053b3454-7da0-40a6-841d-06600f254f79
3273	Sunday at the Village Vanguard	0	\N	3	921	\N	06bf4534-e253-4edb-9727-ec76cb94929a
3274	Explorations	0	\N	3	921	\N	10e163e3-43cf-4b9c-9be8-f412aa20dd8f
3275	Sunday at the Village Vanguard	0	\N	3	921	\N	150e61a6-dbf5-4aa3-ae50-0d77838a8183
3276	Bill Evans Trio at Shelly's Manne-Hole, Hollywood, California	0	\N	3	921	\N	1853abf6-6fe2-45c1-b382-eab395ee01c3
3277	Portrait in Jazz	0	\N	3	921	\N	2540a282-7cad-402d-9e92-ae50aa316671
3278	How My Heart Sings!	0	\N	3	921	\N	26d0a0e8-20a2-4aac-a41f-35965e617b0b
3279	Moon Beams	0	\N	3	921	\N	2844e56d-4836-4574-aed6-2eeabd2425c6
3280	Sunday at the Village Vanguard	0	\N	3	921	\N	28fb1ab6-94dc-4286-a033-7a62055686e5
3281	Trio '65	0	\N	3	921	\N	3c8339b2-9f95-457a-aebf-e0c1ef7a595b
3282	Portrait in Jazz	0	\N	3	921	\N	3d3b8deb-ca41-4f8d-a9de-8c01362d926a
3283	At the Village Vanguard	0	\N	3	921	\N	3f9ef891-5be8-4fcb-83f5-fea574304070
3284	The Jazz Festivals in Latin America	0	\N	3	921	\N	4503868f-2a84-431d-8287-7250a18a65ff
3285	At the Montreux Jazz Festival	0	\N	3	921	\N	47b2f09a-9ed6-45dc-8a8f-b7485fec227e
3286	Moon Beams	0	\N	3	921	\N	4b672e3d-2072-4620-823c-75e72f47b95f
3287	Sunday at the Village Vanguard	0	\N	3	921	\N	6f83176e-6104-4ce9-9289-7bfec3e8bf76
3288	Explorations	0	\N	3	921	\N	a20e7aed-56eb-4ea3-8d6f-5151038c93e6
3289	How My Heart Sings!	0	\N	3	921	\N	a9a3c09a-19cc-47f8-9923-5c4c2063677a
3290	Time Remembered	0	\N	3	921	\N	ac7aa8bf-d030-4339-8ff6-f813fb77fc09
3291	Since We Met	0	\N	3	921	\N	b3771bb9-ea02-3ad7-a2a7-839441e1a5bb
3292	Waltz for Debby	0	\N	3	921	\N	b866e6df-abc3-48cd-9ecd-62acf6da47de
3293	Explorations	0	\N	3	921	\N	cafd81dc-719f-3a82-9fa9-21c8f2cb786d
3294	Portrait in Jazz	0	\N	3	921	\N	d16e1309-13b2-3690-9623-a7b1aa94ed03
3295	Waltz for Debby	0	\N	3	921	\N	e791c133-bdda-434e-bc12-7ceb08de2701
3296	Harry Allen Plays Ellington Songs	0	\N	3	922	\N	12e7e039-ef36-4b36-b6d8-b9b4556ec8a5
3297	Somewhere	0	\N	3	922	\N	4e38957f-afe1-4914-841c-cff068ecf48c
3298	'S Wonderful	0	\N	3	922	\N	87802b61-16d0-4958-95c9-9c44c6ab123b
3299	Written in the Stars	0	\N	3	922	\N	8d0ca20b-cd27-4239-84b0-faa19fa3dbf4
3300	Live at the Village Vanguard	0	\N	3	922	\N	ad1f36be-ffd4-483a-b8c1-ff5bc35f8f98
3301	Souvenir	0	\N	3	922	\N	af2055f2-0b5b-41a3-9043-3dc8e3fe2437
3302	Distant Star	0	\N	3	922	\N	c1c5eb97-9e5d-4c0d-8b9d-79a38456b71d
3303	Somewhere: The Songs of Leonard Bernstein	0	\N	3	922	\N	f47bebcc-248f-41b2-a44a-8be82fd7e87b
3304	Lookout for Hope	0	\N	3	923	\N	0cefe3fa-a5fd-41ba-9b89-ae4b2a3f26e8
3305	Lookout for Hope	0	\N	3	923	\N	3504b0dc-a530-3d54-9430-b87b6400b636
3306	Where in the World	0	\N	3	923	\N	3a9c61fb-78ce-4027-bdfc-881f6d5bfa8b
3307	Lookout for Hope	0	\N	3	923	\N	4e0c180a-1f26-4102-91a8-e992de32f2b2
3308	The Untouchable Sound	0	\N	3	924	\N	04f90b0a-1408-4ec3-8e56-fe28998e7e46
3309	Solid and Raunchy & Movin'	0	\N	3	924	\N	0fe231a5-ec28-4644-803d-6f32845de1bd
3310	Hi Rollin’: The Story of Bill Black’s Combo (1960-65)	0	\N	3	924	\N	14aa2362-06f0-4385-96ab-f7ee86c6dd4f
3311	Best of the Hi Records Years	0	\N	3	924	\N	23a372d2-1c2b-4cb6-af51-2a65a0943747
3312	Bill Black's Beat Goes On	0	\N	3	924	\N	4169dda3-464b-400c-ba65-2e5ca7f9148b
3313	That Wonderful Feeling / Goes Big Band	0	\N	3	924	\N	5760aad4-82e1-4f9a-8dd4-7f5b1f59fb10
3314	Bill Black's Greatest Hits / Bill Black Combo Goes West	0	\N	3	924	\N	7aa85398-1b3e-424b-bbd6-50cb7102322f
3315	Turn on Your Love Light	0	\N	3	924	\N	8aa5e1b1-2be4-4076-a79b-095ad8b08466
3316	Bill Black's Record Hop / The Untouchable Sound of the Bill Black Combo	0	\N	3	924	\N	9d538778-7ae6-4514-87c0-a8179961b03f
3317	Plays All-Timers	0	\N	3	924	\N	b57fe0ca-90f5-4e3f-be9b-11a5946d40e9
3318	Greatest Hits & Bill Black's Combo Play Tunes by Chuck Berry	0	\N	3	924	\N	d06ca334-6d02-4748-892c-1e684e2e146e
3319	King of the Road	0	\N	3	924	\N	d4211234-9fd7-4b19-8943-1ff0732ce92a
3320	More Solid & Raunchy	0	\N	3	924	\N	ecbfd56d-f165-4fc6-8d78-3feec14aecda
3321	Black With Sugar	0	\N	3	924	\N	facba1d4-7193-46ee-8c88-6d1aa2250c95
3322	Let's Twist-Her & The Untouchable Sound of Bill Blacks Combo	0	\N	3	924	\N	fae7acd8-60f2-47f1-bc5e-933989b14d8e
3323	A Far Cry From Freedom	0	\N	3	926	\N	0cf53ad3-10f5-464f-a10c-ad72b51741de
3324	Christmas at the Jefferson 2012	0	\N	3	926	\N	223546a3-d426-4487-a6f5-296d849b94da
3325	Sirens	0	\N	3	926	\N	4675a5a6-651e-4e0b-8a1e-667fb119a45b
3326	Love and Logic	0	\N	3	926	\N	488c7d91-1d53-4186-af7b-84fc6f1373a4
3327	A Far Cry From Freedom	0	\N	3	926	\N	7053c303-e629-3ca1-8bf2-f505a4e2e282
3328	One Town Away	0	\N	3	926	\N	7db5e4b3-9e44-46a7-aed2-2131ff910ef8
3329	One Town Away	0	\N	3	926	\N	c02c11e7-8f31-4a33-896b-9146a5d652f7
3330	Truce	0	\N	3	931	\N	86f6b2a3-1e00-4e44-9379-aa004309adea
3331	Better News	0	\N	3	931	\N	aee5548a-9cfd-4185-90da-c0c7642335f4
3332	No Good Samaritan	0	\N	3	932	\N	cfa14dd1-5927-4552-98a2-01d05289a6e5
3333	Swing Fever	0	\N	3	935	\N	59c0822f-88f1-4222-b6d8-3a4822e4ae35
3334	Live at the Hollywood Palladium	0	\N	3	935	\N	81115441-342e-4b2e-b08d-4d9097f5b27c
3335	Greatest Hits	0	\N	3	936	\N	01033c87-5cd6-4b61-8d17-b7f3b89c2231
3336	Bill Haley & His Comets	0	\N	3	936	\N	07c7c1d8-9c6d-4a6b-9eb7-ed4bd09310b0
3337	Rock Around the Clock	0	\N	3	936	\N	0f4d4a98-f386-4c5b-b40b-a175084c57b7
3338	On Screen	0	\N	3	936	\N	31ae8780-559e-4b10-9d47-9a16e41a8dc6
3339	R-O-C-K!	0	\N	3	936	\N	3664bd1d-3739-497e-9b6f-6415b3bb97f5
3340	Rock 'n' Roll Stage Show	0	\N	3	936	\N	412069be-8ba7-4057-aa8d-51b752e005e3
3341	Rock 'n' Roll Show	0	\N	3	936	\N	4aaa6178-25b9-4897-8af4-ba77b4238577
3342	16 Original World Hits (Aust)	0	\N	3	936	\N	515cdaa0-67c1-4bf8-9a51-180e6859fa88
3343	The Best of Bill Haley	0	\N	3	936	\N	62d2b3d7-a453-447c-8f5f-fb1074680fad
3344	Members Edition	0	\N	3	936	\N	7805de03-e148-4d8b-964a-ad5a8f02fd32
3345	Rock With Bill Haley And The Comets	0	\N	3	936	\N	792cd480-9f6e-4f5f-b5ec-29ff75d6e3ac
3346	The Best Of	0	\N	3	936	\N	84219a2d-0d96-4496-b9bb-efaddcf1c2f2
3347	"R-O-C-K"	0	\N	3	936	\N	88f99b1a-afd9-44c3-a3f9-43f2462ea728
3348	From the Original Master Tapes	0	\N	3	936	\N	95929e5c-02ea-4aa5-9741-d7957f2fa1bb
3349	Rock With Bill Haley and the Comets	0	\N	3	936	\N	9f071b34-9d60-4a2c-bfa3-99cce88cfa7e
3350	Rock Around the Clock	0	\N	3	936	\N	a7bf6753-f956-4371-9850-8773ebd264a6
3351	Just Rock'n'Roll Music	0	\N	3	936	\N	b3140d0c-cd65-4bf8-89be-c31c12891b6a
3352	Bill Haley and his Comets	0	\N	3	936	\N	b641b003-f8b6-4c87-a18a-bec48d42586b
3353	Rock Around the Clock	0	\N	3	936	\N	bd32cc7d-92cc-449c-88e5-ea7409b74667
3354	The Greatest Hits 16	0	\N	3	936	\N	c6722e69-7470-4004-8a2b-36f4877a3cbb
3355	Rock 'n' Roll Around the Clock	0	\N	3	936	\N	cc8468de-5a5e-4d22-968f-391961fc1091
3356	Shake, Rattle & Roll	0	\N	3	936	\N	cf24e0ac-7415-46a1-a687-0b20e40fad9a
3357	20 Greatest Hits	0	\N	3	936	\N	def34171-9100-4dc9-9235-c74ab32cc18e
3358	Rock Around the Clock	0	\N	3	936	\N	e0476e14-629b-4a89-afdb-93aa09276a73
3359	Shake Rattle and Roll	0	\N	3	936	\N	f5aa4b8a-cf66-4b5f-8897-2f895c0c9337
3360	Best Of	0	\N	3	937	\N	7e9c2859-309c-4a4e-94ef-d9b09c2c55f1
3361	Vintage Rock	0	\N	3	937	\N	970f6c30-ec3a-47c4-9016-6411814884b6
3362	Live at the Opry	0	\N	3	938	\N	0fb5e969-e01a-4804-a507-343e3fcf270f
3363	Bluegrass Special	0	\N	3	938	\N	108a521f-32e7-4c18-b9ee-dbf3bdc6618d
3364	The Original Bluegrass Sound	0	\N	3	938	\N	115f5dd8-8120-4247-8d78-f9d75f5eac6d
3365	The Definitive Collection	0	\N	3	938	\N	14edfd2e-1281-4e3b-bac9-e50619df91eb
3366	A Voice From on High	0	\N	3	938	\N	29401376-1f8b-4d72-87a3-903ca811ff87
3367	In the Pines	0	\N	3	938	\N	455e445a-0235-4b36-9fc7-e41ad91590d6
3368	Live: The Hay Barn, Shepherd, Texas	0	\N	3	938	\N	5c0934cb-082a-4433-88ad-fd1bea7f8104
3369	Live at Mechanics Hall	0	\N	3	938	\N	6d43fe9c-4b8a-4802-b069-476aafbc9031
3370	Bluegrass Instrumentals	0	\N	3	938	\N	71b49e3b-0c69-491f-9c1a-92064482a277
3371	I Saw the Light	0	\N	3	938	\N	782ccfce-0e69-4539-8e1f-71246199e766
3372	16 All-Time Greatest Hits	0	\N	3	938	\N	848b06f6-e0e6-46f8-bcca-e92d12e17e71
3373	1982-02-06: Departmental Auditorium, Smithsonian Museum, Washington, DC, USA	0	\N	3	938	\N	86e7d5be-0104-42c4-9ae8-45a78b7ebde3
3374	I'll Meet You in Church Sunday Morning	0	\N	3	938	\N	893cab22-14ee-4964-93bd-30880bf7b2f0
3375	The Father of Bluegrass: The Early Years 1940-1947	0	\N	3	938	\N	a43a286e-41fb-47e2-b0e4-543a2834cc80
3376	Bluegrass Ramble	0	\N	3	938	\N	a9f7f900-b337-4132-96e3-46e3d02bfec9
3377	Blue Grass Time	0	\N	3	938	\N	ab389388-006e-4577-a327-9c7cece39b73
3378	Bluegrass '87	0	\N	3	938	\N	b4f39de5-a5aa-450c-a031-efc13110093f
3379	1961-07-04: Oak Leaf Park, Luray, VA, USA	0	\N	3	938	\N	c02671eb-c137-4f2b-9741-b6f7f3c74817
3380	Sings Country Songs	0	\N	3	938	\N	c045e894-8858-41ca-90fd-d6eb89a686a3
3381	Mr. Blue Grass	0	\N	3	938	\N	de883ef9-99d2-41f3-8292-2a74a4fb8f6f
3382	Bill Monroe's Greatest Hits	0	\N	3	938	\N	e1d754c9-1b67-440a-a22d-184983354868
3383	All the Classic Releases 1937-1949 (disc 1)	0	\N	3	938	\N	eb84d0fb-902d-463f-b5f9-dd8ff865bd87
3384	Mule Skinner Blues	0	\N	3	938	\N	eeed4024-bee8-4c5f-85ed-862f98fa1780
3385	Knee Deep in Bluegrass	0	\N	3	938	\N	f418dc02-1c39-48f4-90db-1427ab9fcf1f
3386	The High, Lonesome Sound of Bill Monroe and His Blue Grass Boys	0	\N	3	938	\N	ffaae43c-5117-493e-8cef-47d7b445814f
3387	Loveless	0	\N	3	942	\N	09a09037-1ebd-3d38-a128-38ab11e6b0fe
3388	Loveless	0	\N	3	942	\N	2fd724cb-63f0-4c50-a7bc-7a156d3d3f5a
3389	Things Left Behind	0	\N	3	942	\N	41dd2d81-b61d-44eb-991c-10df6e8b0cfb
3390	Ecstasy and Wine	0	\N	3	942	\N	4b4f860f-0dce-4e61-a329-95dcf33ada36
3391	Loveless	0	\N	3	942	\N	4c2c07b9-792e-430a-902b-c4d8784d0bce
3392	This Is Your Bloody Valentine	0	\N	3	942	\N	4db164a9-d50b-44ac-bbe5-4a536dc395f8
3393	Isn’t Anything	0	\N	3	942	\N	545ef480-9403-41e4-9ea5-03fb061f5cd6
3394	Loveless	0	\N	3	942	\N	61dc7ffb-1f5d-310a-ab73-f2f0f9ed5111
3395	Isn’t Anything	0	\N	3	942	\N	6298a421-e3a3-4b5b-8356-5173943733a2
3396	Isn't Anything	0	\N	3	942	\N	68dc06dc-242d-43ab-805d-aaa4310648a6
3397	Isn’t Anything	0	\N	3	942	\N	68e5b8f5-8fe5-4824-9608-a8047a2babfe
3398	Isn’t Anything	0	\N	3	942	\N	7b413a27-9f63-368a-b2e2-5bbd9938c4d6
3399	This Is Your Bloody Valentine	0	\N	3	942	\N	97372b04-0518-3993-8e50-b5886f124143
3400	Man You Love to Hate - Live	0	\N	3	942	\N	a41c35b6-369e-469d-950b-8a309615706f
3401	Ecstasy and Wine	0	\N	3	942	\N	a667b792-c63d-4a71-9022-0a2e9c270f8f
3402	Loveless	0	\N	3	942	\N	a78a16d6-2c2d-4873-9676-f07f313ba372
3403	Loveless	0	\N	3	942	\N	bb2591b0-6b3d-4eba-be5a-c624145b5b91
3404	Things Left Behind....	0	\N	3	942	\N	c6117239-97f0-4318-bad2-43fb528d14ec
3405	Isn't Anything	0	\N	3	942	\N	c65d3b19-5094-4c3b-835c-7605fc71a67b
3406	Loveless	0	\N	3	942	\N	cd32c6cf-f979-39e7-a4ec-157d3a560d06
3407	Isn’t Anything	0	\N	3	942	\N	cd3d6e91-8e20-4665-9072-6e41056bcbe5
3408	Isn’t Anything	0	\N	3	942	\N	e501bfa6-6d6c-404b-b23e-7ad78d9bdcbc
3409	Loveless	0	\N	3	942	\N	f3b9e9e6-687a-3b0a-a9f9-2e41d448fce2
3410	Loveless	0	\N	3	942	\N	f66e789e-7539-3d33-9fca-a1d21d741c29
3411	Isn’t Anything	0	\N	3	942	\N	fc4f807a-281a-3307-9730-c3a04357e499
3412	Ode to Death	0	\N	3	945	\N	28588c71-1b42-42b4-9d9f-77274a87d10d
3413	Death to Everyone	0	\N	3	945	\N	35af84ff-d5b6-4936-b4ec-908aa1c74e32
3414	Death to Everyone	0	\N	3	945	\N	54ebb5bb-6302-42f0-8a6c-257d8c196657
3415	War, Hate, and Misery	0	\N	3	945	\N	94216154-c41e-4967-94ca-63b8d0e81e43
3416	War, Hate, and Misery	0	\N	3	945	\N	ab1e0b2d-e5e9-369a-b594-354d99d8ec94
3417	War, Hate, and Misery	0	\N	3	945	\N	bbb98124-9a2e-35fb-92cb-053a41a8e573
3418	Ode to Death	0	\N	3	945	\N	dad75c82-252e-4568-ab6d-b72f3ec8581b
3419	War, Hate, and Misery	0	\N	3	945	\N	fdf2ec33-67cc-35f4-92ca-0322bbdb8e60
3420	Burn It All Down	0	\N	3	946	\N	91c1c113-f9e4-4d01-86a5-b3a6b1ef6bee
3421	Bloody Hammers	0	\N	3	947	\N	4cd3cbe5-871d-41b3-a2fe-c2249b389216
3422	Under Satan's Sun	0	\N	3	947	\N	89577dfb-5d14-4178-9dd6-6f7e2428070b
3423	Spiritual Relics	0	\N	3	947	\N	b3fbaf1a-4674-4640-8fb6-e3df908f4809
3424	The Poison	0	\N	3	948	\N	04cf4df1-2b10-4b9c-a130-64587d18aeb0
3425	The Poison	0	\N	3	948	\N	119aea3f-37cb-4a7e-b8b0-9f4b1f59b531
3426	Fever	0	\N	3	948	\N	21df3684-f52e-44f9-b948-5984ce48827f
3427	Scream Aim Fire	0	\N	3	948	\N	2eaa53ba-cf32-40e1-b4f4-61de392358d5
3428	The Poison	0	\N	3	948	\N	415fd5da-a58f-4230-be1f-005b10e685a0
3429	Scream Aim Fire	0	\N	3	948	\N	42ecf762-76a5-4397-8ead-b3baf439bb12
3430	Scream Aim Fire	0	\N	3	948	\N	52b18062-b993-3537-9e92-0cb178962fbc
3431	The Poison	0	\N	3	948	\N	656ce210-b154-32cf-ae2d-ae5fccf5741a
3432	The Poison	0	\N	3	948	\N	6584a03a-0aa8-4c1e-8cda-7cc098738cfc
3433	Scream Aim Fire	0	\N	3	948	\N	6f2178e9-31d1-33db-acbb-2a31c85e65d6
3434	Fever	0	\N	3	948	\N	738dad3c-d8b7-4e97-b60e-a200cea23d6f
3435	The Poison	0	\N	3	948	\N	785c333c-d7ce-451e-99d9-99a3a5889651
3436	Fever	0	\N	3	948	\N	794f9e14-48a7-3f5f-913e-dd443990afc6
3437	The Poison	0	\N	3	948	\N	822e8b12-86bf-40ee-a5a7-1a5735fab0f0
3438	The Poison	0	\N	3	948	\N	85fb1fb5-b4b4-4c2f-bc15-8429eda2b7c4
3439	Scream Aim Fire	0	\N	3	948	\N	cb58fc68-0a27-493c-ba54-2d3f0f0c3664
3440	Scream Aim Fire	0	\N	3	948	\N	d5ffda16-7059-3e0c-91a9-ba39399d004b
3441	Scream Aim Fire	0	\N	3	948	\N	dab1ceec-5f07-441d-bac4-3797a4d661ae
3442	The Poison	0	\N	3	948	\N	e211df9c-0cc1-4aa5-9c87-17fd353e34c3
3443	The Poison	0	\N	3	948	\N	e5e316b0-7b0a-4516-b34a-579b54d8a0fd
3444	The Poison - Live at Brixton	0	\N	3	948	\N	eb79c2b7-f445-4a98-a0e5-16e2cdc89b04
3445	Scream Aim Fire	0	\N	3	948	\N	f24cc2d2-8774-4de4-b4eb-655915f1c020
3446	Fever	0	\N	3	948	\N	f310effd-4829-4e7b-b130-dddf1e8b77cd
3447	Scream Aim Fire	0	\N	3	948	\N	f767214e-9350-4b91-81df-580424b4777e
3448	Fever	0	\N	3	948	\N	f8e3d85d-3d78-453f-9836-5cd4a511ca6d
3449	The Loveless Poison	0	\N	3	949	\N	dd56e078-7114-4b78-83dd-a44cd443413a
3450	Who to Trust, Who to Kill, Who to Love	0	\N	3	951	\N	20911873-de55-43bb-b7ea-c01c14b2a20a
3451	Yours Until the Bitter End	0	\N	3	951	\N	2d21695c-f75f-42fe-9530-606e8c73ef97
3452	Got It Where It Counts!	0	\N	3	951	\N	4e0406dc-530e-485b-a775-f926b0e7c03b
3453	If Footmen Tire You…	0	\N	3	951	\N	7623580c-58b4-47d7-b5b9-37873a9ea115
3454	Fire at Will	0	\N	3	951	\N	ab4e3074-bbe9-42fd-ac69-31d9b0f406f6
3455	The Bloody Angle	0	\N	3	955	\N	79c6b770-eb2a-44ee-bed7-1ad59d5589e4
3456	Shock Value	0	\N	3	957	\N	f0a1edbf-0cdf-453f-ae27-d6579190f39b
3457	6th Grade Field Trip	0	\N	3	958	\N	1b105e6b-6eaf-4892-af03-4a32616d4396
3458	Dismissed	0	\N	3	959	\N	4f3ecef6-048b-4392-9a60-c5647bef8575
3459	Solid State 14	0	\N	3	960	\N	27b24a49-1f80-4f69-b651-fee17e10912f
3460	SKAteboard Music	0	\N	3	960	\N	80767082-682c-429d-8b57-9f3a77772198
3461	Station One	0	\N	3	960	\N	f5263ea8-0bc5-4b9f-998d-d44530ddfbde
3462	Endless Bummer	0	\N	3	961	\N	ab84d0c0-df70-4893-bbc7-5af8947df71c
3463	Love at Absolute Zero	0	\N	3	962	\N	43370601-bb72-4942-9079-7d439a25c2c9
3464	The Happiest Days of Our Lives	0	\N	3	962	\N	5f153838-1aba-489d-ba36-35d2712dcdba
3465	Italian	0	\N	3	963	\N	03e565cb-f090-4847-97ea-4d6ee8378e73
3466	Moody Dipper	0	\N	3	963	\N	24a62540-82a4-4501-a123-0af1d42787a5
3467	Sunrise	0	\N	3	963	\N	3079f5e4-9306-4fff-84ad-403f2546cebf
3468	A Drink for All My Friends	0	\N	3	963	\N	3a21b850-547f-4e15-9ff4-0f1f8b48afd2
3469	Bad Vibrations	0	\N	3	963	\N	92b52fa0-c96a-4f9b-aedb-a0aa23e67c43
3470	Preachers	0	\N	3	966	\N	7f7fb118-283c-4609-8354-3374718566bf
3471	Gone for Good	0	\N	3	966	\N	84e5e2d0-1620-4442-a19b-d30f962b0b43
3472	Going Blank Again	0	\N	3	967	\N	098bd485-25d5-4718-8034-2f74ba8dac84
3473	OX4_ The Best of Ride	0	\N	3	967	\N	1284de91-0bae-4357-b373-3b1543dbb9f4
3474	Smile	0	\N	3	967	\N	13f49e3f-e741-3f73-a6d0-0578eae0d9b0
3475	Carnival of Light	0	\N	3	967	\N	1690c02d-9071-45b7-9259-8e17eb6034df
3476	Nowhere	0	\N	3	967	\N	187e48ea-abbe-429b-a7ba-32fb8dc3f44c
3477	Live_ Reading Festival 1992	0	\N	3	967	\N	29e59ecc-e20a-424c-a8ed-fd67862ba15a
3478	Overdrive	0	\N	3	967	\N	33c45a5f-062b-406b-8c4f-cead3a616057
3479	Going Blank Again	0	\N	3	967	\N	4cbb5910-7602-4d3f-ab33-69649d89071a
3480	OX4_ The Best of Ride	0	\N	3	967	\N	5039a19a-e8f7-4cb1-9841-db181e930518
3481	Tarantula	0	\N	3	967	\N	62004234-b505-4af7-9ee4-59c2dbdb5b05
3482	Tarantula	0	\N	3	967	\N	6d9912ce-4e74-3f16-b500-052be00be629
3483	Carnival of Light	0	\N	3	967	\N	707c07b1-5628-4234-a994-8b3a4131f6e9
3484	Nowhere	0	\N	3	967	\N	71d9ac00-bfc4-3d0e-a0c2-bcd4fdafbd2e
3485	Nowhere	0	\N	3	967	\N	75ca11fb-c9e2-45fd-b73a-c0252d383c79
3486	Tarantula	0	\N	3	967	\N	814d7d55-e0bc-4a8c-a273-23982e6378b9
3487	Town And Country Club, London, March 8, 1991	0	\N	3	967	\N	9f18557d-d8b4-44d4-b70b-6e90896e56a3
3488	Nowhere	0	\N	3	967	\N	a1cf71b2-4953-34bc-92bc-a3edb203bd3e
3489	Smile	0	\N	3	967	\N	aaf40728-8cba-3052-b559-ad367c5b66e5
3490	Nowhere	0	\N	3	967	\N	b20eaf7a-ca77-4dfe-9f28-07f115c8ae11
3491	Cosmic Carnival	0	\N	3	967	\N	c3d83e8e-1946-42b2-8e15-5f1f9420be80
3492	Smile	0	\N	3	967	\N	c79d2a42-739f-430a-a4c0-05be51f95a9a
3493	Going Blank Again	0	\N	3	967	\N	d5a1ccd0-a820-3f51-bdd6-df30fe938933
3494	Firing Blanks_ Unreleased Ride Recordings 1988-95	0	\N	3	967	\N	d8a17d9e-276c-4d9e-bb9f-e25a7ead00f0
3495	Nowhere	0	\N	3	967	\N	ded0eb52-1573-493c-a551-9a5193e6d584
3496	Nowhere	0	\N	3	967	\N	ebc2ee3f-3407-4f7e-8780-80deaf6cac1e
3497	Amarillo Sky	0	\N	3	968	\N	80eed3bb-1ba9-40e5-89eb-97b48c9fb019
3498	Hurry Sundown	0	\N	3	968	\N	e3b65922-de76-46f3-9b3d-e4a7760ffa1b
3499	Burnin' Up the Road	0	\N	3	968	\N	e49e459a-4630-4f7d-9b34-7d8aa98c21aa
3500	Sacred Ground	0	\N	3	968	\N	feb4fc14-c5e1-4a24-9a17-3a4862a87a7f
3501	T-Ride	0	\N	3	973	\N	2b9d8921-a44e-445a-9d5e-ca05e06a203d
3502	Forget	0	\N	3	974	\N	6448db1f-45b9-43a8-be20-9d3e6561b725
3503	The Ride	0	\N	3	975	\N	03b39af6-c474-4698-a178-2f4df6dfdfb8
3504	Oh the Flow	0	\N	3	976	\N	0ff066b7-d7ce-4318-a35b-73823240f181
3505	Strange Trial	0	\N	3	976	\N	2d7bb2a4-df6a-4b99-bcfb-9a631be52c2e
3506	Skeleton Rites	0	\N	3	976	\N	2ec8960e-7018-471a-955d-c7eff6035404
3507	Stonebridge	0	\N	3	976	\N	5a106ce6-2e48-4410-9a52-dea476841296
3508	House on the Hill	0	\N	3	976	\N	74c69233-4b60-4acc-8aa3-db30393777cf
3509	Coastland Ride	0	\N	3	978	\N	555f631a-0970-4e11-92ef-d069d41c9ad3
3510	Rock 'n' Roll Show	0	\N	3	979	\N	c4719253-a40c-4c32-a599-dbb8c867b224
3511	On the Edge	0	\N	3	986	\N	912ce77b-a4fd-484e-8301-f6184651b917
3512	Elvis Christ	0	\N	3	990	\N	76daba08-ca45-4d38-bd31-04b8855c1dc2
3513	Screaming Down the Gravity Well	0	\N	3	990	\N	9c880b47-c420-4867-8bb8-642ec3ce1b83
3514	Screaming Down the Gravity Well	0	\N	3	990	\N	cce6f590-dd80-49b4-a797-a58b96f7a504
3515	Bathroom Walls... Lipstick Secrets	0	\N	3	991	\N	f7981a79-51b8-472d-a47e-303f8bbe7c5e
3516	Regress	0	\N	3	992	\N	6d481a17-5dbe-4aa0-9a7c-dbc55e508528
3517	Souvlaki	0	\N	3	993	\N	07d02411-6722-4071-8130-14fb8512288a
3518	Just for a Day	0	\N	3	993	\N	0a470a5b-7080-4b74-b947-045e192a8c41
3519	Souvlaki	0	\N	3	993	\N	12694708-e437-4874-a5d4-c1ca0ec46313
3520	Pygmalion	0	\N	3	993	\N	2cb2be50-c98c-38e4-ba72-5440858f19ed
3521	Just for a Day	0	\N	3	993	\N	2e9d25b4-de25-3558-b6eb-73c530162d5b
3522	Blue Day	0	\N	3	993	\N	303d108a-8b3c-4dbe-97bf-e070b5d36d01
3523	Souvlaki	0	\N	3	993	\N	4939859c-ce2a-484b-872b-6d7ab9ff7260
3524	Hide Yer Eyes	0	\N	3	993	\N	4c009b8a-3d46-4eb3-9414-c7cbd9a00e3b
3525	Souvlaki	0	\N	3	993	\N	4c8ba287-53d7-3cc8-84eb-fc730fbfb3ac
3526	Souvlaki	0	\N	3	993	\N	7a663ffe-0279-4f7e-a047-b9b3aaf317d3
3527	Pygmalion	0	\N	3	993	\N	85e67a14-de60-45f7-a58a-171f16b09e5e
3528	Souvlaki	0	\N	3	993	\N	89042d40-fac2-4030-8bb4-e057617fee37
3529	Pygmalion	0	\N	3	993	\N	97d85ef1-bc99-4c2b-9a76-fb6a0975be70
3530	I'm the Elephant, U Are the Mouse	0	\N	3	993	\N	99cda52d-4226-4f35-9c8f-d3e1019cac24
3531	Catch the Breeze	0	\N	3	993	\N	a3aa8a48-7b5b-475c-a713-442ea6c76871
3532	Just for a Day	0	\N	3	993	\N	a7db72e2-9f26-3bbb-98b2-bce8a27a7f93
3533	Souvlaki	0	\N	3	993	\N	b559b838-f8b6-4f47-abed-7d4fbe050826
3534	Just for a Day	0	\N	3	993	\N	ba1e3d80-3cda-4f5e-9838-4377cf841391
3535	Live… (Sentrum) Oslo, Norway 18/10/93	0	\N	3	993	\N	bfbe7af0-b432-49ec-b7fb-9d9c09ca0fdf
3536	Just for a Day	0	\N	3	993	\N	ca7dc2c0-bb6e-47d1-843d-6e7420d11a75
3537	Pygmalion	0	\N	3	993	\N	ca987625-f764-412e-a673-41d4b7bcaa04
3538	I'm the Elephant, U Are the Mouse	0	\N	3	993	\N	cc3e604d-f898-40b7-b66f-c475b0988d62
3539	Original Album Classics	0	\N	3	993	\N	cd8c217b-d256-48cf-9f0b-ce1ac3f56d4d
3540	I Saw the Sun	0	\N	3	993	\N	e4c09d4f-7990-471c-a260-a2e4588c0b2c
3541	The Shining Breeze: The Slowdive Anthology	0	\N	3	993	\N	e9233187-bfd4-4ac4-b45c-a9504f476f67
3542	Collaborating # 2	0	\N	3	994	\N	40716664-045c-4b6a-b6b9-754c31540366
3543	Oasis Collaborating	0	\N	3	994	\N	94cf874b-1ba9-4e21-af56-8ba7417cf2ca
3544	Collaborating	0	\N	3	994	\N	d178dd19-6f9d-41bf-b465-338cb887f972
3545	Radio Supernova	0	\N	3	995	\N	0b487466-e355-41a1-bd58-55c331ce3066
3546	(What’s the Story) Morning Glory?	0	\N	3	995	\N	273780db-4378-43ad-9a2a-e3e1aa8b78ed
3547	(What’s the Story) Morning Glory?	0	\N	3	995	\N	3c084623-09ae-4fe1-93b9-eec2a423aca6
3548	(What’s the Story) Morning Glory?	0	\N	3	995	\N	3cac3754-701c-3390-9064-2241f9c22bb6
3549	Definitely Maybe	0	\N	3	995	\N	572ac148-c10c-47a3-82af-0395e32ddf87
3550	Definitely Maybe	0	\N	3	995	\N	5a03925e-0271-3a84-a1b1-b7121bbf9fb1
3551	More Mancunians	0	\N	3	995	\N	5af42a41-b2a5-4519-9653-a6f753fff326
3552	Definitely Maybe	0	\N	3	995	\N	698d1229-0724-36c1-9ef0-0705ac4d98c4
3553	1995-11-07: "Paris Supernova" live at Le Zenith, Paris, France	0	\N	3	995	\N	6c8df94e-02f2-4d8f-8459-a00ff35ff114
3554	Live at the Metro	0	\N	3	995	\N	714837c3-42a0-4b2a-84e4-223f81a15e8a
3555	(What’s the Story) Morning Glory?	0	\N	3	995	\N	929281e2-8a13-4c02-9f9e-8d3a1fc046ab
3556	Definitely Maybe	0	\N	3	995	\N	9822581d-98bf-3f97-a94c-4b1350d090aa
3557	Live by the Sea	0	\N	3	995	\N	9aec09d5-488c-4a1f-94b8-58101b7a07d2
3558	Definitely Maybe	0	\N	3	995	\N	adca79f8-3876-4cd0-a7b9-1e4a85ff1cb9
3559	(What’s the Story) Morning Glory?	0	\N	3	995	\N	d3590bef-9444-41fc-b7b0-a5d39981f0c5
3560	(What’s the Story) Morning Glory?	0	\N	3	995	\N	d7706ad2-e6f8-38fc-a797-1cf7eea260f9
3561	Definitely Maybe	0	\N	3	995	\N	d7749b04-2bff-409f-a647-cd5c2c75432b
3562	(What’s the Story) Morning Glory?	0	\N	3	995	\N	e0b314a3-fbc5-3628-8e48-803a4f90e0ba
3563	Live at Earls Court 1995	0	\N	3	995	\N	e8abe930-fd00-4e77-b5f4-11ed8a86efe3
3564	(What’s the Story) Morning Glory?	0	\N	3	995	\N	ed286309-6e64-48e3-835b-61aaf86cdb86
3565	Definitely Maybe	0	\N	3	995	\N	ef927fa4-2f6b-4431-8867-0573b0e9c234
3566	(What’s the Story) Morning Glory?	0	\N	3	995	\N	f29584cc-8f94-4035-8a63-d4369f201e2a
3567	Definitely Maybe	0	\N	3	995	\N	f589d114-b9ee-441b-95b8-f4acb4b9411e
3568	Whatever Demos	0	\N	3	995	\N	f84372e1-3511-4824-a7b3-eb36690e581d
3569	Definitely Maybe	0	\N	3	995	\N	feeedf8d-7bff-43eb-b8d5-c3ac75612f53
3570	Oasis	0	\N	3	996	\N	09879fb7-9863-4289-9ff8-3e724758dc58
3571	Father More Ghana	0	\N	3	996	\N	e14acd72-d3c3-4170-8cea-66601d3e9bcd
3572	Bring It On	0	\N	3	999	\N	0e90b420-384c-424e-9e8f-9e848b4df5e1
3573	DUB PLATE MASTER	0	\N	3	1007	\N	7b1f3d58-43bf-4ac7-8637-4fb149e1182f
3574	R.E.O.	0	\N	3	1008	\N	014f0775-9dd6-4c37-b361-79b9e7c7d4b5
3575	A Decade of Rock and Roll: 1970 to 1980	0	\N	3	1008	\N	0c797ae7-17b2-3d18-8c1f-3c915d5211e9
3576	Live: You Get What You Play For	0	\N	3	1008	\N	1458830e-ccc1-4da8-9150-e966471c8ead
3577	Building the Bridge	0	\N	3	1008	\N	24fc8f4e-2c02-3f07-9465-be67f3636ec9
3578	A Decade of Rock and Roll: 1970 to 1980	0	\N	3	1008	\N	386a86e7-ecf8-4203-b0fd-df10082120d9
3579	Ridin' the Storm Out	0	\N	3	1008	\N	413f7814-bed0-4e35-a876-ae88fba08590
3580	Wheels Are Turnin'	0	\N	3	1008	\N	4ef6c86b-5a19-4eca-a1c9-1d507a89cc4f
3581	Hi Infidelity	0	\N	3	1008	\N	591ce56c-587c-37b3-b174-f7fc53631da8
3582	Hi Infidelity	0	\N	3	1008	\N	6c4e96c4-1b03-36ed-9b2f-b5d2c78dc54e
3583	Hi Infidelity	0	\N	3	1008	\N	71827c96-074f-3497-b7f5-c4bb285110ee
3584	Nine Lives	0	\N	3	1008	\N	73c6d8b2-c207-4170-96b4-85617336c96e
3585	Life as We Know It	0	\N	3	1008	\N	7cff6170-d2f1-48b3-a558-d2256f97f113
3586	The Second Decade of Rock and Roll 1981 to 1991	0	\N	3	1008	\N	7ebe4af1-c05d-4bb0-a9dc-d1130182ea9d
3587	This Time We Mean It	0	\N	3	1008	\N	83743c68-44b0-42a7-ac32-9471ba32b96c
3588	Good Trouble	0	\N	3	1008	\N	86020569-0831-4782-88cf-d866e3075943
3589	A Decade of Rock and Roll 1970 to 1980	0	\N	3	1008	\N	971facde-576b-42a5-b65c-d2da8520e09d
3590	You Can Tune a Piano, But You Can't Tuna Fish	0	\N	3	1008	\N	97cafda1-24e7-4916-b6b6-e29593a0d788
3591	A Decade of Rock and Roll: 1970 to 1980	0	\N	3	1008	\N	a5a8319a-2056-3254-9ace-f344629629b3
3592	The Earth, a Small Man, His Dog and a Chicken	0	\N	3	1008	\N	c9de58ee-67c4-4d1d-83fd-82a78c0c1e97
3593	Best Foot Forward	0	\N	3	1008	\N	d59c57cf-e7c8-4b58-ac78-cf2d33af06a2
3594	Live: You Get What You Play For	0	\N	3	1008	\N	e1f59a76-e819-4c5a-9bb1-87043fa96d49
3595	Lost in a Dream	0	\N	3	1008	\N	ea3ea12f-4e32-4fb4-b195-1033cd7b40ae
3596	The Hits	0	\N	3	1008	\N	f38ef4c0-5cfc-40a6-aeec-725ce46f8ca5
3597	T.W.O.	0	\N	3	1008	\N	f44696f7-a26e-43e7-a6a1-bdf83d6539c2
3598	R.E.O. Speedwagon	0	\N	3	1008	\N	fca1e237-c4cb-418c-be57-41ed51923dd3
3599	Despertares	0	\N	3	1011	\N	31cc7308-db3c-4b62-ad03-678bd11a2b30
3600	Serpientes	0	\N	3	1021	\N	2327b150-f863-4d60-b2ae-f545dd27c8a5
3601	Further Out	0	\N	3	1030	\N	0c527d19-c031-45ed-960a-b07665f48bf5
3602	Define the Great Line	0	\N	3	1032	\N	0987d264-c611-4302-a738-32d49abe219d
3603	Ø (Disambiguation)	0	\N	3	1032	\N	0a2a800e-57ca-492a-936e-6504a346939e
3604	The Changing of Times	0	\N	3	1032	\N	0ff29220-5ba3-46dd-89f2-9510d29c916a
3605	They’re Only Chasing Safety	0	\N	3	1032	\N	12655151-895d-44e2-b0ee-c3a5e27a7d23
3606	Cries of the Past	0	\N	3	1032	\N	182df017-12a5-4836-9780-0f1f4b971f87
3607	Lost in the Sound of Separation	0	\N	3	1032	\N	257fc109-3150-431b-8670-39bec0b62e08
3608	777	0	\N	3	1032	\N	29439e2f-87db-4b47-96f4-7e59108029c8
3609	They’re Only Chasing Safety	0	\N	3	1032	\N	32ffa93e-771b-38a2-95c6-14025ef1f7f1
3610	Anthology: 1999–2013	0	\N	3	1032	\N	3b6d3138-93d3-4ed8-9706-3796b5ff1152
3611	They’re Only Chasing Safety	0	\N	3	1032	\N	46199035-c776-4abd-bcbb-1e95af2dfe7f
3612	They’re Only Chasing Safety	0	\N	3	1032	\N	68ffc23e-03cd-4ec5-a04d-f6bdefb82904
3613	Live at Koko (disc 1)	0	\N	3	1032	\N	7415a1d3-58ca-4e89-b08d-52bed4d73bb3
3614	Ø (Disambiguation)	0	\N	3	1032	\N	bea561b8-1c64-4a71-9264-e1302a85dc2c
3615	Play Your Old Stuff	0	\N	3	1032	\N	cef21e2a-2b1a-4eff-a4fa-36ae28fb5a0e
3616	Survive, Kaleidoscope	0	\N	3	1032	\N	d69c03a4-e613-4ae8-b029-330bccd7ad7e
3617	Act of Depression	0	\N	3	1032	\N	ddd30845-bdb7-4b6b-9b59-3b519265ba00
3618	Ø (Disambiguation)	0	\N	3	1032	\N	e2f6c107-d3a0-3b55-976f-12f4eaf13e6d
3619	Define the Great Line	0	\N	3	1032	\N	ec86fdb1-7a1d-46a1-8211-2cc5e1ea6930
3620	Daisy	0	\N	3	1033	\N	21f73a7c-16e3-46ad-bc51-98f2592a0c2a
3621	Daisy	0	\N	3	1033	\N	23308140-6cd4-4d88-a42c-de572cea940c
3622	Fight Off Your Demons	0	\N	3	1033	\N	348a3adf-b5fa-4a5c-baf8-26a0350b3f8c
3623	The Devil and God Are Raging Inside Me	0	\N	3	1033	\N	4591a2e7-abad-4c8c-a717-8b61cb461cc2
3624	Deja Entendu	0	\N	3	1033	\N	499e5f67-a07b-4536-ad3b-82d4edefa993
3625	The Devil and God Are Raging Inside Me	0	\N	3	1033	\N	54056421-b9a6-3258-85d0-57af5e41ff5c
3626	Daisy	0	\N	3	1033	\N	581aa1ff-dccb-4955-af57-f65678228750
3627	The Devil and God Are Raging Inside Me	0	\N	3	1033	\N	788b627c-1d68-49cf-884f-33eac3c15cc5
3628	Deja Entendu	0	\N	3	1033	\N	825f384f-efcd-475f-b69c-8b618feb88f4
3629	Your Favorite Weapon	0	\N	3	1033	\N	9b1068f2-3e58-4fe0-a198-020a5dcbe91e
3630	The Devil and God Are Raging Inside Me	0	\N	3	1033	\N	a74dd146-0faa-49b2-a37e-8c2b51f64b3f
3631	Your Favorite Weapon	0	\N	3	1033	\N	a94c4569-d319-4887-b314-ecf7f415e184
3632	Daisy	0	\N	3	1033	\N	aa69a080-f4bd-44cd-bc3d-513880be9ea5
3633	Daisy	0	\N	3	1033	\N	acad9642-f8f9-4d65-b71c-9f8680da9990
3634	Deja Entendu	0	\N	3	1033	\N	ae0f18ad-bf82-4bc6-afde-1044fcb0f339
3635	Leaked Demos 2006	0	\N	3	1033	\N	b4f33477-d3ea-4557-bf5e-f2bf4daf030d
3636	Your Favorite Weapon	0	\N	3	1033	\N	bd98ccf6-f2fe-4eef-8104-4acf5b315414
3637	80 Minutes of B-Sides	0	\N	3	1033	\N	c85cbfc9-f64f-4aa8-a2e4-28f1c22c86b0
3638	The Devil and God Are Raging Inside Me	0	\N	3	1033	\N	c9294302-9589-4859-a0ed-d82c65b017db
3639	Deja Entendu	0	\N	3	1033	\N	cf4130bc-c4f3-4ad3-adc6-c61faab2303e
3640	Deja Entendu	0	\N	3	1033	\N	d3eb1ddb-04ba-3509-9415-15f8b9127396
3641	Daisy	0	\N	3	1033	\N	dd714b79-de92-45f5-b01a-33dc1d92795e
3642	The Devil and God Are Raging Inside Me	0	\N	3	1033	\N	f2316c52-0483-3bd4-bbb8-c63c00254173
3643	United State	0	\N	3	1034	\N	0da751e4-ddcb-4a01-a60a-af10a5e47fc0
3644	Recipe for Disaster	0	\N	3	1034	\N	1f7936b9-1749-411b-a199-91f031cd84fb
3645	Tequila	0	\N	3	1034	\N	226a4a84-10ea-4e45-ba1e-c043577ceaa5
3646	Brand New Sin	0	\N	3	1034	\N	27dadd84-2a82-4170-b27a-8b260f09caea
3647	Recipe for Disaster	0	\N	3	1034	\N	6eaf8e61-ebb1-4acb-8129-9ac4c94bc8b7
3648	Distilled	0	\N	3	1034	\N	7f01db47-cc38-4f1c-a2ff-b2887382a9c4
3649	78'	0	\N	3	1035	\N	9043f0f2-9373-48db-8f5d-c176226109a8
3650	The Brand New Heavies	0	\N	3	1038	\N	04483b98-c9cf-4b9c-8dfc-d502b3dfb01a
3651	Original Flava	0	\N	3	1038	\N	0c246b4f-729d-42ab-a6a0-bfc71d25872d
3652	The Brand New Heavies	0	\N	3	1038	\N	15297d40-5355-4570-b55d-7fb37f0cc4f8
3653	The Acid Jazz Years	0	\N	3	1038	\N	2ad4aa14-f416-4e45-80aa-458fd976ee30
3654	Brother Sister	0	\N	3	1038	\N	2d62176f-1982-4ab3-8ba9-5203e88c20a5
3655	Brother Sister	0	\N	3	1038	\N	3949c5d8-9cb8-4bdc-a144-5f07191b4b5a
3656	The Very Best of the Brand New Heavies	0	\N	3	1038	\N	39fe2a4e-901a-447e-9dcc-57bc1585ae42
3657	The Brand New Heavies	0	\N	3	1038	\N	3a0d92bf-223f-4fc3-8c47-02287006ec0f
3658	Brother Sister	0	\N	3	1038	\N	580b18d4-eac2-45e4-ae03-2e0db4fefd97
3659	Heavy Rhyme Experience, Volume 1	0	\N	3	1038	\N	5aec7d3c-33ff-4ee8-bc3e-f8022619a45e
3660	In tha Beginning	0	\N	3	1038	\N	7bb56a53-e567-4169-a88f-761b37d29e33
3661	Shelter	0	\N	3	1038	\N	821d6175-d6ae-4250-bfbc-bf61f5cb44d3
3662	The Brand New Heavies	0	\N	3	1038	\N	83c1f76a-d267-4175-914b-b3eb7f5a030a
3663	Shelter	0	\N	3	1038	\N	89ba2d54-7c40-4790-8443-8f1d0fc25828
3664	Excursions, Remixes & Rare Grooves	0	\N	3	1038	\N	8d5a24e2-4844-44f9-972d-6a1680ee121c
3665	Trunk Funk Classics 1991-2000	0	\N	3	1038	\N	a5d17fd5-332e-4c3c-ac3a-5c7c637a4579
3666	Shelter	0	\N	3	1038	\N	a86eaa4f-3c5f-4619-abf9-fa1a75e3c271
3667	Put the Funk Back in It	0	\N	3	1038	\N	b30a9fbe-5954-4fae-9f01-3bfa2609a290
3668	Heavy Rhyme Experience, Volume 1	0	\N	3	1038	\N	b65f2e22-fbe5-33ba-bbbb-2b38c22d56f2
3669	Dream Come True: The Best of the Acid Jazz Years	0	\N	3	1038	\N	c16f4c35-9d4e-48ae-8e77-634bf3c339c8
3670	Shelter	0	\N	3	1038	\N	c82941b3-326a-4121-82e4-c6f09bfaeae3
3671	Trunk Funk: The Best of the Brand New Heavies	0	\N	3	1038	\N	df6946ed-fbc5-4315-b8fd-39ce18cc9d58
3672	Shelter	0	\N	3	1038	\N	eb49cd4c-092c-427a-af98-03e0fcc08eaf
3673	The Best of the Acid Jazz Years	0	\N	3	1038	\N	f0c00c22-bf4f-408c-baa2-4f76cac09e6d
3674	Brother Sister	0	\N	3	1038	\N	faa2be2a-418e-40cb-b3fc-861ddeb93916
3675	Tragic Show	0	\N	3	1039	\N	59dbef92-7f0d-420b-83fb-6bca466de923
3676	Looking Back Again	0	\N	3	1040	\N	7ec4737c-08f9-487f-ac70-adde19836d27
3677	Melody	0	\N	3	1044	\N	03774624-de4e-4105-88d7-6a0513a767bd
3678	COLORS	0	\N	3	1044	\N	86353bf0-4f8d-433a-aae1-4177032b0249
3679	The Neverending Tentacle of Osculus the Monster From Below	0	\N	3	1048	\N	f9f29dcf-2bbc-4bfa-8cea-0c328936d840
3680	Nine	0	\N	3	1050	\N	0d02872d-e1d2-4a1a-9419-42e11c39cac8
3681	Stop the Music	0	\N	3	1050	\N	9ce977e3-6891-4899-ad9f-b15fff98eb86
3682	All For Love	0	\N	3	1051	\N	0555fad6-6d3c-412a-930c-3dcf2ad07ac6
3683	Candy Girl	0	\N	3	1051	\N	0c238e95-a2de-3ca0-88d7-e45613b128f3
3684	Heart Break	0	\N	3	1051	\N	1d37901b-884c-4d9f-bdca-b56a37b8a411
3685	Lost In Love: The Best Of Slow Jams	0	\N	3	1051	\N	215c5ce9-3c72-4deb-b134-f5d1839c607a
3686	Hits	0	\N	3	1051	\N	28177dc8-42c7-4687-b7be-4c4c385d0b25
3687	Greatest Hits	0	\N	3	1051	\N	2b21013b-f0b0-4952-95aa-799aa57d74c2
3688	Candy Girl	0	\N	3	1051	\N	2b6228fc-8aa6-4541-8d76-9bc46625f555
3689	Heart Break	0	\N	3	1051	\N	4d5dc907-cd82-4c3b-ade0-75e99fa279bc
3690	Under the Blue Moon	0	\N	3	1051	\N	54fce22d-55c2-4325-b7cb-84d9ba8aea7e
3691	Home Again	0	\N	3	1051	\N	56eb8f52-4339-4d2d-8871-cb399ac19d09
3692	New Edition	0	\N	3	1051	\N	67327d08-24ee-4022-9b62-98fefc7edf29
3693	Lost in Love: The Best of Slow Jams	0	\N	3	1051	\N	72f9ef86-6ce9-4cfa-9530-da500626be23
3694	New Edition	0	\N	3	1051	\N	78e7fe6d-e5ed-3d79-a79d-a8347d80e480
3695	All the Number Ones	0	\N	3	1051	\N	8e497051-8f06-44b1-8521-38edc38581b4
3696	20th Century Masters: The Millennium Collection: The Best of New Edition	0	\N	3	1051	\N	93fe74f6-0c88-4be2-9c83-976be9b89f77
3697	20th Century Masters: The Millennium Collection: The Best of New Edition	0	\N	3	1051	\N	953e4523-7536-3975-996e-00d61512aa9f
3698	All for Love	0	\N	3	1051	\N	9be07c0a-1b9b-46fe-af74-93b2fed7c662
3699	Gold	0	\N	3	1051	\N	b955aa57-3cb1-44b7-a9a3-e54dd08e3a63
3700	Christmas All Over the World	0	\N	3	1051	\N	cf093681-d467-457f-9cfa-5039fb9c0d85
3701	One Love	0	\N	3	1051	\N	efcbd0c3-4758-4ccf-8747-a4972eed9e31
3702	Heart Break	0	\N	3	1051	\N	f7d83098-1d45-3f72-9a08-8fb69bcc0562
3703	You Get What You Give	0	\N	3	1053	\N	44c3e798-9f1e-4a42-a92e-fdca5af59ef6
3704	Maybe You've Been Brainwashed Too	0	\N	3	1053	\N	5b16f99a-118a-47b7-83b3-4af1a9ed91d9
3705	Maybe You've Been Brainwashed Too	0	\N	3	1053	\N	9017679c-2ef9-4211-9605-70e81999ae6b
3706	Maybe You’ve Been Brainwashed Too.	0	\N	3	1053	\N	c4ee98a5-c975-4995-b5a9-e75877f76738
3707	Maybe You’ve Been Brainwashed Too.	0	\N	3	1053	\N	f65ff263-eaa5-4489-8339-53b47f1d7bbf
3708	Stagnant Progession	0	\N	3	1054	\N	11872cd2-0d63-4c14-b1a1-4ad91b964c07
3709	Obscure Master Plan	0	\N	3	1054	\N	6aa54460-3b04-4023-8f19-73db1df6cad6
3710	Stagnant Progession	0	\N	3	1054	\N	8689714c-e0c7-4db6-aecd-79e31d0d34d6
3711	Through the Make Believe	0	\N	3	1054	\N	a6d4b667-7d9f-4c35-90cd-3fee0cbc0959
3712	Solving for X	0	\N	3	1054	\N	d7fd189b-58a6-4740-8682-1a5b064862e1
3713	New England	0	\N	3	1055	\N	0adb9958-d6c8-4aee-a1e5-40785f1ee83b
3714	Explorer Suite	0	\N	3	1055	\N	18059195-8aa2-3fa4-b636-56ba4ffd9e0b
3715	New England	0	\N	3	1055	\N	5120d675-94a0-40dd-9ab9-963bad30c5e4
3716	Walking Wild	0	\N	3	1055	\N	5ab1e121-0bc1-391c-8385-149d6cd5d8f0
3717	1978	0	\N	3	1055	\N	6b8736ae-187d-4fd2-8406-bfd7eee85af1
3718	New England	0	\N	3	1055	\N	9a4a6e86-0f06-4902-88f7-b21059ef9596
3719	Explorer Suite	0	\N	3	1055	\N	c335b02a-ccc7-42b9-848e-511a20913fec
3720	Live At the Old Waldorf	0	\N	3	1055	\N	d26444c7-4148-4d0e-a974-40b3d0fbdc08
3721	Walking Wild	0	\N	3	1055	\N	d9364665-793e-47e8-b138-4cba39c31675
3722	You Can't Keep Living This Way	0	\N	3	1055	\N	e9ee546f-e639-4127-967f-3db67d70c80e
3723	New Regime	0	\N	3	1056	\N	13598a45-847b-407c-8f94-b988a52052cf
3724	New Brutalism 2001-2003	0	\N	3	1057	\N	29912066-a170-4396-8225-77fdc1526e16
3725	Actual Record	0	\N	3	1057	\N	77039d2e-88e9-48db-830a-a80d0dee9f7a
3726	New Again	0	\N	3	1058	\N	09c709d8-1bc2-39c7-87cd-746065cf5177
3727	Louder Now	0	\N	3	1058	\N	0f5d3604-ea67-3bb0-88ae-2db7f889db38
3728	Louder Now: PartTwo	0	\N	3	1058	\N	15c20c62-d2f9-402d-95b7-0c2bb033d529
3729	Where You Want to Be	0	\N	3	1058	\N	17f88c72-99db-495c-8fbd-37610350c785
3730	New Again	0	\N	3	1058	\N	4016c4f7-2e56-3b96-a073-1665a693149e
3731	Louder Now	0	\N	3	1058	\N	4527a812-8de1-4561-b397-363b29256686
3732	New Again	0	\N	3	1058	\N	49bf2bd1-3d90-4552-9f3c-e215992ea9e2
3733	Tell All Your Friends	0	\N	3	1058	\N	5dbe9c74-4f8b-4ee6-8dc1-a97de54adc0a
3734	Taking Back Sunday	0	\N	3	1058	\N	7ecc7bd3-ddf3-4244-82eb-d21afc99a525
3735	Taking Back Sunday	0	\N	3	1058	\N	903d6ac5-2f7a-46bd-a570-47b7ddf29c17
3736	Louder Now	0	\N	3	1058	\N	94d9760a-01c0-3c5c-8910-0110a1fc9095
3737	Taking Back Sunday Demos	0	\N	3	1058	\N	94e430c0-28f6-4d7c-9666-1ef9a21757f3
3738	Louder Now	0	\N	3	1058	\N	a13eca4e-70a6-4062-bd80-04dee027a305
3739	Tell All Your Friends	0	\N	3	1058	\N	a605e4ac-b112-4aaa-ab80-8aebc483711a
3740	Louder Now: PartOne	0	\N	3	1058	\N	a7682f0f-b2af-478e-bc89-226002dc412a
3741	New Again	0	\N	3	1058	\N	b376aa1f-02a3-4d49-8c09-3477bebabe2c
3742	Notes From the Past	0	\N	3	1058	\N	b4b4ed17-323e-4104-a850-d0fab83a6c6f
3743	Happiness Is	0	\N	3	1058	\N	b53339f6-67b2-42dd-8fdb-a5bc7ce6e8e0
3744	TAYF10 Acoustic	0	\N	3	1058	\N	bb7e4cf2-dfd1-44dc-8bd4-5f662dfb5910
3745	New Again	0	\N	3	1058	\N	c8665478-f002-3646-9f09-720afade1df4
3746	Tell All Your Friends	0	\N	3	1058	\N	d21b975d-a422-42f2-9716-7c2b0a052ec4
3747	Louder Now	0	\N	3	1058	\N	d2cea175-f231-4f03-8743-d3879d82ffae
3748	Louder Now	0	\N	3	1058	\N	e1dc9f1f-9f34-4364-9727-ce7909ba2d78
3749	New Again	0	\N	3	1058	\N	f186deb8-d2de-4e99-a186-7e767553e4a7
3750	Tell All Your Friends	0	\N	3	1058	\N	fd3c3217-92d9-39f6-99b0-79c9f9f1a4aa
3751	Wake Up! Wake Up!	0	\N	3	1059	\N	05a51df5-3fea-4fc9-b398-613b5a04bff8
3752	Best Night of Our Lives	0	\N	3	1059	\N	40b9802d-85cb-4551-bedb-970ccf271984
3753	Anthems for the Imperfect	0	\N	3	1059	\N	b8f349d5-e6c8-4e42-b734-56fa1c6b8921
3754	Stand Up	0	\N	3	1059	\N	f322f848-05f7-477b-baf9-62531eda40de
3755	Sundayrunners	0	\N	3	1060	\N	43724c1d-8896-4e35-80db-7bb5495a2965
3756	Tronic Blanc	0	\N	3	1062	\N	abd5a056-11c0-3728-80c5-44d015e144f7
3757	Destruction Unit / Black Sunday	0	\N	3	1062	\N	f11e59a8-818d-452f-ad8d-65dcf931273a
3758	Tronic Blanc	0	\N	3	1062	\N	ff669ede-8d4e-41fe-ad0c-fc8b2b714062
3759	On	0	\N	3	1064	\N	6e357d38-0bd1-4d61-bbde-6efc24364f13
3760	Many Will Play	0	\N	3	1064	\N	841599fa-8362-4cec-8ff6-e5fb995fb416
3761	The Mean Streets of Goleta	0	\N	3	1064	\N	b62bda45-6f71-4646-b148-06594e0e41c4
3762	We Sang as Ghosts	0	\N	3	1065	\N	3b4ad382-be3b-431f-9b3a-569a8edfdf27
3763	Low Sunday Ghost Machine	0	\N	3	1066	\N	184f7101-a2de-4d53-bf68-ad0d5d49fece
3764	King Rhichard's Sunday Best	0	\N	3	1068	\N	70cd4dc2-578a-4029-b229-d1b7e3f9a647
3765	Greatest Hits	0	\N	3	1068	\N	c9009bc7-7d34-4df1-adad-6df3df0115b9
3766	Wake Up! Wake Up!	0	\N	3	1069	\N	8ae48eef-0b04-4516-ba5c-77fd63bab146
3767	Back Off Cupids	0	\N	3	1070	\N	bead3ea5-3366-42da-abc3-b734de1b4365
3768	Look Back and Laugh	0	\N	3	1071	\N	aa156937-4d97-47f5-b633-622c6972e3a9
3769	Self Titled II	0	\N	3	1071	\N	cad31572-a958-4584-8951-0ca7aa40ef86
3770	Fast Cloud Slow Cloud	0	\N	3	1072	\N	083c80c4-64b5-4e6e-bd6a-343fb7b2d390
3771	Blissters n Basements	0	\N	3	1072	\N	5fcfe717-a4ed-4d89-b94d-cc7396517175
3772	Eaten Back to Life	0	\N	3	1073	\N	19244965-9284-436f-b3b8-d0b59b57d42e
3773	Split in Two	0	\N	3	1073	\N	7146336f-9379-4801-8aef-6199d4401a06
3774	Love You to Death	0	\N	3	1073	\N	7307095c-30ff-4ee0-b8c6-6b50fa9e8b95
3775	Killer	0	\N	3	1073	\N	d3aa2ea7-7476-44af-9b77-05147bd70f81
3776	Lend You a Hand	0	\N	3	1075	\N	e12fe075-c385-4de6-8401-e54b13ad761c
3777	Runnin' Thru My Bones	0	\N	3	1075	\N	f80ecaa5-4234-46b0-967d-8ee7a6b14d77
3778	Dress Code	0	\N	3	1081	\N	6a147a54-9a6d-4ce1-bff1-c89de5e55831
3779	The Top	0	\N	3	1082	\N	0cc7ebf4-cba0-3821-932b-ea132950ba7d
3780	Japanese Whispers	0	\N	3	1082	\N	186edf0e-9c33-4233-8472-772c766d0f23
3781	The Top	0	\N	3	1082	\N	1c7c3a67-247a-3e83-9f75-e7d6d71ed3c7
3782	Three Imaginary Boys	0	\N	3	1082	\N	2207aa68-71c6-3371-986f-0d56ab63de56
3783	Faith	0	\N	3	1082	\N	30f56ff9-8cc1-32e1-8860-e914298155f6
3784	Three Imaginary Boys	0	\N	3	1082	\N	38753b29-71ab-4b65-b244-466824a8b79a
3785	Pornography	0	\N	3	1082	\N	395f9ac1-4440-4952-87ea-bb4726943ef5
3786	The Top	0	\N	3	1082	\N	5a674aa0-3afa-3044-8852-4cef4a77bdf3
3787	Concert: The Cure Live / Curiosity: Cure Anomalies 1977–1984	0	\N	3	1082	\N	684cff10-29c0-40f4-940c-dc990e418258
3788	The Top	0	\N	3	1082	\N	6e605ceb-7c51-4a4d-8dd2-3744ade5d011
3789	Seventeen Seconds	0	\N	3	1082	\N	7e21d693-4c1e-3219-8fbc-94d9a2d1bc0f
3790	Faith	0	\N	3	1082	\N	801abe5b-e512-3cf8-b73b-8a0a1532cf53
3791	Happily Ever After	0	\N	3	1082	\N	83f5b005-d981-4338-ad38-a37a15721998
3792	Faith	0	\N	3	1082	\N	8abfb36b-9cc0-320f-945c-4208de4f82ec
3793	Boys Don’t Cry	0	\N	3	1082	\N	8c0252e4-3d79-3ce1-8a77-c79394549889
3794	Faith	0	\N	3	1082	\N	8d633474-f161-470b-b47c-cf6383f235a9
3795	Concert: The Cure Live	0	\N	3	1082	\N	9cc9bcf3-3d2f-44bc-a18e-a92a0448b98f
3796	Japanese Whispers	0	\N	3	1082	\N	a63b07a1-89be-3df6-b965-17705bd94932
3797	Three Imaginary Boys	0	\N	3	1082	\N	a661d5b0-7f4d-46e0-966b-55dc1eee254b
3798	Japanese Whispers	0	\N	3	1082	\N	abefe2e1-6411-42e3-a142-8672005866e6
3799	Pornography	0	\N	3	1082	\N	c0ab9780-6b0c-377d-b6f7-0dc38344f282
3800	Seventeen Seconds	0	\N	3	1082	\N	ca6f753b-4db1-4ca3-aebd-cfff8902a05a
3801	Boys Don’t Cry	0	\N	3	1082	\N	cb1cfce3-7cce-3831-997c-e9f55226e7da
3802	Boys Don’t Cry	0	\N	3	1082	\N	d08498ac-25a1-3e53-a0ff-717cb61f514c
3803	Concert: The Cure Live	0	\N	3	1082	\N	d4b62506-9be0-3a7e-ac94-e22b0d9f999c
3804	Country Archives	0	\N	3	1085	\N	88d2e46a-18d5-4ef4-95f9-4d646dd92962
3805	Live	0	\N	3	1085	\N	93989690-2923-4c02-8bb4-a6c0b829f419
3806	Four to the Bar!	0	\N	3	1085	\N	9400f0b9-fc93-4901-b824-3b7a0982e2d5
3807	Bottled	0	\N	3	1085	\N	f7b2ba0c-94ff-46ec-b50d-fa7762d80638
3808	Tough Love	0	\N	3	1088	\N	05d6a8d6-a3bc-4a38-b2a7-89ee7db25cf8
3809	2nd Avenue	0	\N	3	1088	\N	0a4d98e6-36cb-41c4-b992-7b46234a06f1
3810	Idle Cure	0	\N	3	1088	\N	9997bba3-ff1a-48c3-8457-fcad779f71fb
3811	Eclipse	0	\N	3	1088	\N	99a98307-982c-4f5a-bbe7-efc465646037
3812	Inside Out	0	\N	3	1088	\N	af2bfc95-e3dd-4cbc-ad0b-7802028c83d5
3813	Your Head Smells Good	0	\N	3	1090	\N	a4509c18-ab34-499c-9f4e-0929d403d0e9
3814	Defiance	0	\N	3	1090	\N	cd6e5c39-b16c-4662-bafa-d395b3a0cc05
3815	Hazzard's Cure	0	\N	3	1091	\N	a2eae12a-a4d9-497b-a885-b8fd616cae49
3816	Hazzard's Cure	0	\N	3	1091	\N	cbc2c817-010e-4881-9a03-c7ff6ed6afe0
3817	The Tempo of Bicycles and Boats	0	\N	3	1092	\N	2d4d0002-a4ae-477a-a9ce-d3d5a55e573d
3818	Kill or Cure	0	\N	3	1093	\N	aa22cb50-8d4f-43ff-8721-dbb53400a4f2
3819	Like Crazy Doves	0	\N	3	1094	\N	5b358c64-bcc7-4d92-b0fb-dbccd580b4e9
3820	Undeniable / Irresistible	0	\N	3	1094	\N	602a979f-c730-461d-affb-e6725ddd2b95
3821	You Absorb My Vision	0	\N	3	1096	\N	3276a4cf-e532-4577-9f64-7449ea240333
3822	Physical Angel	0	\N	3	1096	\N	33e8fe6c-dbbc-4b63-8d6d-b388a75c5353
3823	The Bunny The Bear	0	\N	3	1097	\N	383d0f48-290b-472a-b48b-7795e491c281
3824	If You Don't Have Anything Nice to Say...	0	\N	3	1097	\N	546bb726-a8e6-41ab-a9ca-c4fa1bbdcc83
3825	Stories	0	\N	3	1097	\N	6d2aa364-8f19-414b-877b-468d5d096a16
3826	Food Chain	0	\N	3	1097	\N	94b4af03-eca8-4fb5-8ac7-08ffc153c807
3827	The Stomach for It	0	\N	3	1097	\N	ef00aefe-227d-4576-8fa9-1cec1b79e555
3828	Love We Are We Love	0	\N	3	1098	\N	616a49b2-b1ba-4875-a4be-5b5a36712de5
3829	Uglier Than You'll Ever Be	0	\N	3	1100	\N	07d4330b-e1b0-49e0-bd5e-aa0cdce039df
3830	Easy Listening for the Underachiever	0	\N	3	1100	\N	0f1c9dc6-c245-4013-a834-17d93b3653fe
3831	Easy Listening for the Underachiever	0	\N	3	1100	\N	35a47c8b-50ff-45ae-9c6a-ab78932bdcd4
3832	Emerge	0	\N	3	1100	\N	5c161be1-a34b-4c0a-9bf3-2211ebdc67d4
3833	Play Chess	0	\N	3	1100	\N	70c631d8-cf1f-4d16-9b9d-f9269497e40b
3834	Emerge	0	\N	3	1100	\N	ea7c5a71-1cd6-37f9-8b16-e47c3c7b71fe
3835	Rabid Reaction	0	\N	3	1101	\N	0d7c48b1-19b9-48b1-8adb-75bccadf8212
3836	Misery Loves Company	0	\N	3	1101	\N	12cb3d8c-87c9-469e-a544-122678a1d77f
3837	Crawling Blind	0	\N	3	1101	\N	1a023b5b-207d-4629-8e4a-197b00393b58
3838	Rabid Reaction	0	\N	3	1101	\N	2b62600f-44fe-4539-8204-e59f228013cb
3839	Token Bones	0	\N	3	1101	\N	2d847852-c5fc-4767-bed1-24f0c9c8e27f
3840	Freak Show	0	\N	3	1101	\N	46aa8d2d-115e-4038-8487-892cb6187213
3841	Land of the Lost	0	\N	3	1101	\N	5f7d1787-812b-4ee0-9035-2242b592c049
3842	Boston Wolfpack	0	\N	3	1101	\N	906adb3c-c1e0-47d2-b828-e47e7a5c18ec
3843	One False Move	0	\N	3	1101	\N	c2a9ece5-2a0f-4c9f-a520-3ad0e3489c0a
3844	Land of the Lost	0	\N	3	1101	\N	d58c931c-f0a6-4ee0-bfb5-be6107fef500
3845	Enter: The Conquering Chicken	0	\N	3	1102	\N	15d2007e-df26-4c04-9afd-caee905fb0b0
3846	Frenching the Bully	0	\N	3	1102	\N	47651943-21e5-4525-8d3e-c4c4b720c754
3847	Seafish Louisville	0	\N	3	1102	\N	52f81d8d-dae8-4342-89ab-d0fcc40c6a21
3848	From The East To The West	0	\N	3	1102	\N	55a975dc-7e45-48b7-ae84-0883cd10862c
3849	Frenching the Bully	0	\N	3	1102	\N	5acbc9cb-6bb7-481b-9999-d2aa172b0478
3850	Enter: The Conquering Chicken	0	\N	3	1102	\N	6704f177-1c1c-4aba-83fe-f78dafecbd91
3851	Frenching the Bully (re-remixed and remastered)	0	\N	3	1102	\N	8a25e77b-9225-4eba-bbf9-b42e0c5a47af
3852	The Best of The Gits	0	\N	3	1102	\N	c43207ea-5161-459d-a613-7897639007a1
3853	Kings and Queens	0	\N	3	1102	\N	e2448686-0d66-410e-bae0-fa3793957395
3854	Diamonds in the Coal	0	\N	3	1103	\N	114b06f2-bcdd-4026-831e-cc9a1d8da33b
3855	Up There Down Here	0	\N	3	1103	\N	13c1500d-ce4a-407b-a2d1-4b8cf76c44ff
3856	Love Is Rain	0	\N	3	1103	\N	2eccda98-0674-41b6-864e-9090039ef022
3857	Amazing Grace	0	\N	3	1103	\N	6436e508-7304-4930-a6ba-95eef200ebf4
3858	River Songs	0	\N	3	1103	\N	c46a6b0c-1c91-4857-96bd-41c1d050afdd
3859	The Unfortunate Result of Spare Time	0	\N	3	1103	\N	c7af691b-3e1c-4756-96b2-08d998e0f475
3860	Renew	0	\N	3	1103	\N	da9cc4a3-b24d-4e84-9167-640fbd77dc4c
3861	Hate Your Friends	0	\N	3	1104	\N	00a8fd9c-263a-3325-aa68-6a8a5935f09e
3862	Come On Feel The Lemonheads	0	\N	3	1104	\N	0deaa290-438b-36e3-86d0-6676845539a1
3863	Creator	0	\N	3	1104	\N	24f6b42d-8519-33ff-9da6-3c79cef200d5
3864	Come On Feel The Lemonheads	0	\N	3	1104	\N	2ec701cc-e6c3-4bc0-822f-2dac4a411250
3865	The Eye of Evan Dando	0	\N	3	1104	\N	36b146c5-951a-4194-be4c-440955fd5ca1
3866	New York New York	0	\N	3	1104	\N	3acc7088-3aaa-4e47-b7ed-8f8b60313117
3867	Lick	0	\N	3	1104	\N	431e4543-c4bd-4899-939a-0a79c8c53f02
3868	Lick	0	\N	3	1104	\N	45038774-534b-383d-ab5f-b95d7faafb9e
3869	Creator	0	\N	3	1104	\N	4c974408-e489-4185-b1fe-c3bcaf22d5bf
3870	Lick	0	\N	3	1104	\N	5876add3-d2d7-4ccd-856e-362169112b26
3871	It's a Shame About Ray	0	\N	3	1104	\N	62b96548-83c8-426d-b4cd-fb73e91555e4
3872	Lovey	0	\N	3	1104	\N	6a936c83-524a-4ffa-a95f-1d8c900d6ef6
3873	Car Button Cloth	0	\N	3	1104	\N	76f6f7a8-4f91-42d4-849a-3c59ac2924da
3874	Create Your Friends	0	\N	3	1104	\N	78f1993a-cdf8-43f0-bf9c-fc416fa35d3d
3875	Lovey	0	\N	3	1104	\N	790e0eea-f60d-4f09-92f4-f7cfe849f880
3876	It's a Shame About Ray	0	\N	3	1104	\N	8113c075-e1ae-3b92-a598-593ada98f0bc
3877	Come On Feel The Lemonheads	0	\N	3	1104	\N	87500ed8-61b5-3ca6-bbc9-d0798261ed33
3878	Come On Feel The Lemonheads	0	\N	3	1104	\N	8a1d610c-4b9e-3205-af82-f5917d1a6a50
3879	Hate Your Friends	0	\N	3	1104	\N	b5b70030-158e-404d-90fe-6cf1f658012b
3880	It’s a Shame About Ray	0	\N	3	1104	\N	c6f59916-965f-4d15-abf6-bad4fb372837
3881	Lick	0	\N	3	1104	\N	cfcd9b58-88be-3f7b-9f79-f0ef291c8b12
3882	Creator	0	\N	3	1104	\N	d5c566f1-b3fe-4889-9790-8da3dc7ab7a8
3883	Hate Your Friends	0	\N	3	1104	\N	d6aabe5b-bbf3-4a13-8a4c-87032d671644
3884	Lick	0	\N	3	1104	\N	d9e5192b-5238-3838-acb5-7c82307a462b
3885	Creator	0	\N	3	1104	\N	deddd4aa-fb96-4229-aac2-34515b29005d
3886	Candy-O	0	\N	3	1105	\N	08bce009-34de-3c27-b44e-72c3c15dacb9
3887	Candy-O	0	\N	3	1105	\N	175d4269-13e8-4a65-9270-173aa3dbeb74
3888	Heartbeat City	0	\N	3	1105	\N	1ba7a7e6-052d-42e4-bd78-56f33c2c958a
3889	Panorama	0	\N	3	1105	\N	22abfe6e-8dd7-419f-8f10-9d47606b873d
3890	Shake It Up	0	\N	3	1105	\N	3187b9f1-4f77-48c7-979f-32a0786c180a
3891	The Cars	0	\N	3	1105	\N	32595a0a-835c-4ba5-9ff1-8b8310e5e1cb
3892	The Cars Greatest Hits	0	\N	3	1105	\N	38bb3960-8bb7-4a13-9c27-4c9da356cdf7
3893	Shake It Up	0	\N	3	1105	\N	409ead4d-387f-3dc9-aec1-13b9d22ced89
3894	The Cars Greatest Hits	0	\N	3	1105	\N	432f6da0-cfd7-3432-9ea1-5a37b42ac078
3895	Heartbeat City	0	\N	3	1105	\N	589545a8-8b6a-4d24-ba51-b46b4ba11cf6
3896	Candy-O	0	\N	3	1105	\N	64a6c9c3-47be-4e3f-a068-d31a50da0409
3897	The Cars	0	\N	3	1105	\N	725ac387-4da7-4905-a09b-f2e2be6f78ea
3898	Candy-O	0	\N	3	1105	\N	7c3aeefc-8428-4796-b565-47808bc44c76
3899	Heartbeat City	0	\N	3	1105	\N	82db403e-e66c-4110-829c-db317bfd669f
3900	Heartbeat City	0	\N	3	1105	\N	8c3970ab-fd00-4098-8605-4c8cdb98bdf8
3901	The Cars Greatest Hits	0	\N	3	1105	\N	90160b61-0563-44dc-9c30-abf2d4b5dbe9
3902	Shake It Up	0	\N	3	1105	\N	9ba358f6-c56a-4f03-98f9-ab19b77ae836
3903	The Cars	0	\N	3	1105	\N	a47b6ee6-266e-44d8-9a26-251107eae25a
3904	The Cars Greatest Hits	0	\N	3	1105	\N	a9ae648a-25fd-477a-98b1-f16949e32898
3905	Shake It Up	0	\N	3	1105	\N	c05e105e-ec26-4aaa-b5e3-e74b8ebe2377
3906	The Cars	0	\N	3	1105	\N	d27c76ed-f89e-33f4-991b-b79779bdede2
3907	Heartbeat City	0	\N	3	1105	\N	d28cb978-e649-4aa3-9af5-8210cb4adbb8
3908	Heartbeat City	0	\N	3	1105	\N	df07423a-2566-315f-bc4f-640c754bdd09
3909	Candy-O	0	\N	3	1105	\N	eda28fee-d775-3a60-b3dd-f6cf26f13a7c
3910	Heartbeat City	0	\N	3	1105	\N	f43996d5-b160-41a9-810d-1205e6c3aaf3
3911	Infinity	0	\N	3	1106	\N	18a4027f-4bc5-4bd7-b0bc-e68712070e7c
3912	Heart Ache & Dethroned	0	\N	3	1106	\N	25288f8f-4057-41b5-b980-196126552507
3913	Infinity	0	\N	3	1106	\N	2ce401c9-2dab-35c6-96f0-2fa5c48c2a7e
3914	Jesu	0	\N	3	1106	\N	34881aef-1149-4460-802b-cbd89d4ad556
3915	Conqueror	0	\N	3	1106	\N	3a99332d-e326-46d6-acdc-f9935bdb9efb
3916	Collected: 2004-07	0	\N	3	1106	\N	4a2791c8-a745-462c-9411-789e782e246a
3917	Everyday I Get Closer to the Light From Which I Came	0	\N	3	1106	\N	4ca8bae8-f2a5-46a1-981c-3bba4985fda0
3918	Ascension	0	\N	3	1106	\N	51f6da0f-a67c-48ad-a546-629a3e635411
3919	Everyday I Get Closer to the Light From Which I Came	0	\N	3	1106	\N	575f4b87-21b0-4b7e-a73b-c987564c9d39
3920	Jesu	0	\N	3	1106	\N	63d3cad2-4b18-4ac9-ab8b-448f8f9a9f37
3921	Heart Ache & Dethroned	0	\N	3	1106	\N	6d6b7b3b-c103-4745-9519-f76ecc8b38ae
3922	Jesu	0	\N	3	1106	\N	89a46b85-115b-3b10-9b8b-1022e2d47af5
3923	Infinity	0	\N	3	1106	\N	8ede9dee-c5ea-4376-b4b1-ba60de35aa96
3924	Jesu	0	\N	3	1106	\N	9b091bcd-f336-3381-a7c3-8783dff901d7
3925	Jesu	0	\N	3	1106	\N	ba7a97f4-1a5c-3f06-9a0f-57a9f4c61a06
3926	Heart Ache & Dethroned	0	\N	3	1106	\N	bc013368-2645-465c-bbe7-42d0737bd8c0
3927	Infinity	0	\N	3	1106	\N	c24e31fd-8348-42aa-8cfc-fc9a8fd3a9be
3928	Everyday I Get Closer to the Light From Which I Came	0	\N	3	1106	\N	ce43b70f-eb2e-47cc-847e-73594fbf1eda
3929	Conqueror	0	\N	3	1106	\N	d2876a54-b230-38a3-8c01-42cfc1a74de6
3930	Pale Sketches	0	\N	3	1106	\N	d68f7f67-ad9a-4b9c-af00-be44ccc37a20
3931	Conqueror	0	\N	3	1106	\N	ea15a511-f575-38d5-a041-517d2245da99
3932	Conqueror	0	\N	3	1106	\N	ec40c9a5-4375-3da2-9d6f-56feb401100c
3933	Jesu	0	\N	3	1106	\N	edb16c87-e168-3a07-a107-822411a19803
3934	Ascension	0	\N	3	1106	\N	f0a876b9-fc2f-4041-a72d-c3fd957e094e
3935	Pale Sketches	0	\N	3	1106	\N	faff0678-6399-3b29-a1d9-66d7193f5680
3936	Psychocandy	0	\N	3	1110	\N	00ee25c9-ab9a-43e0-92c8-3167db1bb120
3937	Honey's Dead	0	\N	3	1110	\N	237447a9-4c62-31be-af0a-69d2128a4bf6
3938	Psychocandy	0	\N	3	1110	\N	31eb0922-5c4a-4aa9-bdb9-428b4008a3b9
3939	The Sound of Speed	0	\N	3	1110	\N	33e60f1a-5d24-4177-a5cc-4a10c93f2e52
3940	Barbed Wire Kisses	0	\N	3	1110	\N	3bee355c-9df9-483a-82c9-d66c40eedd56
3941	Honey's Dead	0	\N	3	1110	\N	4342fb86-faee-45df-a6c7-446334612d6c
3942	Automatic	0	\N	3	1110	\N	472ba8da-9953-345d-8540-a38a826119b5
3943	Psychocandy	0	\N	3	1110	\N	4b15b383-3a20-3ede-8cc4-b1a64bb465d3
3944	Darklands	0	\N	3	1110	\N	65b899f5-2861-3887-8a65-ecb560bda761
3945	Automatic	0	\N	3	1110	\N	6629d170-17fb-44e5-b2e0-365c751184b6
3946	Automatic	0	\N	3	1110	\N	67d21e7f-1657-3f21-94c0-f1a5825e3dc3
3947	Fuck	0	\N	3	1110	\N	7441ee39-6cb9-498e-b5ae-eeb1895ca9d4
3948	The Peel Sessions	0	\N	3	1110	\N	757c224d-8bf2-48ef-bd04-c6f87b6f1f36
3949	Darklands	0	\N	3	1110	\N	76b9d94a-aae3-4a4a-93af-420fbf119933
3950	Barbed Wire Kisses	0	\N	3	1110	\N	895260fd-4908-458a-959c-6f0334778ff1
3951	Honey's Dead	0	\N	3	1110	\N	9dcd80b2-0c7d-3a61-acf4-af275aab7f47
3952	Psychocandy	0	\N	3	1110	\N	b6acb375-e8c7-3e7b-ac32-72947e2e3e42
3953	Automatic	0	\N	3	1110	\N	c03c81ae-6306-4f82-b2ee-75e1efda37c6
3954	Darklands	0	\N	3	1110	\N	c27a08b4-e063-4057-9fe8-9e7c2735d5b5
3955	Psychocandy	0	\N	3	1110	\N	cffcc1fb-ddcf-3487-85c3-b1b780118dcc
3956	Barbed Wire Kisses	0	\N	3	1110	\N	d16e881b-5856-32b2-8bd0-69ec337ee340
3957	Automatic	0	\N	3	1110	\N	dfc826ba-cb71-417a-bdb8-f1052df0791b
3958	Live in Heaven 1987	0	\N	3	1110	\N	ed4fe2e2-ae03-40be-a0a7-73855e09f21c
3959	Barbed Wire Kisses	0	\N	3	1110	\N	f7d6df9e-0ea2-4a69-9b3b-55a6b49feffb
3960	Automatic	0	\N	3	1110	\N	fa6bd610-6c53-4d90-9baf-37c1cc47d8da
3961	Down With Liberty… Up With Chains!	0	\N	3	1111	\N	01cb3c1c-2ad4-3c9b-8dea-3edece6741bc
3962	Minimum Rock N Roll	0	\N	3	1111	\N	1df78b35-3aa4-4019-bc45-3b6848b70537
3963	Down With Liberty… Up With Chains!	0	\N	3	1111	\N	250eb68d-c37c-4756-a0a1-fe15affbe83a
3964	Down With Liberty… Up With Chains!	0	\N	3	1111	\N	968b68db-6947-3a7b-8436-f907953ebb62
3965	In Cold Blood	0	\N	3	1111	\N	d5d27349-71ee-4fbc-8940-26c968f91ea7
3966	Music’s Not for Everyone	0	\N	3	1111	\N	eacc777c-7309-405e-bb83-c336ee9070ba
3967	Shut Up and Bleed	0	\N	3	1112	\N	5368eaf9-4006-4ca5-8bb0-cf9d5f37a107
3968	Shut Up and Bleed	0	\N	3	1112	\N	fd732f76-d52b-4ec1-91a0-2e028d6b35ed
3969	Everything	0	\N	3	1112	\N	ff91da1f-30c9-4ffc-a45d-0857c0cacf7d
3970	Antarctica	0	\N	3	1113	\N	9d9d3d77-dc9f-4d96-aceb-5ce186ba8c97
3971	Mercury	0	\N	3	1113	\N	9ee5c810-df79-42db-b88e-936620d95710
3972	Neverland Sessions	0	\N	3	1113	\N	aba5fbb8-eac1-437c-9b7d-b9c9b34137b2
3973	Shawl	0	\N	3	1113	\N	e726de65-fb35-4c94-ab68-9aa20b85e258
3974	Blue	0	\N	3	1114	\N	01348943-8cc4-44da-92c3-9fe527a24908
3975	Bang	0	\N	3	1114	\N	0c4f151d-4161-4ab1-b204-abda6f34c8d5
3976	Show	0	\N	3	1114	\N	2ca4857f-8dc1-43a5-bd6d-e6efe18d2bc8
3977	Goat	0	\N	3	1114	\N	39768213-ed10-4cdb-a516-d8194f3ac3aa
3978	Down	0	\N	3	1114	\N	46b76193-bf9e-4f57-a142-be73b5b11058
3979	1990-05-20: Uptown Bar + Grill, Minneapolis, MN, USA	0	\N	3	1114	\N	4df4d7ee-1750-48ed-a683-d54d21f7b0e7
3980	Head / Pure	0	\N	3	1114	\N	5257fe81-b82e-47ec-ad54-60e4c04ccc22
3981	Head	0	\N	3	1114	\N	58591c4a-3fb5-40e8-a150-155d36507b6e
3982	Shot	0	\N	3	1114	\N	638372f3-87b8-43e9-9d13-340bf9f61035
3983	Head	0	\N	3	1114	\N	69a2c8bb-3fa9-443f-87a8-8d4f2c6a775e
3984	Liar	0	\N	3	1114	\N	89f8d890-f7fa-4747-a108-50773326fa08
3985	Down	0	\N	3	1114	\N	8ad66b2a-9513-4b1b-b017-932b0b68a91e
3986	1990-05-20: Uptown Bar + Grill, Minneapolis, MN, USA	0	\N	3	1114	\N	91229ee8-ea3e-42b2-8fba-c5f9ac4f80e8
3987	Head	0	\N	3	1114	\N	9a68a85a-64a6-4d6f-ace3-6efcaf169494
3988	Shot	0	\N	3	1114	\N	b5c17241-a530-4a59-ae30-147407daa7f9
3989	Head / Pure	0	\N	3	1114	\N	d2d6cee4-99ad-3b10-b32c-e54de9ec5535
3990	Liar	0	\N	3	1114	\N	d9b3e795-c0d0-3492-a12c-b391ef9fc92b
3991	Goat	0	\N	3	1114	\N	da363688-9877-4cba-8ee0-89b42649e352
3992	Show	0	\N	3	1114	\N	e8ddceca-4c34-397e-9a91-65b9b429c8d6
3993	Goat	0	\N	3	1114	\N	f2830a83-184b-45b4-829d-e7af946ff3b6
3994	1997-11-02: Tuxedo Junction, Danbury, CT, USA	0	\N	3	1114	\N	f58358de-00a2-4575-bc7b-0e840e32ac3f
3995	Liar	0	\N	3	1114	\N	fd587259-e1f5-4ee0-a378-aafa3f20da72
3996	Album 1700	0	\N	3	1115	\N	0223c539-e0dd-4d92-9fcc-e16628167986
3997	Peter, Paul and Mommy	0	\N	3	1115	\N	0580de85-acf6-3c5d-a721-cd40e0d53a7e
3998	Reunion	0	\N	3	1115	\N	0786a777-a1f3-375b-ac55-ab37095b424a
3999	Peter, Paul and Mommy	0	\N	3	1115	\N	11ca7bf7-20db-4110-adbd-ae43ba32c528
4000	Peter, Paul and Mary	0	\N	3	1115	\N	1b846511-7a8e-3885-baaf-40a33ee7d08d
4001	No Easy Walk to Freedom	0	\N	3	1115	\N	1bc06eb6-e53a-3843-ba33-2640aa22b190
4002	A Song Will Rise	0	\N	3	1115	\N	296fb7cf-4f87-45ad-8ee3-d64c3e6ed591
4003	Peter, Paul and Mary	0	\N	3	1115	\N	41ff35a6-5fc4-4e48-9d96-2f34357ab334
4004	In Concert	0	\N	3	1115	\N	518c696a-488a-3f93-b8c7-499e70c618b8
4005	A Holiday Celebration	0	\N	3	1115	\N	60a7d267-6b74-36fa-af3d-4f27ca7efe0f
4006	In the Wind	0	\N	3	1115	\N	72610acd-1ae2-3651-a22c-378c99f02721
4007	In Concert	0	\N	3	1115	\N	7a974eec-ecfc-4ca2-b819-5d23006b9f36
4008	(Moving)	0	\N	3	1115	\N	a0cef3f8-ceb8-3be7-9797-7394d8add1a9
4009	Golden Star Portrait	0	\N	3	1115	\N	afc4ddc2-e4b3-4d1d-8318-4fc08a3170cd
4010	Reunion	0	\N	3	1115	\N	b17e87dc-d333-48ac-9529-9ecea79f4a1e
4011	Ten Years Together: The Best of Peter, Paul & Mary	0	\N	3	1115	\N	b34757fc-cf2e-44fb-9c4f-4f4eff161f7c
4012	See What Tomorrow Brings	0	\N	3	1115	\N	be09cc29-7930-4c3a-96a7-7f845b4dc1aa
4013	The Very Best of Peter, Paul and Mary	0	\N	3	1115	\N	c57f36f3-dc7c-4635-ab41-8d2ab0650c4f
4014	(Moving)	0	\N	3	1115	\N	cd25615e-4e14-4c78-b782-c94894cff1b5
4015	A Song Will Rise	0	\N	3	1115	\N	da016677-cdbd-3944-99b5-2e462837dbc5
4016	Ten Years Together: The Best of Peter, Paul & Mary	0	\N	3	1115	\N	e35830c6-ab80-4bbe-ad37-0892dc76e9be
4017	Album 1700	0	\N	3	1115	\N	e4f186ed-57f4-423d-8a95-7c4cd9972ffa
4018	In the Wind	0	\N	3	1115	\N	f073bbd5-b18b-48a3-81db-733b7056983b
4019	Such Is Love	0	\N	3	1115	\N	fc1c6c7d-9dc0-4bea-8f46-27c5a65c1d4e
4020	The Peter, Paul and Mary Album	0	\N	3	1115	\N	fd935d31-2d92-48d4-b7fc-8ab84dd7f28d
4021	Record No. 1	0	\N	3	1118	\N	11bf47fa-48cf-4978-9ad7-6d327ecbbfe1
4022	Flame	0	\N	3	1118	\N	3ac65b8c-d064-401f-b41d-c5e48baed6a9
4023	Greatest Hits	0	\N	3	1119	\N	02ccf30a-f244-449e-b2e0-ed9ad7e102be
4024	The Fabulous Les Paul & Mary Ford	0	\N	3	1119	\N	1de002c7-2beb-4be8-b98d-b945264971bb
4025	The Best of Les Paul and Mary Ford: The Capitol Years	0	\N	3	1119	\N	26d57bb6-808c-4341-83da-4b386bfb6312
4026	All-Time Greatest Hits	0	\N	3	1119	\N	2c589cf2-9c2a-491f-b949-5c42fe54ff9b
4027	16 Most Requested Songs	0	\N	3	1119	\N	2f8efffe-de1f-4102-a73a-404e29c118ec
4028	A Touch of Class	0	\N	3	1119	\N	41513ee9-afd7-4d23-aba1-dc099f8abc76
4029	Les Paul & Mary Ford	0	\N	3	1119	\N	572aeb5d-c231-4b4c-8d80-c1de43f9b9f3
4030	How High the Moon: Essential Collection	0	\N	3	1119	\N	5b229b20-654e-4737-a849-bc420203b15b
4031	The Very Best Of	0	\N	3	1119	\N	6bb8eccb-f927-4ee6-a34a-855f8dc1c678
4032	Bye Bye Blues!	0	\N	3	1119	\N	750bee3f-d290-4127-a1c3-2fcd49a97637
4033	24 Greatest Hits	0	\N	3	1119	\N	7be5c4e6-aca8-4709-bdfa-33334f16bf3e
4034	Hits of Les and Mary	0	\N	3	1119	\N	887ad447-1f22-45bc-9c50-c33beaf6f1b8
4035	The Greatest Hits of Les Paul and Mary Ford	0	\N	3	1119	\N	8c53d5f2-3883-4d62-8ed4-d4a2c3299f86
4036	Guitar Wizard (disc 2)	0	\N	3	1119	\N	930fb5b8-5de6-4725-9204-7e2d454f9bcc
4037	The Best of the Capitol Masters: 90th Birthday Edition	0	\N	3	1119	\N	9b8bc034-fac7-49b3-8fde-26dc0f46a384
4038	On the Jukebox...	0	\N	3	1119	\N	a6c3c07b-351b-43c3-a094-8a6dfe7837ce
4039	The World is Waiting for the Sunrise	0	\N	3	1119	\N	b13ab26f-2f90-4f68-8959-5c2302f0bbea
4040	The Hit Makers!	0	\N	3	1119	\N	b3371ff3-47f0-48db-9952-b426e9568fba
4041	Brazil	0	\N	3	1119	\N	bfd4a45b-12b0-4229-99f9-f2ad54ea0c4e
4042	The Best of the Capitol Masters	0	\N	3	1119	\N	e30827a2-0dd9-4aa4-8106-8aa4a92b0743
4043	Greatest Hits	0	\N	3	1119	\N	f532addd-cda0-455e-bbcb-2f30fe629435
4044	Best	0	\N	3	1119	\N	f6ee3ac6-7c91-4afb-8b2e-84ec0721801f
4045	Greatest Hits, Volume One	0	\N	3	1120	\N	211fa4cc-0624-4256-a8b4-4e9bb6f4960f
4046	Brother for Sale (50 Cents)	0	\N	3	1120	\N	35849b32-9430-4263-8ea2-6a344b03b744
4047	Greatest Hits, Volume 2	0	\N	3	1120	\N	51fbd58e-27ce-4bfc-916f-3f8f5b6dbd64
4048	Give Us a Mystery	0	\N	3	1120	\N	5df95d6f-a06d-488f-8bc9-c3b84d260b57
4049	I Am the Cute One	0	\N	3	1120	\N	7457a37c-8f68-48a3-b631-fa0c097d27f6
4050	Incredible	0	\N	3	1123	\N	0be1fd9c-0b1c-4ffc-b697-b3680a5b95d9
4051	Go Get It	0	\N	3	1123	\N	13c98d57-fc45-45f4-8f04-4599b0679357
4052	A Mary Mary Christmas	0	\N	3	1123	\N	1427a883-cb64-4427-a070-72a09218a18e
4053	Incredible	0	\N	3	1123	\N	3c485ef2-8d68-4e00-8916-16c49916f34e
4054	Incredible	0	\N	3	1123	\N	71dac09d-990b-4187-a47b-52c85db3b081
4055	The Sound	0	\N	3	1123	\N	916b84d5-aa60-462b-b3d1-00325ff863ed
4056	Mary Mary	0	\N	3	1123	\N	a2b380d8-c5b7-4a84-a89c-03ce77dbf399
4057	The Sound	0	\N	3	1123	\N	d70bde37-aa94-4af1-bbc3-503ddee4e0c3
4058	Something Big	0	\N	3	1123	\N	e4aee3d6-9e14-4c49-93cd-98868232ab5f
4059	Thankful	0	\N	3	1123	\N	e8ab0af6-ede4-476f-80d0-a2ecff307cf0
4060	Chain of Command	0	\N	3	1125	\N	9d558808-e509-4b09-97e2-8174b4e5a822
4061	Show's Over	0	\N	3	1126	\N	1144f70c-70e8-4f76-b3db-c6270926dad3
4062	Home	0	\N	3	1129	\N	e83173e8-fc27-4749-b763-a06c2712aa87
4063	Blue Skies Over Dundalk	0	\N	3	1132	\N	18316528-0ccc-4807-9d4b-135c8e0277ae
4064	Blue Skies Forever	0	\N	3	1132	\N	1db00b1c-a0f2-48db-91bc-ecdfc9553509
4065	2002-06-15: Ottobar, Baltimore, MD, USA	0	\N	3	1132	\N	7639e7bd-3eda-4ac5-bc20-262e43aab2c8
4066	Tell Your Friends	0	\N	3	1132	\N	95fb214f-7d05-49d7-af97-b16d8e4e3a76
4067	Lemonade Live	0	\N	3	1132	\N	a45f6fdd-3c08-4f3a-ad75-9246435ca2a0
4068	Roulette Girl	0	\N	3	1132	\N	b37370ad-08d8-4174-b499-49b6be8b685d
4069	Mary Butterworth	0	\N	3	1133	\N	4d11e546-f676-49d3-ae80-a2cdde7e0e9f
4070	Satan's Little Helpers	0	\N	3	1134	\N	0f14c68e-abb3-4060-83a7-b3ffadc9b10f
4071	Hammering on the Gates of Heaven	0	\N	3	1134	\N	1fee52e1-4d5d-4ee2-bf2c-d497e70cf865
4072	Wut + Zorn = Revolution	0	\N	3	1134	\N	43bee939-42a4-4bae-87af-54cc0e8d18cc
4073	King ov Salò	0	\N	3	1134	\N	79a76e43-dcda-4694-9364-262031e016d4
4074	Blood, Sweat and Tears	0	\N	3	1134	\N	9ad0ac6f-c0a0-4396-b0d6-19b7cffdf4fa
4075	Harmonic Tremors	0	\N	3	1135	\N	17ba0f3e-1ccb-4e91-9411-006fe2bd56f4
4076	Bird of Prey	0	\N	3	1135	\N	ed12a18a-b50b-4058-ae2f-e98eda9d1778
4077	Until Your Heart Stops	0	\N	3	1136	\N	00f1dea8-f5a0-4e80-93c0-455757824532
4078	Antenna Demos	0	\N	3	1136	\N	1784622a-28b6-4c33-9c9a-c70b797fafa7
4079	2003-07-31: Cleveland, OH, USA	0	\N	3	1136	\N	28a4c012-ba74-4106-b3fb-06ed4e5ce466
4080	Antenna	0	\N	3	1136	\N	29d455dc-f604-4de8-a4b6-d1f35a629c86
4081	Until Your Heart Stops	0	\N	3	1136	\N	2ac68e21-9bc8-4697-9362-170e61c238ab
4082	Antenna	0	\N	3	1136	\N	309326d4-b735-4036-a162-67abc3052233
4083	Perfect Pitch Black	0	\N	3	1136	\N	51b1325c-05de-45a5-b960-cab15807ba91
4084	Antenna	0	\N	3	1136	\N	6aab896d-69ff-4403-be07-10b02876a0ce
4085	White Silence	0	\N	3	1136	\N	80f724c9-5f1f-45e9-8fcc-730123ec27a5
4086	Jupiter	0	\N	3	1136	\N	84f521a4-ee77-418f-8ee8-21dd6c5d97a8
4087	Antenna	0	\N	3	1136	\N	952b3d5c-a8b2-410f-ba1e-f60cfe6ef4be
4088	Godcity Demos	0	\N	3	1136	\N	a26d75b0-1a27-45b9-a254-9188f2113cf1
4089	Beyond Hypothermia	0	\N	3	1136	\N	d6a747ff-7a68-4bc2-8c8b-805f9e771ca9
4090	2004-03-13: Cleveland, OH, USA	0	\N	3	1136	\N	d80b1254-be1a-4912-b3a6-baef4642fa9d
4091	Love Comes Close	0	\N	3	1138	\N	0c551770-8675-405e-b466-973badf4b402
4092	FACT Mix 97: Cold Cave	0	\N	3	1138	\N	1e4c643b-97dc-43fd-a2fc-89ee1229b72b
4093	Full Cold Moon	0	\N	3	1138	\N	32f18e91-92ac-4ca8-9b92-a9f2142f7519
4094	Love Comes Close	0	\N	3	1138	\N	46ba4661-8cf7-39ec-9661-cc1a93099f29
4095	Cremations	0	\N	3	1138	\N	7597489d-486e-48b4-beba-46397f29f85e
4096	Cherish the Light Years	0	\N	3	1138	\N	8ea747d3-d9ce-44a0-aa59-6fbd425e8a9a
4097	Cherish the Light Years	0	\N	3	1138	\N	903bf5a3-9236-3a82-99db-3c1ea286a129
4098	Cherish the Light Years	0	\N	3	1138	\N	aff997be-b047-48c5-acfe-9c0701ff755a
4099	Love Comes Close	0	\N	3	1138	\N	e3b0b5ce-b357-4ac5-8f48-c57e48055871
4100	Cherish the Light Years	0	\N	3	1138	\N	f5623ff9-ea0d-4685-ab22-f1a35bc42ba9
4101	Cave Country	0	\N	3	1139	\N	f8f29723-9931-4202-831d-b6ed390c0e58
4102	Fast Cars and Smoky Bars	0	\N	3	1142	\N	1f3465ac-5e8c-46dc-828f-738755d99596
4180	De-Jah-Voodoo	0	\N	3	1167	\N	b34c125a-dfa5-4594-bdf1-c4bcfbd07374
4103	Love Me Like Crazy	0	\N	3	1142	\N	3e37c584-7d9a-4a8e-bb81-307548c1d560
4104	Whiskey and the Devil	0	\N	3	1142	\N	c1e47279-00f8-4231-b170-c16c8360f6a2
4105	Naomi	0	\N	3	1143	\N	208d752a-a8a5-460a-91f1-f54f8179bc19
4106	No Witch	0	\N	3	1143	\N	5a161af4-ca08-4118-81b9-7b0e9c9ffd0e
4107	No Witch	0	\N	3	1143	\N	7667d44e-2d7c-48c7-bda0-ffc42035189f
4108	Naomi	0	\N	3	1143	\N	8153349f-37c6-4a38-b974-d6739e5e6755
4109	Welcome Joy	0	\N	3	1143	\N	b344ad9c-90e6-49f0-a9f8-fffe8484f3a8
4110	Invitation Songs	0	\N	3	1143	\N	d8f53d5b-0833-443b-a2df-5a33ce2022e0
4111	Psychic Psummer	0	\N	3	1146	\N	23def5c0-cb68-4178-a752-2348f6cdf733
4112	Threace	0	\N	3	1146	\N	6db52338-a9f5-4035-acb8-047521e0e624
4113	Neverendless	0	\N	3	1146	\N	92ce32c9-beb3-4fb9-9c13-6e53dca1b97c
4114	Hunt Like Devil/Jamz	0	\N	3	1146	\N	a1e381b4-a5ac-40a9-a61d-e901a5447b7f
4115	Lions Write History	0	\N	3	1148	\N	56620838-dbb8-4d07-86a3-6f670fc85038
4116	Learning to Accept Silence	0	\N	3	1148	\N	89a66b71-3d5d-439b-9dac-c6c4a9e030a6
4117	How to Make a Human Heart	0	\N	3	1148	\N	8e03c7c3-5554-4090-b6d3-0e707e6de236
4118	Violent Resignation: The Great American Teenage Suicide Rebellion 1992-1998	0	\N	3	1149	\N	5f53ab29-146e-44d6-bd66-0bf029c9b6e9
4119	Four Seasons of Grey	0	\N	3	1150	\N	82052138-5058-4248-b215-6437f93e4ab5
4120	The Curse of Decay	0	\N	3	1150	\N	84c5bbc1-9b7c-41e8-99e3-a66e8924be55
4121	Four Seasons of Grey	0	\N	3	1150	\N	e5fc216d-8e00-34c6-9c87-e5a121a0a2de
4122	Sailing the Seas of Forgetfulness	0	\N	3	1151	\N	c061076d-7060-46e3-aaf0-82cf55fe00dc
4123	Sounds Superb	0	\N	3	1153	\N	0a5e0c22-45e2-4640-8a44-557681395f9c
4124	Viola!	0	\N	3	1153	\N	1e8acfe1-498a-4cf7-917c-3e779076794c
4125	Wronger Than Anyone Else	0	\N	3	1153	\N	3744bdee-7070-4280-ba0d-83ad4f3ff09f
4126	Brash & Vulgar	0	\N	3	1153	\N	62681c7d-958c-4080-bc65-144ffe05a7ac
4127	Worse for Wear	0	\N	3	1153	\N	7cfe1347-fbe0-43e4-aebc-9b72a16a24c8
4128	FACT Mix 54: In Flagranti	0	\N	3	1153	\N	ae4e2928-ceee-45a8-b461-4d6ba1d3183e
4129	On That Note	0	\N	3	1154	\N	21011e54-ec09-43ab-b369-14e21a6fc51a
4130	No Gods No Masters	0	\N	3	1156	\N	8e338840-5f20-49f3-9d2d-1870249ada4c
4131	Victor Griffin's In-Graved	0	\N	3	1158	\N	9f3c3d85-53ba-42c9-9a49-2ec0f519284b
4132	Victor Griffin's In-Graved	0	\N	3	1158	\N	a7455052-b57f-4a80-9a4d-7de46d03c5eb
4133	Reciprocity	0	\N	3	1160	\N	811b59c6-5cf0-4e66-9547-ac21494afdbf
4134	Infinity	5	\N	5	1030	\N	
4135	Hello	10	2000-08-08	5	917	\N	
4136	Led Zeppelin III	0	\N	3	1161	\N	0914d44a-c33e-3d75-ad42-38bb710360e1
4137	Presence	0	\N	3	1161	\N	0c6e631d-4d64-3313-80d5-505eccbfbffa
4138	Physical Graffiti	0	\N	3	1161	\N	0d06025c-afff-49fd-a1db-8005e686e4d9
4139	[Led Zeppelin IV]	0	\N	3	1161	\N	1da28879-c832-4d8a-a227-06595d49b2c8
4140	Houses of the Holy	0	\N	3	1161	\N	3ccb4cb2-940a-4e2e-b1fd-4c0b7483280f
4141	Led Zeppelin	0	\N	3	1161	\N	3df3b60f-d6e1-3af9-913f-0014e73650ee
4142	Houses of the Holy	0	\N	3	1161	\N	564dba39-a5e2-4931-bba8-9e4cbf9db6e5
4143	Presence	0	\N	3	1161	\N	5c1032af-2d86-424b-963e-dd9e65f7281b
4144	Led Zeppelin	0	\N	3	1161	\N	6ad8bb9c-bddc-481e-846a-e0f2e20f1516
4145	[Led Zeppelin IV]	0	\N	3	1161	\N	71eafe5d-33b0-4e41-9b51-754b8450302e
4146	Led Zeppelin	0	\N	3	1161	\N	7214f50e-e7d6-4948-806a-024a00a1eda7
4147	Led Zeppelin III	0	\N	3	1161	\N	7aadcfa2-df82-480e-8d2d-7ec4d0b41172
4148	Led Zeppelin II	0	\N	3	1161	\N	87e8eaa5-2285-4fd5-b392-f0e8bad5b2f9
4149	Led Zeppelin II	0	\N	3	1161	\N	97e89db2-e0fe-3e49-8183-ec846c2892ce
4150	The Song Remains the Same	0	\N	3	1161	\N	99301bda-f462-41d3-ae27-658b57772dda
4151	Houses of the Holy	0	\N	3	1161	\N	9be882ef-ebdb-49be-a5cb-5e0021c05e37
4152	Led Zeppelin III	0	\N	3	1161	\N	a41da5c4-a6e0-3e73-87ce-25e6510ebdcf
4153	Led Zeppelin II	0	\N	3	1161	\N	c2ac2fe1-817d-4979-ad7b-40b3e880645c
4154	[Led Zeppelin IV]	0	\N	3	1161	\N	d204c2a6-665a-35ef-9b7c-799df194dea1
4155	Led Zeppelin II	0	\N	3	1161	\N	d7be0adc-dbcb-3a6c-878c-ddac4dc711f5
4156	Physical Graffiti	0	\N	3	1161	\N	e3f0f405-d50f-45a4-ba71-795e7333fb56
4157	Led Zeppelin	0	\N	3	1161	\N	e6ac555e-e831-32d7-8e0a-10d7cc187950
4158	Led Zeppelin III	0	\N	3	1161	\N	e6ec152f-2913-4598-8552-17fea3798730
4159	Led Zeppelin II	0	\N	3	1161	\N	e85b6f60-4293-3cf2-ba44-7f653d3887f1
4160	Led Zeppelin	0	\N	3	1161	\N	ed69765d-bb07-4775-bc02-d0376bd363b0
4161	Live 10/1-94	0	\N	3	1162	\N	2e49b9a3-0314-4e08-921f-59b939853091
4162	Live 10/1-94	0	\N	3	1162	\N	e57db4a3-b068-4790-8dfa-084a0e2e7b06
4163	Chicken and Ribs	0	\N	3	1167	\N	1511c9b4-0a15-483c-b2c6-78888b6782d9
4164	Un‐Led‐Ed	0	\N	3	1167	\N	1af72a88-4354-3caa-904e-6e904fa441bc
4165	It's Not Unusual	0	\N	3	1167	\N	22476c4b-2dc0-42c5-8a5d-641e0d461de1
4166	Hots On For Fresno	0	\N	3	1167	\N	2ef21c24-8898-471f-b501-d018918a3924
4167	Hot & Spicy Beanburger	0	\N	3	1167	\N	43d9a8dc-98cf-4377-9b33-6de29564852a
4168	Spam-Bake	0	\N	3	1167	\N	4bfa5687-cb03-49ab-bfdf-6b919ac23259
4169	Bar Coda	0	\N	3	1167	\N	571d1232-ba91-44f1-8a83-97598ac31389
4170	Ruins	0	\N	3	1167	\N	5f420cfc-19e7-4346-b0e1-6c1d6fb049bc
4171	Live at Larry's	0	\N	3	1167	\N	62e1dcff-8146-439b-832a-e1aeb0a6182a
4172	Dread Zeppelin Live	0	\N	3	1167	\N	6440564f-d470-4935-9525-5bcfbc9988aa
4173	Chicken and Ribs	0	\N	3	1167	\N	67a051d1-4344-4336-bd0c-03a4ceddec0a
4174	Presents	0	\N	3	1167	\N	76349835-4220-4ad1-82d4-af83136406f4
4175	Live: Front Yard Bar*B*Que	0	\N	3	1167	\N	85e967c8-4710-4f58-901d-e4937016a23b
4176	Re-Led-Ed: The Best of Dread Zeppelin	0	\N	3	1167	\N	8c675934-989c-43e1-aabb-91a821fd6df5
4177	Heartbreaker	0	\N	3	1167	\N	8cac9bb2-8cba-41f2-9335-b6b2542fb78d
4178	The Fun Sessions: Tortelvis Sings the Classics	0	\N	3	1167	\N	8dfdcb74-d0a2-4c95-a2f6-59e4a18974e1
4179	Un‐Led‐Ed	0	\N	3	1167	\N	b0b79978-f1c1-444f-b071-885be775450b
4181	Rock’n Roll	0	\N	3	1167	\N	b9ebe0d1-3f21-4f09-a190-08281904cfa3
4182	No Quarter Pounder	0	\N	3	1167	\N	c4d13a2f-e026-4fae-ac31-e902ec61006f
4183	Hot & Spicy Beanburger	0	\N	3	1167	\N	c680945d-a172-4b6b-ae7c-235922d96906
4184	The First No-Elvis	0	\N	3	1167	\N	ceb26905-e621-4a00-bc34-fd23dd51fe26
4185	The Song Remains Insane	0	\N	3	1167	\N	e5cb7212-9707-4011-9d83-99697a7d46d4
4186	5,000,000*	0	\N	3	1167	\N	f06c4dd0-d1f6-4db0-9a9f-257138ddf69f
4187	De-Jah-Voodoo	0	\N	3	1167	\N	fb0de4b1-8023-3cd7-839b-199bbdc72e29
4188	Lez Zeppelin	0	\N	3	1168	\N	996e560e-7e01-4266-90d7-68c3ed4aea66
4189	Dust on Common	0	\N	3	1170	\N	5b31a323-cfb4-4421-9435-596987a5a43e
4190	Dust on Common	0	\N	3	1170	\N	9a85a163-3a59-4cf9-a393-122cbf94c558
4191	Led Er Est / Ancien Régime	0	\N	3	1170	\N	cd9b8f00-ec3c-42da-810b-4ef6fb1fc96d
4192	The Diver	0	\N	3	1170	\N	e05d2589-d0b6-4838-bc86-2e36823ca15c
4193	American Derivative	0	\N	3	1173	\N	23720a94-e8cf-4251-9246-0cbdd8ef2c57
4194	8 days	0	\N	3	1175	\N	17567987-90b2-4aff-974b-2573d8e746e0
4195	2am	0	\N	3	1175	\N	47d8cc0e-f475-4492-b5e8-ff855e3dcf1f
4196	Last Evening's Dreams	0	\N	3	1175	\N	7d5044ba-3859-469f-ac22-dbc41436cb5c
4197	Denying the Inevitable	0	\N	3	1177	\N	ac22b7a7-f126-47d8-8957-60b51d07bc10
4198	In Ways Unforeseen	0	\N	3	1177	\N	afcc239d-3d80-41b6-b26f-b315ebc7bf7a
4199	Sizewell Tea	0	\N	3	1178	\N	06ce19f9-7201-4ade-aae6-0ec359bd8b8e
4200	The Good Egg	0	\N	3	1178	\N	0b6f6fbd-b50e-4b3c-a24a-97e33d2dc4a1
4201	The People In Your Neighbourhood	0	\N	3	1178	\N	4fb5b144-704e-463c-b781-071e611ab251
4202	Bring Your Own	0	\N	3	1178	\N	63fdd680-330b-40ee-8715-b8caf4be0fd6
4203	Sensible Shoes	0	\N	3	1178	\N	b0157e40-ef81-4909-b8d7-efb6d7820c23
4204	Arboretum	0	\N	3	1178	\N	ced47a08-83d8-433d-8f45-54cfd40b6c00
4205	The People in Your Neighbourhood	0	\N	3	1178	\N	cefae18d-b878-40c6-9e12-58297a6f003e
4206	Led the R Out	0	\N	3	1179	\N	7a3cb698-93a4-4308-9008-cdee1034a22b
4207	Led Zepagain 3: A Tribute to Led Zeppelin	0	\N	3	1180	\N	d7bda6ba-1a7b-4e14-9e26-291cd78401c5
4208	CODA	0	\N	3	1181	\N	30892847-b3e8-4e3f-bc32-962a3d94f80a
4209	Run To You	0	\N	3	1181	\N	a653da9b-5b29-49aa-93e7-5ca7ca599460
4210	Niga Mwonde	0	\N	3	1181	\N	c8a578cf-6419-4d2f-b68f-a0ace442ff30
4211	Logic Egoism Delete	0	\N	3	1181	\N	d77365cd-368e-4d43-b09c-2b8e6faa446b
4212	Bring It on Home Tour	0	\N	3	1184	\N	bf1b77aa-1e3d-4c3d-8838-4aec2771db73
4213	Led To The Grave	0	\N	3	1185	\N	51f32850-ed8a-4862-b696-4a8328df6e15
4214	Feast of Love	0	\N	3	1186	\N	66fcc5f0-fbd3-445d-9270-7fdd541ae618
4215	Launch Off to War	0	\N	3	1189	\N	2783c3ee-5786-491c-a411-c9de18326462
4216	Written in Blood	0	\N	3	1189	\N	e4ad7550-0cd3-4bcd-b97b-4b92a8cfe6cd
4217	Headed for a Breakdown	0	\N	3	1189	\N	f5a9e391-baf7-434e-9cd7-dc6c56e7a46f
4218	The Silent Majority	0	\N	3	1192	\N	81dff78c-5692-4e56-8eb0-3c0707e9bdf6
4219	Strum & Drum!	0	\N	3	1193	\N	a6b7218c-6b88-3d41-923b-241d73b3e997
4220	Strum & Drum!	0	\N	3	1193	\N	c60a18d3-acbd-4bff-9e5c-6ad21ac7d081
4221	Antedium	0	\N	3	1193	\N	f426cd3a-8ffd-4ad6-8eb0-7745d68e96d9
4222	NSFW	0	\N	3	1195	\N	30f9060a-f2e7-40c8-9723-7ac62efc07a8
4223	NSFW	0	\N	3	1195	\N	3e515f76-4d9f-40dd-ae81-e0a77e179900
4224	Strawberries and Cream	0	\N	3	1195	\N	4ffc4511-7b0c-4e65-a8d8-2a0f15e57789
4225	Attitude City	0	\N	3	1195	\N	848b7d0c-7429-47b6-af03-7e311a699daa
4226	Attitude City	0	\N	3	1195	\N	9bdfa2c6-76d8-407e-ab43-fff758aa0e70
4227	Strawberries and Cream	0	\N	3	1195	\N	d7f530e8-4c34-4b36-a924-f0157d319914
4228	I.	0	\N	3	1196	\N	216029b4-b83c-4dfa-bf96-5e85b825c4c5
4229	Naked Ladies and Bloody Skulls	0	\N	3	1197	\N	627042c6-8f65-4bd0-a6c5-706108d67246
4230	Fantasyland	0	\N	3	1199	\N	ae72e76c-4dcc-4479-a06c-a553b77af75a
4231	Israeli Wall	0	\N	3	1201	\N	90affa37-0c47-4739-9a46-735a8fd30614
4232	Neumann, Jussi, Pepe, Jippo	0	\N	3	1202	\N	9e1d939d-642a-4e61-8d17-9dfcc5486ac6
4233	Neumann, Jussi, Pepe, Jippo	0	\N	3	1202	\N	d5345704-8305-4511-89a7-00506e25f22b
4234	Never (A)part	0	\N	3	1203	\N	036d963e-8fe6-4f3c-97de-76f66f4a326d
4235	Waving Goodbye	0	\N	3	1205	\N	c6131670-9ca4-49e2-8650-060e3b4820e1
4236	LIKE CROWS ON THE SLAUGHTERHOUSE FENCE	0	\N	3	1206	\N	057c214f-4f14-47f5-aade-476113e8e9cf
4237	LIKE CROWS ON THE SLAUGHTERHOUSE FENCE	0	\N	3	1206	\N	1367fc85-1be4-4dc0-b876-01ce743f02ff
4238	SEX SEX SEX	0	\N	3	1206	\N	37680b8b-1d20-408c-8b5f-a2c3d8fc58eb
4239	924 North 25th Street	0	\N	3	1206	\N	6ce7a610-adef-4bb8-abc6-12f4e8b5ba61
4240	Chaos in Cancerland	0	\N	3	1206	\N	7569d30f-9de3-4d48-bffc-0b41e9c0ab3e
4241	Eerie Nights	0	\N	3	1206	\N	83e4d63d-e105-4b4b-9b3f-a1873fb9c1c7
4242	Freaks: We Who Are Not as Others!	0	\N	3	1206	\N	d2e32afd-f884-4aa2-95d6-8b53978e2158
4243	Never Mind the Bollocks Here’s the Sex Pistols	0	\N	3	1207	\N	11c6c574-6442-45f8-9c25-110675725f2f
4244	Never Mind the Bollocks Here’s the Sex Pistols	0	\N	3	1207	\N	155cc065-924f-3046-a73b-624e3311ce11
4245	Better Live Than Dead	0	\N	3	1207	\N	16064597-08dc-4bc1-9a03-07c45e312a36
4246	Never Mind the Bollocks Here’s the Sex Pistols	0	\N	3	1207	\N	19e7ecfa-145d-366d-80db-3b12452cccda
4247	The Original Pistols: Live	0	\N	3	1207	\N	24208ded-4569-48dd-8654-cf5e5daa9d42
4248	Never Mind the Bollocks Here’s the Sex Pistols	0	\N	3	1207	\N	270e7584-1754-3618-a884-e661f11c3f53
4249	Kill the Hippies (Live in Atlanta: 1978-01-05)	0	\N	3	1207	\N	29523134-4c50-4b2f-9a8e-0eee796fbcb1
4250	Never Mind the Bollocks Here’s the Sex Pistols	0	\N	3	1207	\N	312c8ae9-0b20-49aa-8eae-97f68ac427f0
4251	Never Mind the Bollocks Here’s the Sex Pistols	0	\N	3	1207	\N	329551ff-ffee-4cfc-b3cb-2a3c4d54a521
4252	The Great Rock ’n’ Roll Swindle	0	\N	3	1207	\N	34a96e6a-31ad-43c3-b60f-744d4ea1e49b
4253	Never Mind the Bollocks Here’s the Sex Pistols	0	\N	3	1207	\N	4ec2dea2-c4f4-3244-95bc-cf7feb80222c
4254	Flogging a Dead Horse	0	\N	3	1207	\N	6485ff04-f72e-3b7b-a837-ad0362a88593
4255	Spunk	0	\N	3	1207	\N	87258ea8-4562-4a81-bb97-357e8425b732
4256	The Great Rock ’n’ Roll Swindle	0	\N	3	1207	\N	8dd3f0b4-4e93-4c0c-8731-7c13af803ae4
4257	Never Mind the Bollocks Here’s the Sex Pistols	0	\N	3	1207	\N	8f8d5077-69d5-373a-98c3-db77706739e4
4258	The Original Pistols: Live	0	\N	3	1207	\N	9f87f13f-b7a1-4373-a4f7-6e66278c0ec0
4259	Indecent Exposure	0	\N	3	1207	\N	b591e5b2-945d-4707-b8c2-93c34786fb9f
4260	The Great Rock ’n’ Roll Swindle	0	\N	3	1207	\N	b8664235-0362-4911-98c1-e46316d7a391
4261	Sex Pack	0	\N	3	1207	\N	bab5e314-3964-4f34-b40f-cf23eacecfbe
4262	The Great Rock ’n’ Roll Swindle	0	\N	3	1207	\N	cd21fe62-8583-3aa7-894e-588c22cb3e27
4263	The Original Pistols Live	0	\N	3	1207	\N	cfd07a64-fefe-4367-b10e-8c7cfee8157d
4264	After the Storm	0	\N	3	1207	\N	d46a4e35-c190-494c-be7b-b2a5fe6b6fb7
4265	Better Live Than Dead	0	\N	3	1207	\N	e111c966-e0cd-48e5-b62b-6915d591029f
4266	Flogging a Dead Horse	0	\N	3	1207	\N	e7aef270-6c4e-40c0-949e-5c9464b7d8ca
4267	Spunk	0	\N	3	1207	\N	ed75bd6c-e736-4283-b390-591fc5f39693
4268	Sex Mob Does Bond	0	\N	3	1208	\N	19a8a3c9-6277-48a5-9e16-5daf50d764eb
4269	Theatre & Dance	0	\N	3	1208	\N	3122daa1-1bd4-4143-bbcf-ce04090a33e5
4270	Dime Grind Palace	0	\N	3	1208	\N	3fb40aba-fa85-4a00-99b9-db538f38ed45
4271	Sex Mob Meets Medeski - Live in Willisau	0	\N	3	1208	\N	6c5adab7-bcce-4f83-baeb-6ebb8680411e
4272	Sexotica	0	\N	3	1208	\N	ab584f4f-84a9-4014-86a4-06bea3041c00
4273	Solid Sender	0	\N	3	1208	\N	abdbae58-b378-46d7-aac8-54b941075cba
4274	Din of Inequity	0	\N	3	1208	\N	ee88c461-9078-4d99-b450-c74448f9b076
4275	The Essential	0	\N	3	1209	\N	1fe62cf9-2388-4fcb-9d9f-731ddadb2439
4276	Space Race	0	\N	3	1209	\N	3e8d81ac-4dc1-4e10-b678-b2bf74169017
4277	Shanghaied	0	\N	3	1209	\N	42d2c53a-f8ae-45a8-a0c2-3e7543afa8ec
4278	Where Do They Go?	0	\N	3	1209	\N	4a8acd56-c2ed-4da4-8359-18d36fb3eb85
4279	Shanghaied	0	\N	3	1209	\N	58ee7dd5-6663-498f-82a1-5c16b9b8d375
4280	Graffiti Crimes	0	\N	3	1209	\N	b8137a64-ab09-4b95-99b8-55736f0c2038
4281	Mi-Sex '79 - '85	0	\N	3	1209	\N	c252ace6-9cfe-4b13-9266-77459c2a9c1d
4282	Splintered Faith	0	\N	3	1210	\N	bc372a70-1b7c-488b-a19a-c8d9c5df31dd
4283	Whatever	10	2012-08-10	5	1212	\N	
\.


--
-- Name: recordstore_album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('recordstore_album_id_seq', 4283, true);


--
-- Data for Name: recordstore_albumreview; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY recordstore_albumreview (id, text, date_written, album_id, author_id) FROM stdin;
1	this is a really good album	2015-12-02 21:52:00.723142+00	1691	3
2	I know that I would buy it	2015-12-02 21:54:45.728961+00	1691	3
3	I love it	2015-12-03 04:07:08.41136+00	3553	10
\.


--
-- Name: recordstore_albumreview_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('recordstore_albumreview_id_seq', 3, true);


--
-- Data for Name: recordstore_artist; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY recordstore_artist (id, country, date_start, date_end, name, musicbrainz_id) FROM stdin;
442	US	\N	\N	This Will Destroy You	9512eed7-a1a9-4e2f-8cac-c10d1448c1ce
443	US	\N	\N	This Ship Will Sink	a8c9649c-5778-4fe1-9c96-2e5e1da948e7
444	US	\N	\N	Destroy	68a30713-d5d5-4b76-8a76-504584ff0a61
445	US	\N	\N	…And You Will Know Us by the Trail of Dead	9c1ff574-2ae4-4fea-881f-83293d0d5881
446	US	\N	\N	Destroy Destroy Destroy	ba27e20e-42f0-4f5c-be04-73572bbe041e
447		\N	\N	Man Will Destroy Himself	fc278511-5848-40d3-907d-fc565b670e1a
448	US	\N	\N	Destroy All Monsters	d2fdc048-fe7a-4d34-a5e8-fe2b65b140c5
449	US	\N	\N	Destroy the Runner	6e36dc4e-42a5-4b2f-a84d-a407e494c9a4
450	US	\N	\N	How to Destroy Angels	143b396d-a678-43aa-8c74-628fea8e381f
451	US	\N	\N	To Destroy a City	6f260893-4410-4297-b4e1-fec1bfbecb13
452	US	\N	\N	Destroy Rebuild Until God Shows	4a40140f-0e68-4ab0-9d6e-6e097957d85e
453	US	\N	\N	This Ascension	f0ab580c-1312-4021-a9c0-9b819acb6c7c
454	US	\N	\N	This Providence	f92671a4-1635-45b2-bc04-20d029a4cd49
455	US	\N	\N	Mambo This!	2c1646ea-c0d5-446f-a5f9-5f055a8c4fee
456	US	\N	\N	Enemy You	a9ce410e-38ac-434f-8f1f-58eea8d8efe4
457	US	\N	\N	Despise You	39d032fd-5830-41ec-8309-e54d264cd896
458	US	\N	\N	You+Me	a5593715-888e-43a7-84f9-a8ccd5e6b06d
459	IL	\N	\N	This Means You	bec28e85-6574-4f84-aa98-1f435d451e90
460	US	\N	\N	Will Haven	915d3d51-8a51-4864-a1f4-016bae819c7f
461	US	\N	\N	God's Will	ada898d6-305f-4922-a127-489942e48751
462	US	\N	\N	Ill Will	358914ce-b143-4881-8da9-1d72fc690a28
463		\N	\N	The Crazies Will Destroy You	702db6c2-3f32-4e75-8846-7745ee00c928
464		\N	\N	This Day Will Tell	535a9219-3e96-4f59-90cd-aef51ceb456c
465	US	\N	\N	This Busy Monster	2aa062a2-11ba-41ac-8021-8047fb156cef
466	US	\N	\N	This Runs Through	4835933f-831e-4800-b112-7e4a842d5a87
467	US	\N	\N	Isis	5e521e8c-0ab2-44c4-8fd8-14d8d3321265
468	US	\N	\N	Isis	a892235b-2acc-446f-9f2e-0370c920310c
469		\N	\N	Isis	8987df8e-227f-4139-9b1f-b138866bdc0f
470		\N	\N	Isis Project	fb03640c-db64-41d1-bb04-1a013b38a48e
471		\N	\N	Isis	995a32e1-b1a6-4836-8abc-953c8b2f5094
472		\N	\N	Isis	9405c80f-f85b-4a8a-86f5-d9e357951307
473	FR	\N	\N	Isis	c206b66e-f9aa-458d-8d2f-979533fea5d8
474		\N	\N	Isis	0d2399bd-5526-4590-a09b-aa1e35bfd4f9
475		\N	\N	100% Isis	4bacc310-4035-404f-9560-b0f45208597d
476		\N	\N	Isis Regina	ab51630f-95f8-4f1d-9e31-3a3c027effad
477		\N	\N	2 Isis	f8520ab8-413e-4d89-947c-9e7a6a776595
478		\N	\N	Isis Montero	468036c9-c453-4e8f-bbef-dddfca7495a4
479	MX	\N	\N	Isis Signum	d0f950f6-2b22-40cb-ab17-3555a4836383
480		\N	\N	Isis Gee	bfd5672d-7bf9-447c-b287-21ef07b8c7b6
481	CA	\N	\N	Isis Salam	9cc26bb6-cb31-4bda-aa0f-44b485c99f17
482		\N	\N	Empire Isis	1122517d-c3fc-4a9b-a536-c30a7c83ad59
483		\N	\N	Isis Moreira	ce05f5f0-3425-4a5d-a503-1c4d020ac69d
484		\N	\N	Isis Figaro	2a1d0cf9-7ac7-4207-89e8-86cfdce1f1aa
485		\N	\N	Isis van der Wel	31499383-1410-4f64-ac72-c28937ad269c
486	CA	\N	\N	Omalola Isis Salami	08dff3ff-371e-4bc2-8143-3f9fd28a04aa
487		\N	\N	C Isis Rain	a158a97a-1d4e-4024-ab55-166188dbbca7
488	DE	\N	\N	Prisca Isis Gerstung	b06b3b37-b784-4760-a92b-3ce13dec2059
489	US	\N	\N	Pailhead	9714bcae-da69-4189-84a3-6e226802eddb
490	US	\N	\N	Gamma	59b83484-0935-47f3-a0ee-91cecc2ab361
491	US	\N	\N	X-Cops	e7556297-8018-497e-a379-b3a538198aed
492	US	\N	\N	Mutoid Man	d6c8e477-7221-47be-bab3-fe6980cf4284
493		\N	\N	Mutoïd	d555e7c4-dd63-476b-ae29-2190dd6bee5d
494	US	\N	\N	Man Man	4e210d41-b3e3-4e34-8c3b-3b8cc2116562
495	US	\N	\N	Man or Astro‐Man?	28c5d97f-4321-4ef4-8ac2-d9d93b0eb16c
496	US	\N	\N	Automatic Man	c5ad7668-2ed8-4a6b-b4d8-c7e4242b2805
497	US	\N	\N	Minimal Man	058557db-95f2-4871-97cc-a080f0f3e48b
498	US	\N	\N	Marginal Man	fff14e91-ae03-4105-8fbb-3a318d6c01ca
499	US	\N	\N	Expanding Man	e49b2d00-3106-4d2c-950b-b7d2c96eef22
500	US	\N	\N	No Man	693584f4-c93d-4fd7-9497-be81b356bdc1
501	US	\N	\N	Iron Man	ec74050c-f96b-490a-af4d-3b541434d69d
502	US	\N	\N	Yawning Man	075ded80-c694-4157-9a97-4d42ca8b9e8e
503	US	\N	\N	Early Man	1d401a56-bc0a-4e64-bb07-fbd0ccb34c88
504	US	\N	\N	Old Man	78d13fa1-1567-4ccd-9a2d-37ebe212fc47
505	US	\N	\N	Man Factory	367d49bb-0754-44db-bbf3-c153fdd4e352
506	US	\N	\N	Man Overboard	a79173ba-00f4-4e6e-8af2-ba964f52b6b7
507	US	\N	\N	Mountain Man	ecc6e248-9ec4-4150-bbd2-d2b112f0b365
508	US	\N	\N	Modern Man	481eb125-aa3e-4b66-88c2-5211b818e8da
509	US	\N	\N	Illustrated Man	6d136760-871a-485f-bb11-6545462d44e5
510	US	\N	\N	Old Man	26a34b93-2501-487c-a8ab-3a5f4f192d8f
511	US	\N	\N	The Day of Man as Man	6e1dca84-6161-4e25-b30e-69c6e5a65012
512	US	\N	\N	Two Man Advantage	2855dc78-1c4c-4aab-9f41-7fbead28a5ff
513	US	\N	\N	Blue Man Group	dbcec54d-49c8-4d61-8512-8025bb37bf8e
514	US	\N	\N	Method Man & Redman	c03e2388-9e1b-4b78-8194-28c0d6ca19a0
515	US	\N	\N	One Man Army	6f9937e2-11a3-40f5-a607-3750584685c9
516	US	\N	\N	Man Is the Bastard	b59a4797-4292-49a4-a21c-8f43c61f6bb8
517	US	\N	\N	Bob Dylan	72c536dc-7137-4477-a521-567eeb840fa8
518	US	\N	\N	Bob	5b782ca9-8970-475a-8d9d-e20ff593e0b2
519	US	\N	\N	The Dylan Group	158dfb95-57e2-45e3-9407-b7ab4477ce25
520	US	\N	\N	Dylan in the Movies	6f7c2195-a5f2-4ef2-b1ed-90276216169f
521	US	\N	\N	Dylan Sires & Neighbors	b613ba3a-2244-4804-927d-6b9356284253
522	US	\N	\N	Dylan	27b547e3-b2c9-4d2c-9dce-a3b44c484a0d
523	US	\N	\N	Nob Dylan and His Nobsoletes	ddbb4984-58a4-4aad-9316-2ab2c3b2a2f7
524	US	\N	\N	Bob Evans	84052a3a-cd74-4b63-b2b0-e7181e986339
525	US	\N	\N	Bob & Tom	8d5fdbfb-7544-4d58-bfb3-e8545063f5c5
526	US	\N	\N	Bob & Earl	03c051c5-d424-419f-8cce-1d9f7aa12175
527	US	\N	\N	Bob James Trio	9536a0bc-15f1-4bf7-8005-19102bdd4b67
528	US	\N	\N	The Bob Seger System	c96237ac-9319-4cd7-83eb-a2c14e819c6c
529	US	\N	\N	Bob Mintzer Big Band	31dd2e79-9c86-42b7-96e4-0769f5eb65a5
530	US	\N	\N	Not Bob Marley	ba59f607-1bf2-41be-9d3c-2f430e301e0b
531	US	\N	\N	Bob Florence Trio	63824ff7-3f1b-4481-892b-d183d5ad3193
532	US	\N	\N	The Bob Crewe Generation	fe2dd395-210e-4a5d-a331-15948ac52e93
533	US	\N	\N	Bob Brookmeyer Quartet	f5e3c0af-5bef-4ded-99f0-69a224f603d4
534	US	\N	\N	Bob Scobey’s Frisco Band	43636496-b975-410a-8f3b-254ea232ef5d
535	US	\N	\N	Bob Mould Band	c9f49f27-95ec-47e9-a1d7-983612f451ad
536	US	\N	\N	Bob & The Rockbillies	367a4ff1-2679-4de1-bb34-ae968428d961
537	US	\N	\N	Bob & Ray	a4c26d19-7e89-49df-a311-f08baea8d554
538	US	\N	\N	Bob Kendall Band	35f4f28d-e20f-4e3e-805e-399c1a3a4ee8
539	US	\N	\N	Bob Helm's Riverside Roustabouts	8fc2e2ce-5e04-40b9-b8a3-beab1192cc10
540	US	\N	\N	Bob Ogden & Orchestra	df6a0bbe-93fe-4cd5-baf5-d8533ecefcc7
541	US	\N	\N	Bob & Lisa	b2bcb09a-4c0a-4894-929a-02416c3d5f80
542	US	\N	\N	B.B. King	dcb03ce3-67a5-4eb3-b2d1-2a12d93a38f3
543		\N	\N	B.B. King & His Orchestra	53e74442-a01c-4e74-8bbd-13b023d45b0b
544	US	\N	\N	KING	ad4b792d-82df-43ea-8083-1d12f483de5e
545	US	\N	\N	The BB Band	9b659b00-8b4b-4e61-be98-8ad265a2e18e
546	US	\N	\N	The B.B. & Q. Band	bccb9298-9df6-452e-9d95-6b9ace543a95
547		\N	\N	B.B.	6333cea8-f934-4143-bfa4-b5593e23c8b5
548	ZA	\N	\N	B.B	8f31ead7-af61-40aa-af42-06b1b2adcbd0
549	US	\N	\N	Acid King	1fc5d8e8-240c-4c0e-85b5-d5a2650a362c
550	US	\N	\N	Citizen King	81350c04-b8cf-46b7-9a8f-b3b749d8c166
551	US	\N	\N	King Radio	6463b8cc-7337-4864-b60c-ead08d41ae63
552	US	\N	\N	King Missile	62881dc4-2776-4743-a938-79a7d865ea53
553	US	\N	\N	Lustre King	dda371fd-319b-4827-8b2f-df5efc303c29
554	US	\N	\N	King Kobra	bd4e0318-8792-4301-b70b-23e9f8e7917f
555	US	\N	\N	King Harvest	3e6e3015-5f02-4068-a44c-728dc9fe218b
556	US	\N	\N	King Kong	fd95f811-981e-4802-a712-f023fc4197fb
557	US	\N	\N	King Changó	c4e7d839-abd4-4936-a192-f3bc3097ff33
558	US	\N	\N	King-Size	f9e9c78d-3121-4a2d-b868-bf2dbe4eae1c
559	US	\N	\N	King James	b2248dd8-d4e2-4fad-8aea-3b1b73a480ba
560	US	\N	\N	King Fantastic	93628342-c236-4b2d-a0ce-cd9df3c886ad
561	US	\N	\N	Sky King	2c6cc64e-cc57-430d-a044-f26021abda23
562	US	\N	\N	Rude King	bd439851-3d60-4779-b1ab-44e4d7743fba
563	US	\N	\N	King Sparrow	eee9fe5c-f14d-4f17-ad64-1179e867fe16
564	US	\N	\N	King Mob	a80a99ba-81e9-4682-b382-9091e2d94e28
565	US	\N	\N	King Comets	9ac1b7be-36a8-497e-8aa4-94576dd614a5
566	US	\N	\N	KING 810	977673cb-c160-4a8c-81e0-b2dad6b0192f
567		\N	\N	Elvis	03f1cac5-7179-4588-a94f-f1527e99947b
568	US	\N	\N	Elvis Perkins in Dearland	c1857ec7-94b1-43dc-8cc2-0c9d265cd8c1
569	US	\N	\N	Elvis Presley	01809552-4f87-45b0-afff-2c6f0730a3be
570	US	\N	\N	Elvis Ramone	6ca00925-25d3-4aab-8e8f-21e88ef2a5f1
571	US	\N	\N	Elvis Perkins	ca2f9ff7-c53d-4b8b-a687-a5001ce5fcf6
572	US	\N	\N	Elvis Phương	bccfcba8-a996-4c8e-a51a-75e61b484b6a
573	US	\N	\N	Elvis Lederer	582cc36b-675b-467b-aff9-70abf518aba8
574	US	\N	\N	Elvis Depressedly	531f2c87-9442-4c89-843c-56313dc58ed7
575	SI	\N	\N	Elvis Jackson	01e89006-693a-43c8-8d23-207a46a76043
576		\N	\N	Elvis Hitler	663765ff-c8f7-42eb-93d0-1fe698732ca1
577	GB	\N	\N	Tiny Elvis	c9f93eea-f5c3-4cf5-abc0-d22218294274
578		\N	\N	Elvis McMan	3db968e1-3a1a-4361-86b3-f7f825e9b220
579	SE	\N	\N	Kjell Elvis	52369448-96eb-4f0a-9847-fe88399d5d99
580		\N	\N	Chasing Elvis	4736fe66-03f8-4e58-947a-c8fee51e9685
581		\N	\N	Velvet Elvis	e162c23a-2c18-4c98-af6e-b56672d4f22e
582		\N	\N	Elvis Deluxe	22b0afd8-8991-48f5-ad28-8d2def89e1b8
583		\N	\N	Elvis Caligula	4fb9ae9e-1d8a-4737-b9eb-6450339d7cf6
584	DE	\N	\N	Mexican Elvis	51b706d3-6560-4911-bffe-22a0d3201cfa
585	FR	\N	\N	Double Elvis	3cae7ae6-7c53-4504-8e34-eac94eecd182
586		\N	\N	Dead Elvis	2b6a91f4-7d6b-4552-97eb-43d5107d48ff
587	JP	\N	\N	ELVIS JUNKIES	bb21555a-a2b1-4744-9d6c-8088298a9e73
588	FR	\N	\N	Radio Elvis	3e9928ed-a765-4271-aa69-f62ac2becf7f
589	GB	\N	\N	Elvis Fontenot	85118033-0ad0-4fc4-9a17-0fa7c7b5b220
590		\N	\N	Radar Elvis	a5de505a-75a2-4d77-be0a-914d90c69503
591	US	\N	\N	Nine Inch Elvis	f49d1e93-2919-456c-a30a-041906fa0574
592	US	\N	\N	Blue Sabbath Black Cheer	77e75365-6c78-4769-9cfc-656d1c5497ed
593	GB	\N	\N	Black Sabbath	5182c1d9-c7d2-4dad-afa0-ccfeada921a8
594		\N	\N	Black Metal Sabbath	b3bfe6f0-2cbf-492c-ae90-fcd62c203435
595	US	\N	\N	Sabbath Assembly	57fd7983-ad98-4aa2-9319-6b2ee8281c50
596		\N	\N	Crack Sabbath	6a82a640-fe91-4649-bb11-42b74063ef4e
597		\N	\N	Sabbath Crow	c28d9843-0a77-48d2-9b88-0865abb19866
598		\N	\N	Witches' Sabbath	dd6b9208-44a5-427f-bd0b-a46778e73ff1
599		\N	\N	Sabbath Folk	94733086-f0e0-4e48-8af3-72d04053dfff
600		\N	\N	Brown Sabbath	4451bb2f-4542-4774-a698-aa30ba976e79
601	US	\N	\N	Big Black	9463868f-edc8-427e-ac07-ea89698e5f15
602	US	\N	\N	Black Flag	9941a936-196a-4a62-ae53-a69cbc33f20e
603	US	\N	\N	Black Sheep	63034f55-692a-4f3b-a19a-ac2072eac3bb
604	US	\N	\N	Black Moon	7057a0c4-481f-48c8-9c64-28d8400539ea
605	US	\N	\N	Black 47	355ac0da-ab94-48c2-badd-41f3986041cd
606	US	\N	\N	Black Lab	6977ec07-9d54-4151-b5ef-f4697afc9aee
607	US	\N	\N	Black Star	02708fd6-0fe6-4738-a27d-0561ace8b4c6
608	US	\N	\N	Black Flies	492885cc-9c88-497a-b455-12f90a1bfcfd
609	US	\N	\N	Black Magic	5062ff5e-524b-4778-9b82-2c674d6ed550
610	US	\N	\N	Black Atmosphere	202d2193-9a5e-45e9-b9b2-3e252c703af9
611	US	\N	\N	Black Earth	ceb7954e-05cc-4993-9d06-8c015304363d
612	US	\N	\N	Black Symphony	e0ba7cd0-e2ea-45a1-bb72-a6ffce1a5738
613	US	\N	\N	Black Tambourine	8cf2cf86-fb95-4a93-be6b-37d98d3df506
614	US	\N	\N	Black Widows	2ab09500-2850-4b1f-b1c4-1f8fdb62305e
615	US	\N	\N	Black Heat	5a9af251-cec7-4e58-b2ce-7d8547bce526
616	US	\N	\N	Black Nasa	0b64a48e-290d-4a25-a1a3-d4e984f665e2
617	US	\N	\N	Fugazi	233fc3f3-6de2-465c-985e-e721dbabbace
618	US	\N	\N	The Captain Howdy	6b377dd3-2935-46a6-ac1c-c218fe9ec8f1
619	US	\N	\N	Gabardine	05c673e9-eba4-40f5-add0-8ee6fbb3d859
620	US	\N	\N	Platypus	b79ac6e4-c486-40d7-bf83-432e818fc212
621	US	\N	\N	Omen	596cc676-32c7-480c-9bf4-dcc9d8ff62d3
622	US	\N	\N	Icon	8bfab3c4-7dea-4203-8408-9bffab4bc1f1
623	US	\N	\N	Hagfish	532b2b4d-e271-44f9-970e-dc2e1225f1a0
624	US	\N	\N	Young & Restless	f343b0bc-d08f-499d-8ac1-33c9a83dd404
625	US	\N	\N	Bare Necessities	75ca91b6-e46b-42e9-92ee-c9afcd403840
626	US	\N	\N	68 Comeback	00077d46-7b4a-4761-9eed-c7dd435fa5ff
627	US	\N	\N	Chamberlain	17de431b-7958-4d0f-b33f-ea538ebc5aef
628	US	\N	\N	Solas	ae389557-f85b-4954-88f2-7b542db07ff8
629	US	\N	\N	Gridlock	83d8c079-a39a-42b1-af6e-4a202b8e6ab3
630	US	\N	\N	The Centurions	441b8d20-8f8e-4d02-985e-b0e69936b7b7
631	US	\N	\N	Mississippi Sheiks	159f73c7-74f3-40d9-8937-ee90fdae4d67
632	US	\N	\N	Jelly Roll Kings	d86c3c8b-84d5-44ce-80fa-7cfc537fe5c1
633	US	\N	\N	The Louie Bellson Quartet	c7d999eb-7bfb-4f7e-9bd7-e676dbb7db28
634	US	\N	\N	Waterdeep	61c6657a-1c5a-4f73-859a-390a164d6eeb
635	US	\N	\N	Thorr's Hammer	31c2d9e6-5f45-4b4e-9af1-aa46bbe3d4f9
636	US	\N	\N	Maynard Ferguson & Big Bop Nouveau	a5ef049f-e7c6-43eb-a76d-b4c25457dbf3
637	US	\N	\N	Chemlab	608732e8-d168-4270-8c96-a9cd1ef3667c
638	US	\N	\N	The Voluptuous Horror of Karen Black	d1f6fbbc-3058-419b-a55c-49852bdf3740
639	US	\N	\N	Minor Threat	09037f07-42bc-46ac-a1ee-37f834451fee
640	US	\N	\N	Death Threat	10bc16b4-567d-4bb0-b455-3ad0db178975
641	US	\N	\N	Suburban Threat	db0a81d8-d910-4aaf-8f55-842ada066e3b
642	US	\N	\N	Triple Threat	9df7fe47-d093-486c-9dd9-6b08e40d55ae
643	US	\N	\N	Triple Threat	637014b3-7b58-40d4-a3dd-a7829c2d3170
644	US	\N	\N	Vicious Threat	763ca236-f7da-4d92-b9f2-9fe9875846d1
645	US	\N	\N	Off Minor	9fdb0aba-13a6-42bc-8953-d4035b1f3cfc
646	US	\N	\N	American Minor	f20884a1-84f4-455e-8065-16e4e3e265ee
647	US	\N	\N	Fort Minor	e1564e98-978b-4947-8698-f6fd6f8b0181
648	US	\N	\N	A Global Threat	c073f75f-e99b-4584-b954-d5488d87b970
649	US	\N	\N	Proletarian Art Threat	21466799-5ecb-491b-9aec-577c0e01070f
650	US	\N	\N	The Minor Leagues	3a6a4c2b-ae20-4719-9f51-9cf22f242c34
651	US	\N	\N	A Minor Swoon	4be5f89e-0405-4d19-8b37-0eabe388c3a1
652	US	\N	\N	The Minor Three	bc1c0ee2-d54a-4239-ad36-43fce89c2e6d
653	BR	\N	\N	Threat	e2e2b2f2-f02e-4ad7-9d6e-2e6a842a3ea5
654	IE	\N	\N	Threat	55e59f48-5320-4f4c-8db0-9aeb260aa593
655	US	\N	\N	Damion Suomi & The Minor Prophets	131155d2-6427-4636-99fd-b3c9596c50a7
656	US	\N	\N	Deep Threat	84000c31-83f1-4917-aa1e-5c0e7344d7e7
657	US	\N	\N	Politikal Threat	089fc8e9-a692-4b21-b835-b55c63208a57
658	US	\N	\N	Shane Minor	05415ca9-43de-4c71-9d14-a993f8cc0542
659	US	\N	\N	Dan Minor	b4203c1a-5295-44cf-8fdc-11dae5f2b1f9
660	US	\N	\N	Rickey Minor	ec6ed49a-e6a0-49bc-b345-913a9427cd4a
661	US	\N	\N	Derek Minor	b2e73cf7-9093-4d50-b3ab-7195ca52b4d2
662	US	\N	\N	Aria Minor	baecda0d-a9a9-41a6-a769-049bf1f7a4bf
663	US	\N	\N	James Minor	74b561f4-a332-4d2c-bb9f-9e2b9ac6fff2
664	US	\N	\N	Converge	fa31e7d4-a03a-4110-98fc-f8826e95ec25
665	US	\N	\N	'68	c2a7fb29-eb0d-4ecc-82da-24f94af0c6da
666		\N	\N	Sunday 68	37817169-c521-4986-94fe-fc47fd08785f
667		\N	\N	Reverso 68	58b1cec8-eb9d-48b7-b35d-eb68eb25edf8
668	AR	\N	\N	Satelite 68	f2bfc30f-533d-42af-99c4-4557e99aa8d8
669		\N	\N	Rosita & Club 68	ae870be4-6b3c-45c7-9530-388246cdb9d0
670		\N	\N	Brian Setzer '68 Comeback Special	3e749477-88aa-42e2-b510-d4153d77278e
671		\N	\N	68 Beats	5a8f9050-3831-457b-b987-c3b8610a8931
672		\N	\N	Jet 68	708264c7-20dc-4207-8c09-11d884a1b8dc
673		\N	\N	Galaxy 68	6d7e88ec-978b-4574-bf36-56fb948b81f2
674		\N	\N	Nate 68	04e02df1-cee0-4782-81ef-6959c0e6f01e
675		\N	\N	Prototype 68	f953fb3a-e7e0-4963-82e3-46880c3ab2c2
676	GB	\N	\N	Freefall 68	a160d7ef-e5e2-4e31-b3cd-2c59b24af2f1
677		\N	\N	Jo 68	c7660877-84d6-43f3-a24c-18f16a9d4bc7
678		\N	\N	Interface 68	b50f5c8a-788a-4618-be52-7c9dc81a64c7
679		\N	\N	I Nuovi '68	e80344a1-ff04-4c8c-b61f-34cffad3e612
680		\N	\N	Experimental Polen #68	08f5296a-0397-4d9e-b6a7-b6822d69d27e
681		\N	\N	Crash Site 68	9aa5b94b-4066-475e-bdb2-29ae0bc72817
682		\N	\N	Sons of '68	80725513-34e4-45d1-8107-b47541766402
683		\N	\N	68 Lost Souls	7190914e-6665-4bbd-a917-9293c19ddac5
684		\N	\N	The Studio 68!	cfe1bab3-35b3-4b60-977e-62c6bfa9dd96
685	US	\N	\N	Old Man Gloom	75a97901-0051-4b67-a79b-9ebf2400d1d9
686	US	\N	\N	Old Man Markley	d2b2f4f2-da5e-4fd7-9a34-23b33a5f9b17
687	US	\N	\N	Old Man Smithers	fa5c1967-c6fb-42fe-80bd-975740d004c6
688	US	\N	\N	Old Man	ed17f92c-635b-4e01-8a9f-112256b31a8b
689	US	\N	\N	O.L.D.	2a7e17f0-dc67-4902-ad4b-20bd986e847b
690	SK	\N	\N	Gloom	beddcf5f-be56-449c-bbb0-2eea740ef1c0
691	RU	\N	\N	Gloom	0b22443e-d2c9-4083-a97a-9c96d1bc4e9d
692		\N	\N	Trembling Old Man	2244faae-af6e-4b54-b521-14bfbf82668d
693		\N	\N	Old Man Savage	1461979d-adc3-48ef-929f-490919a1f401
694	JP	\N	\N	Old Man Bondage Machine	5baae738-a97d-431e-997a-fc4f783d1005
695		\N	\N	Old Man Canyon	617c99cc-2a8d-4310-9b0d-688a851bb2bd
696		\N	\N	Old Man Wizard	7e4ab498-efcd-487b-936a-b1cd325df1cb
697		\N	\N	Day Old Man	f63ebd63-cf03-4935-9ce9-3d07f225e578
698		\N	\N	Old Man Lizard	16bfe676-3626-4412-8bdf-a4d08a6a25e0
699	US	\N	\N	Old 97's	8dd216da-6db2-4130-9a7c-ece756d1394d
700	US	\N	\N	Old Canes	fa3dc077-336d-47e2-b8e5-57043586de02
701	US	\N	\N	Old Dogs	6ed2f24c-f205-4add-8477-aa000934c073
702	US	\N	\N	Old One	08ddbaa5-09e4-4ae1-9fce-e78b1e52bd3c
703	US	\N	\N	Old Gray	ddae9a60-a349-4f05-a75c-51240ae31ab6
704	US	\N	\N	Old Soul	12e6ea8d-fb28-42ee-8a1b-b0bc627b1b00
705	US	\N	\N	Old Shoe	f71258fa-9352-4b6a-8b1d-2ea9dc4103a4
706	US	\N	\N	Old Tapes	5c623964-78ce-464d-b630-8b20f50ceb9d
707	US	\N	\N	Citizen Fear	6752a790-2f67-4610-9c72-a08018c38484
708	US	\N	\N	Hello Citizen	bf0ada8c-bb13-4f0d-bdb8-a1017da3fa22
709	IT	\N	\N	Citizen	7ef9f451-fe57-40c3-b82d-af9a42a81ff4
710		\N	\N	Citizen	4c239bf4-964c-4a0b-a220-81c989ca84e2
711		\N	\N	Citizen	bd743cdc-74a1-4669-bcf9-3942594dc09a
712	US	\N	\N	Standard Issue Citizen	4ab74585-7e9c-497b-8b7c-04a2ebac5fc4
713	US	\N	\N	Citizen Cope	9b21f670-8359-4e11-be1d-bf75b649a719
714	US	\N	\N	Darryl Citizen	6a7394cd-cac3-4716-945c-27823c129ed5
715	GB	\N	\N	Citizen Fish	5752ebdf-9a18-4935-84ee-03c613d7bf5a
716		\N	\N	Model Citizen	44976003-5f9a-42d1-8c01-39c2ca9c74d3
717	NZ	\N	\N	Citizen Band	6425f5dd-2dc1-4367-a874-659204b0bc78
718	CA	\N	\N	Citizen Kane	c12e900e-d88f-474d-8417-a366c2e49132
719		\N	\N	Citizen 020	760c097f-b00c-49d7-8e55-d265043c7cc8
720		\N	\N	Misled Citizen	e868c839-3f05-488f-ab1d-16ee385d48c7
721		\N	\N	Citizen Kain	4e13ae38-6777-45c7-9581-5c8f07d1507d
722		\N	\N	Citizen Art	9b3d9f98-a25e-42e0-8610-f66de2572cf8
723		\N	\N	Citizen Kane	d1d3a93b-e809-404c-8983-3496f4b88d7d
724		\N	\N	Citizen Crane	f5c68b5e-48a1-4d05-aec6-8e70f2a4917c
725		\N	\N	Global Citizen	581193b8-39f8-4b3f-af08-218b08dcb64a
726	DK	\N	\N	Rocket Citizen	d6891b99-9e7e-4ab9-9b83-c4ce1f6adccd
727	GB	\N	\N	#1 Citizen	337d4131-404c-49d9-b1e8-ce74180b5f08
728		\N	\N	Citizen Smile	2cd0f48d-5273-4121-9268-98fac27a520a
729		\N	\N	Electric Citizen	f0e56cc2-3a42-4d20-a0c4-1f83e7f56e70
730		\N	\N	Citizen Way	f04ab832-cdd5-47d5-9d69-3dfdc0ac7eb3
731	US	\N	\N	Blues Brothers	7252abc2-dfc8-4aa6-889f-2d168b265403
732	US	\N	\N	Blues	50224f53-32f7-455a-a1da-234e8c2cb121
733		\N	\N	Burton Brothers Blues Band	8739c279-0915-4ad7-9019-1288b6515c9e
734		\N	\N	Mungos Brothers Blues Band	e180389d-6f2f-427d-beb4-ed1cf409c53f
735		\N	\N	The Blues Brothers Band	fcd7aa10-eb1d-4486-8d54-7a734969ce90
736		\N	\N	The Blues Brothers Horns	662cc9c5-1a95-4a7e-8a22-0314eb5d7615
737		\N	\N	Myers Brothers Blues Band	9770b49c-cbcf-4003-93b8-565da8b49957
738	DE	\N	\N	The Blues Brothers Revival Band	34a4dfca-206f-4fb2-b669-b2f40c158eea
739	US	\N	\N	Blues Traveler	6b28ecf0-94e6-48bb-aa2a-5ede325b675b
740	US	\N	\N	Blues Magoos	9f066e90-a04e-447e-a878-01d8a1bb4bea
741	US	\N	\N	African Blues	1f614bcd-3646-40a9-b5f7-63717dda7c5c
742	US	\N	\N	Blues Image	316a2ab2-1863-472a-b9d7-223b2d07a6d0
743	US	\N	\N	American Blues	5292129e-42e9-4cf3-9e03-7026166a8c4d
744	US	\N	\N	Blues Dragon	32993e57-62e9-42c3-8e25-c4a91e28f501
745	US	\N	\N	RX Blues	076efb96-d86b-4159-9791-18876cdbb44d
746	US	\N	\N	Jungle Brothers	ce3bc975-a76f-415b-a6cd-1e568c5714dd
747	US	\N	\N	Waco Brothers	b4322fe8-a43e-40a0-9728-52d6ee873bc8
748	US	\N	\N	Pernice Brothers	48b83db5-1aa2-48d3-8f5c-8cc1d585e585
749	US	\N	\N	Analog Brothers	083a9e9d-35d1-48bf-82f4-41974b49e13c
750	US	\N	\N	Brother’s Keeper	adc6b217-c618-4f65-83c5-fb914ad68b85
751	US	\N	\N	Soledad Brothers	db9fbcdb-8585-4a18-97bf-42ceaa37b3d4
752	US	\N	\N	Wooldridge Brothers	f2cc480d-825d-48a9-9b3d-ea2829e12e74
753	US	\N	\N	Just Brothers	6bdf0a27-f456-45d4-94a9-3a63493c5c8a
754	US	\N	\N	Brothers' Vibe	c2857df9-3805-4c1c-934b-b4653364a503
755	US	\N	\N	Burden Brothers	32c8836f-28ee-4d71-9c7c-7146e5928a9b
756	SE	\N	\N	Cult of Luna	d347406f-839d-4423-9a28-188939282afa
757	US	\N	\N	Luna	dda04604-b50a-4bd1-8780-77564c659dc0
758	US	\N	\N	Cloud Cult	a33a9cd6-8c03-4047-b62d-59f76f494c20
759	US	\N	\N	Cult Heroes	5d079457-b1ef-48d7-9f8b-44d18447ef9b
760	US	\N	\N	Ex-Cult	b897c806-0cc8-462a-83d7-94a09d7cd700
761	US	\N	\N	Cult Leader	ecb76a4e-8863-4b4c-a512-bf58c8c845dd
762	US	\N	\N	Dead Cult	207b0693-ee8d-4553-9445-f380b422e313
763	US	\N	\N	Luna Halo	f177da51-bde7-4561-9f05-b924c4952919
764	US	\N	\N	Stella Luna	2359da8d-0573-4b73-98de-713de4589c89
765	US	\N	\N	Luna Mortis	3d64a173-e417-464f-b6c9-dec8ed3420cc
766	US	\N	\N	Blue Öyster Cult	c7423e0c-ab3e-4ab4-be10-cdff5a9d3062
767	US	\N	\N	Cult to Follow	75664b30-41bf-435b-adb1-c2fcf23239f2
768	US	\N	\N	Raw Oyster Cult	fc7280e8-64f2-48c7-bfe0-979196374b96
769	US	\N	\N	Lisa Lisa & Cult Jam	504456e7-65c3-4088-9e63-e2bf04fa1ed4
770		\N	\N	Cult of Sirius	8207ce1b-bb5d-4b9c-9816-690bfa12674d
771		\N	\N	Cult of Sue Todd	613d7b0d-6840-43ac-861a-13b023dbc4f1
772		\N	\N	Cult of Erinyes	dcccef69-3e0f-445b-b3bb-ed9dbb333b74
773	GB	\N	\N	Cult of Dom Keller	31eacacc-d2b5-439f-8018-840bbce9c3c1
774		\N	\N	Cult of Youth	955e56a8-cdce-4c03-85d5-6a07c8f46e6e
775	NZ	\N	\N	Cult of The Cobra	7312238c-4685-4a24-9281-4bc94da7cf0e
776	FR	\N	\N	Cult of Occult	7a7c60b3-9226-4fef-ac36-2cc698353119
777	SE	\N	\N	Cult of The Fox	9d1fd8ac-5d77-486c-9f58-61bef3d8992a
778		\N	\N	Cult of Herodias	41c97972-d1b7-4438-a11e-830787e82f12
779		\N	\N	Cult of Hatred	fcb1b54c-6728-4c18-80ae-e00cbbde2632
780	CZ	\N	\N	Cult of Fire	74de256e-0dd5-4edc-abc1-ab587bec3a6e
781	US	\N	\N	Monastic Choir of Our Lady of Clear Creek Abbey	b3b5afd8-6114-4bdd-85f9-f3a2ca6ee085
782	CA	\N	\N	Our Lady Peace	78661da3-894c-4947-a34b-fb7edf585d9b
783		\N	\N	Our Lady of Bells	479f4eac-8b30-4cce-874f-f62fb2b2ca64
784	US	\N	\N	Lady	cdfab5f8-d7a8-43df-be26-8ef4b9784b2f
785		\N	\N	Our Lady of the Highway	414f01f7-b152-481a-9481-59bd22e64352
786	US	\N	\N	Magic Lady	20e0d051-5cb1-44be-a56d-859368a6736b
787	US	\N	\N	Lady Antebellum	0eedfc95-e79a-4fd9-832a-cd816a0b3fda
788	US	\N	\N	Lady Flash	64e7a98e-744c-4171-8a2e-59ce33058dea
789	US	\N	\N	Lady Danville	0bc35a08-3e0c-408c-8c0a-9380e5bfee09
790	US	\N	\N	Lady Luck	411e75bb-679a-4a8e-b01a-3df98d2f7326
791	US	\N	\N	Mean Lady	8c6341b3-14af-4a2b-bfe0-53ca386ea2b6
792	US	\N	\N	Lady Sinatra	df2e7273-b391-4dc9-a8b1-180b9a4222e1
793	US	\N	\N	Lady Sabre	d844898a-c52f-42d8-a9c5-3ec512f459b8
794	US	\N	\N	Our Daughter’s Wedding	8015bb00-a3ae-40de-ade8-712cdba27df0
795	US	\N	\N	Spanky & Our Gang	022ab2c8-39b6-4a1f-9f85-90206e91ca3c
796	US	\N	\N	Our Last Night	5466b02a-4465-4e87-b372-584cd5f97bff
797	US	\N	\N	Our Brother the Native	c4143d9c-4d4f-48ee-8dbc-db43293f6964
798	US	\N	\N	Save Our Souls	2860b9b0-9cd9-4db8-a135-846f2385f8ab
799	US	\N	\N	Guide Our Ships	9bd23488-c19d-4bbd-aa23-ff3ded3f9548
800	US	\N	\N	Our Imperfect Future	0448320b-686f-4963-93c0-ceb883edd6f6
801	US	\N	\N	Hooray for Our Side	37651bdc-c682-4e05-8da8-fd334dab8f6c
802	US	\N	\N	Our Last Day on Earth	be6bd001-bf1f-41fa-a499-d38031964fcc
803	US	\N	\N	Naked Lady Wrestlers	595e9702-068c-4ec2-a33b-24b277f54837
804	US	\N	\N	First Lady Assassins	ca8c38b7-cce6-4422-a66a-d18665f1bb3a
805	US	\N	\N	The Lady Crooners	524bbac0-aa0f-487b-91c6-f67418d23e23
806		\N	\N	So Long Forgotten	0a400a09-7d99-4c34-8dcf-01952f03c066
807	US	\N	\N	Long Since Forgotten	be34bae7-cf2d-45ba-a017-21578c97aa27
808		\N	\N	Long So Long	77694daf-ac27-49d7-8c0c-b564be3813fa
809	US	\N	\N	The Forgotten	9f057ded-0612-4f92-b838-5a3632769457
810		\N	\N	So Long Davey!	7dad4cda-7766-4023-a22a-3dca9abf1269
811		\N	\N	So Long Superman	b54ed415-3cc3-492b-901c-b86fcbeab0e4
812	IT	\N	\N	So Long, Astoria	13c8acf6-852b-4e54-a5c1-d27a4b6a3e81
813	US	\N	\N	The So So Glos	9b4c57ed-b318-44b5-ab50-fb9a3e3fcd25
814	US	\N	\N	So Plush	33802f54-fc08-4d30-9268-fe17de194e43
815	US	\N	\N	So Percussion	60212905-02a1-4b05-a09b-c12dc85c50e7
816	US	\N	\N	So-Sakryfycial	de553a8e-0a8d-42b3-8ad0-71fca3dd10e3
817	US	\N	\N	So Crazy	13ade3d8-cda3-47d4-b474-438e1dc60072
818	US	\N	\N	Long Beard	6a4044aa-4705-4ecb-9bc0-6a7d892813a5
819	US	\N	\N	Dreams So Real	6c89335d-202c-4ed3-9073-6c891d55c2e5
820	US	\N	\N	The Story So Far	bc303c9e-3ffb-49ca-acf1-088ef4d46ed7
821	US	\N	\N	Farmer Not So John	56699f9c-2b02-4c4a-b777-816274727037
822	US	\N	\N	Yall So Stupid	dcd2e89a-fe86-4dce-8d4b-0c49ec688d4a
823	US	\N	\N	So They Say	eae25f00-28a9-4b2b-b6fa-af47d9668b58
824	US	\N	\N	So Many Dynamos	edd1ccee-f8cf-47bd-be0d-a1b6c9258f86
825	US	\N	\N	So Hideous, My Love...	87581022-a7b7-4ea2-a653-1b76b8323f73
826	US	\N	\N	So Much Closer	80c9b05e-0e38-430c-96d9-f20c4b5b4c97
827	US	\N	\N	Long Beach Dub Allstars	c7a2ba91-4efd-4ac5-b5ae-d2c238dbfb88
828	US	\N	\N	Long Winters' Stare	ce2913a2-8333-443a-a901-3e56f3a9f27f
829	US	\N	\N	The Long Ryders	c26ba79c-dedc-4eae-b42f-1a68ddc3c104
830	US	\N	\N	The Long Winters	966bd819-2ba1-4e1b-9d35-72385937e8ed
831	US	\N	\N	Cash Cash	dda162b4-f871-4e89-b081-b7b3470782f0
832	US	\N	\N	Cash Registers	8ae4e014-e09a-460c-b575-d19d1c2cb088
833	US	\N	\N	Cash	278b3f66-3668-4add-b429-2cd96bc91696
834	US	\N	\N	Cash	dc822f27-fc13-4a57-8a84-1ef2c9e31646
835	DE	\N	\N	C.A.S.H.	df4e6df1-e5cf-4a2d-896c-794f85ddc189
836	US	\N	\N	Cash Money Millionaires	e7457d77-aebe-4347-8f53-a4ad2c653c31
837	US	\N	\N	Lo-Cash Ninjas	35c85f53-c815-4057-86c9-aff31a494ab6
838	US	\N	\N	Cash for an 8-Ball	0ea83ef8-e986-48dd-98d7-381b5be3c906
839	US	\N	\N	Church Of Cash	08bbbb95-77a3-4e8f-96a9-b80b40a11d21
840	US	\N	\N	Bastard Sons of Johnny Cash	42ae45dd-a580-4643-a410-aa78c24d2ae1
841	US	\N	\N	Johnny Cash	d43d12a1-2dc9-4257-a2fd-0a3bb1081b86
842	US	\N	\N	Rosanne Cash	5ff6f6eb-31ad-4903-a3c3-4c9283fcde8b
843	US	\N	\N	Alvin Cash	f21dbc9d-585f-4f86-b73b-be13e17e4a7c
844	US	\N	\N	Steve Cash	068ee867-250a-4d6f-9880-38c297c68245
845	US	\N	\N	Cash McCall	e1de5a47-6797-489f-a978-3fca2c72690c
846	US	\N	\N	Tommy Cash	d8c5c228-0dff-4236-beae-3e2982714a72
847	US	\N	\N	Laura Cash	9e3795f0-9505-4454-adaa-0a9b42aabf68
848	US	\N	\N	Ray Cash	fc830370-6786-4340-8252-04a83b336a18
849	US	\N	\N	Fred Cash	bda7c516-2368-4e7f-b26b-28941fee872b
850	US	\N	\N	Brent Cash	b64fbe17-a07d-4164-80dc-13a7bc8611f8
851	US	\N	\N	Rob Cash	c0b04f96-45cc-4924-8975-59efd915dfc6
852	US	\N	\N	Young Cash	d4263e51-c7e8-4767-bc57-f173d8a3a8dc
853	US	\N	\N	Cash Seyffert	6c87b381-c2dc-4b0a-a850-7a82acd17ba3
854	US	\N	\N	Harlems Cash	75ad0aaf-b64a-4bd7-a0bd-5754ad6bc115
855	US	\N	\N	Yayo Cash	86af0081-be34-409a-be68-bb5cc7cb0ff7
856	US	\N	\N	Z	959ec8f7-7cc3-4a43-a278-f54a2c98b109
857	US	\N	\N	Z-Lot-Z	51e317b4-2df8-4990-9dc1-2fda55def609
858	US	\N	\N	D.B.'z	c8c82cbe-b723-43ea-8eef-ff1ae2055790
859	US	\N	\N	Rachel Z Trio	cdcf790d-67ca-41c5-a421-6396864cff96
860	DE	\N	\N	-Z-	549b9093-5ae0-49aa-8b44-a0fc64c0e3fe
861		\N	\N	Z	e7cf2f55-30c1-4522-ab4e-1f33d7999b80
862	US	\N	\N	Rob Base & DJ E‐Z Rock	6f191c70-1345-4ea5-b7af-5db9ee50d7c0
863	US	\N	\N	JAY Z	f82bcf78-5b69-4622-a5ef-73800768d9ac
864	US	\N	\N	Z‐Trip	03f93de6-6d62-4710-bcc7-9b3d7c3d95f5
865	US	\N	\N	Jimmy Z	631f5467-bf41-46d7-867e-4e61b8665662
866	US	\N	\N	Milo Z	9879f587-15c9-4840-883d-10b69e7ab476
867	US	\N	\N	Roy Z	7f2519d8-a09d-45f2-8210-d6e44093a722
868	US	\N	\N	Z-Ro	36cf5c5e-14fb-42c0-a232-56bd449a81df
869	US	\N	\N	Pamela Z	cb8cdd2b-a93b-459d-9c17-e8d61eb8ce23
870	US	\N	\N	Z Berg	74386eb0-97c2-4e2a-9423-26dce57bb639
871	US	\N	\N	Bobby Z.	cf9f1d20-e7c1-4680-8892-3f5936611024
872	US	\N	\N	Rachel Z	d9abe50d-8f48-4dae-98ae-d39be294152e
873	US	\N	\N	David Z.	23b8e336-72ae-4749-91ee-24337f690c31
874	US	\N	\N	Laurie Z.	d55d0a63-2b43-4dd7-b472-763324a777e4
875	US	\N	\N	Z-Man	8971e1cd-71ba-4435-8469-a8b02e01a14c
876	US	\N	\N	Z-Factor	0baadd78-183a-4ea2-9615-4d9f747ddabb
877	US	\N	\N	Benjamin Z	aea3e374-6826-4261-9ac8-aaa2957dbb6c
878	US	\N	\N	Andy Z	04ace22a-93ee-4d88-a338-6a3d30829513
879	US	\N	\N	Q-Z	3d1fcb47-4e68-43d7-a784-825e0cbbf4aa
880	PL	\N	\N	.Z:E:Z:B.	3cd5a52f-d3dc-4b98-800e-daf9cb91e35b
881	US	\N	\N	Ramones	d6ed7887-a401-47a8-893c-34b967444d26
882		\N	\N	Noise Ramones	ab0cc657-17d0-4df6-a75b-7c4289227781
883	DE	\N	\N	Hamburg Ramönes	1cdad224-5766-43cb-8a8d-23376211d9ba
884	SG	\N	\N	The Misfit Ramones	95567aff-7d24-430d-9dbe-4336f956abcc
885		\N	\N	Marky Ramones Blitzkrieg	a67184a3-4dbe-456c-b358-09b3d28e6aeb
886		\N	\N	Los Ramones de Nuevo León	fcde327f-c714-47dd-abc2-486213e011cc
887		\N	\N	Yokosuka Ramones	8bf5d705-eee7-4003-86f8-a26d012a7e24
888		\N	\N	Constantino Ramones	e17abe03-2835-47b1-a143-71073d8fa978
889		\N	\N	Kesha Ealy	5caabfd1-006f-47da-a6dc-db9429a0d8dd
890		\N	\N	Tenei Kesha	5efa8476-39c6-4677-9bb0-0610e9b703f4
891		\N	\N	Kesha J.	da99124d-776b-46b3-a27d-d624d621e6ee
892		\N	\N	Kesha D. Smith	add83faf-5b0f-467c-96fd-23218ac553b2
893	US	\N	\N	Nine Inch Nails	b7ffd2af-418f-4be2-bdd1-22f8b48613da
894	US	\N	\N	Nails	a7d9c5f6-751d-4ea5-bf6d-39f1751d44a1
895	US	\N	\N	Inch	9bf06cba-b933-46a8-886b-534d66b668c6
896		\N	\N	Nine Inch Richards	409aff05-c871-4893-9487-465fb157430c
897	US	\N	\N	The Nails	d55deff8-24e7-4b52-bd66-4460147c85ab
898	US	\N	\N	Bent Nails	68cd17f6-e7ad-4cf3-8a9d-6e0497e7a17c
899	US	\N	\N	Braced for Nails	b6f465c8-beae-4564-b8bb-7d6cf5faf8b6
900	US	\N	\N	12 Inch Rulers	e248191f-65c9-47f6-8783-6edb1d080b50
901	US	\N	\N	Ten Inch Men	0c2dc682-cb8c-4ea9-9940-c3d3bc7f5325
902	US	\N	\N	Nine Days	c30dfb44-768a-487b-af9c-c942682aa023
903	US	\N	\N	Virus Nine	5fab212b-03f6-4382-ab06-bae40fc46aa5
904	US	\N	\N	Mariner Nine	6cca1789-7e70-4b5c-93b1-4def96bcb764
905	US	\N	\N	I Nine	950ae76f-1c46-4192-b10d-ef5a37939743
906	US	\N	\N	Nine Lives	c482915d-4883-4578-9402-9e36598a0dda
907	US	\N	\N	Cloud Nine	8894309d-8d81-450d-8a5b-694a47f9079f
908	US	\N	\N	Lee Press-On and The Nails	d82ea0ed-9b54-42d3-8767-83b973dd4c23
909	US	\N	\N	Buck-O-Nine	be00eda8-a3ef-45ac-b70a-de21bcd61562
910	US	\N	\N	Nine Pound Hammer	ebfda26f-8625-4b2b-9f03-d53e08eb3ce8
911	US	\N	\N	Armstrongs Secret Nine	638719d8-2788-4591-8ab7-5bc7e7c63dd7
912	US	\N	\N	Nine False Suns	04c18691-60f0-4417-8e81-b400f1853b0a
913	US	\N	\N	Nine Left Dead	cfb04c87-c2f7-4fa9-a49a-872f48ca1ebe
914	US	\N	\N	Five by Nine	94316eb1-16cb-453f-87af-b560f56ef121
915	US	\N	\N	Metronome All-Star Nine	a70a6944-1c14-4127-a109-f0f49803d2d0
916	US	\N	\N	Thirty-Nine Thieves	61174c1f-744e-4b36-8720-922d0c28f527
917		\N	\N	Bill Nye	00b262c5-295f-4704-9d51-264a67bf39c6
918	US	\N	\N	Suspect Bill	6cac5183-4b1f-4fc0-8c05-fd19885f9e0e
919	US	\N	\N	Critical Bill	4a0b7ff1-dc4a-4f7e-8c79-799b6b68d399
920	DK	\N	\N	Mick Nye	b1d52601-0c0a-4e94-a62d-8265d4377a4a
921	US	\N	\N	Bill Evans Trio	d0630a08-3b40-4cb4-9f48-7d525262c1f6
922	US	\N	\N	Bill Charlap Trio	8586b4ce-49e8-42a5-80b6-0d4429f99850
923	US	\N	\N	The Bill Frisell Band	36f68d99-7c09-4ba6-898b-8f1b42022fed
924	US	\N	\N	Bill Black’s Combo	8d172aa0-5b30-415c-9014-40fa04a493ce
925	US	\N	\N	Big Bill and Thomps	7379d310-18ee-4068-b026-5b7d1ac1d9a8
926	US	\N	\N	Sons of Bill	19b709ff-5a73-4fe5-98d2-47147ffc4541
927	US	\N	\N	Bill Grogan's Goat	635e8374-3290-4d0c-b66d-17401563de0f
928	US	\N	\N	Bill Normal Experience	b53c3e4d-8feb-43dc-814d-c0c42b419197
929	US	\N	\N	Bill Harris and Friends	5de8825e-6732-4e75-85b9-e6bafc8430aa
930	US	\N	\N	Bill Haley's Comets	f0568af6-d6d0-4122-a62c-9daff9b430b1
931	US	\N	\N	Bill Mike Band	f9f2d511-c20c-40ad-b381-e097dd8e63b4
932	US	\N	\N	Douglas Kramer Nye	b90bac3a-bc21-42f8-bb3e-c1ccf418852d
933	US	\N	\N	Captain Pearl R. Nye	eaa0b084-acea-4eb6-935f-04f4758038d2
934	US	\N	\N	John Christopher Nye	ef2fc245-b464-445f-a513-eef13a75440f
935	US	\N	\N	The Bill Elliott Swing Orchestra	29d2d9af-da9f-42b5-b945-161d6fb4cb05
936	US	\N	\N	Bill Haley & His Comets	4458d70d-c215-4f06-beea-ebd448dad6ac
937	US	\N	\N	Bill Deal & The Rhondels	f44434ff-e70d-46df-8241-8409dce4059b
938	US	\N	\N	Bill Monroe and The Bluegrass Boys	624db6ea-1afb-4a3c-8092-5acfd2cb4a33
939	US	\N	\N	Bill Pinkney and The Original Drifters	a91b8182-4ec8-4ab9-984e-5cc31bb75a07
940	US	\N	\N	Bill Allen & The Back Beats	6fd67fd2-d4c5-4d2a-80dd-8063ab0f4609
941	US	\N	\N	'Wild' Bill Taylor and The Clefs	2739af19-6b8f-454c-9bd2-024a9aa0dd61
942	IE	\N	\N	My Bloody Valentine	8ca01f46-53ac-4af2-8516-55a909c0905e
943	US	\N	\N	Bloody Crackdown	07a84bec-ae16-4ea4-9661-cdc5dcb10b55
944	US	\N	\N	Bloody Sods	942e2926-00d5-4923-92bf-fb7925ae91d0
945	US	\N	\N	Bloody Phoenix	c7c915c4-31e2-4a49-a73e-4bbf4661800e
946	US	\N	\N	Bloody Knives	8eaf31fc-1bb0-4c6a-bb7a-c0b482db532b
947	US	\N	\N	Bloody Hammers	9e1c4182-b5a8-4c99-ad9a-ae3b183aad93
948	GB	\N	\N	Bullet for My Valentine	d530dbf9-69b1-404f-98f2-0431104f5a1e
949		\N	\N	Bullet for My Bloody Valentine	a64c35ac-4c06-434f-982a-c563e2eafd05
950	US	\N	\N	Dark Valentine	0796f9eb-a64f-4441-8827-ff10ac9ba3d8
951	US	\N	\N	The Bloody Hollies	d6c22fc7-f693-480e-b72b-8ad3a1373196
952	US	\N	\N	Bloody Mess & Hate	a868824c-8674-4c18-8f91-ca06e5abf975
953	US	\N	\N	Bloody Mannequin Orchestra	0fff1834-c23b-448b-8595-92fa143456e7
954	US	\N	\N	Screaming Bloody Marys	9557de00-8486-4a94-a210-3f8288ab06b8
955	US	\N	\N	The Bloody Angle	ec2b4944-3023-48de-af50-d635ef0ec0cc
956	US	\N	\N	The Bloody Muffs	da6eeade-63f9-458b-b765-0794a71f743e
957	US	\N	\N	Twelve Gauge Valentine	6a5d3381-eea3-4c73-a235-7de297272333
958	US	\N	\N	Bloody Mess and the Skabs	4f9865d9-6899-4a18-bfc1-0ca5863c9afd
959	US	\N	\N	Charlie Brown Gets a Valentine	69365bd7-948e-4658-a886-3e2c2a1d64d7
960	US	\N	\N	My Superhero	9ebbd112-a8ae-48e6-be0f-731573454e46
961	US	\N	\N	My Head	6cff49ef-8612-4605-9942-42cb68082a87
962	US	\N	\N	My Favorite	7bf37602-f8fb-4218-95ee-222a158cf1cb
963	US	\N	\N	My Education	c1c3686a-f22f-4729-815d-ad2bd3d0170a
964	US	\N	\N	My Baby	c3d11b9e-bb64-493d-ab03-4465dd2ae967
965	US	\N	\N	My Friends	4481f34c-3f57-42bc-b185-5a53420b995d
966	US	\N	\N	My Jerusalem	e94c0da0-358a-4403-b374-359c91d47ce7
967	GB	\N	\N	Ride	3f575ecd-627d-4f08-a89f-abd46d469c7e
968	US	\N	\N	McBride & The Ride	693948d2-3751-4378-8161-1c0f1eb9057b
969	US	\N	\N	Appalachian Death Ride	1dba07aa-3ede-4602-8fe3-8a687c9805bc
970	US	\N	\N	XXX Car Ride	5bda5d13-4769-4bba-acd2-064b28ccb164
971	US	\N	\N	Bizarre Ride Live	4187540a-7434-4436-8965-b8112fc63860
972	US	\N	\N	White Knuckle Ride	35ca9cce-7f53-4f7b-8e18-7b45f5aea6df
973		\N	\N	T-Ride	6d614ca7-cbb1-4ff5-bf55-a73110fce8a1
974		\N	\N	Elephant Ride	6ca6b772-37ae-40d0-8a69-b86cabcdce4b
975		\N	\N	The Ride	868b35ec-8b7d-4b17-998b-1fe594b9a338
976	FI	\N	\N	Plain Ride	6ee2bdf6-b521-405f-a550-001384b1d4fb
977		\N	\N	Blind Ride	b7892854-b8a9-4344-815f-4b4d1d546471
978		\N	\N	Coastland Ride	ed96310e-44a0-4936-adb0-731bd6195414
979		\N	\N	Heavy Ride	39b17ea5-76be-46a1-925c-821971232007
980		\N	\N	Motorcycle Ride	394206b4-f0b8-40e5-b194-9153909f1bb2
981		\N	\N	Ride Inc.	b73a671b-1e87-4edd-8872-f20d22b6c417
982	EE	\N	\N	Ld-Ride	09d68fe3-8a7f-446f-9ce5-6bd0c9f2bde6
983		\N	\N	Camel Ride	d660aeaa-3af4-42b8-8eee-7f217bf69912
984		\N	\N	Low Ride	17f3513b-6970-4a0c-97db-6aa97e32179b
985	GB	\N	\N	Ride On	c46841d1-d8c2-4a3d-8840-820a33426b31
986		\N	\N	We Ride	48de446a-a441-449a-a103-623feefeefc3
987		\N	\N	Last Ride	5438b632-f29a-49ab-8e07-4c7f04518636
988		\N	\N	Bullet Ride	1060f6bd-d41f-4c94-b2c1-4b55f9142a06
989		\N	\N	Late Ride	a8ef3176-d8ec-4640-ad25-548e0ad4a60c
990		\N	\N	Death Ride 69	fa613572-f9db-4ee1-bd20-825289047dc8
991		\N	\N	Five Minute Ride	e73d4198-1b32-4e84-9f1a-7829f7524d63
992	GB	\N	\N	Slabdragger	7727fe8c-78a1-49c8-8986-ae1e9732f9d8
993	GB	\N	\N	Slowdive	a16371b9-7d36-497a-a9d4-42b0a0440c5e
994	US	\N	\N	Oasis	ecf9f3a3-35e9-4c58-acaa-e707fba45060
995	GB	\N	\N	Oasis	39ab1aed-75e0-4140-bd47-540276886b60
996	GB	\N	\N	Oasis	a7a848c3-515d-4486-9e69-dc7491dd3bd1
997		\N	\N	Punica Oasis	72ec62c9-9905-4755-b2ac-7d8358a465b3
998		\N	\N	Oasis UK	f051c547-262d-4331-be04-08736e053138
999		\N	\N	Jonathan Foster & Oasis Praise	2eb26faa-a770-4ea7-a875-7b5e1b92ff52
1000		\N	\N	DJ Oasis	1ffd8812-f108-4fe5-89b8-3540803e16b0
1001		\N	\N	Bass Oasis	71e29549-95ef-4d60-98ed-3562aaebfcc1
1002		\N	\N	Soul Oasis	3abf3aad-d26f-421b-9ca8-f72af9082a7b
1003		\N	\N	Godfather Oasis	425497ba-244c-42e0-86db-e468e2b0dfb4
1004		\N	\N	Oasis Praise	6f926b8b-cefa-4997-b271-8757e44f72ac
1005		\N	\N	Oasis Osmosis	0470fcce-7728-4e8f-9874-413bf79195ac
1006		\N	\N	Jungle Oasis Inc.	4984da5d-6b83-4b67-b3c8-f435ae256dca
1007		\N	\N	OASIS RISING SOUND	4ac273c2-3f7b-424f-9c60-011d36d05da4
1008	US	\N	\N	REO Speedwagon	bdc70372-7e8a-4cb9-8d33-f036b3b7cdc1
1009	AR	\N	\N	Reo	c93bc8e2-efa1-4163-9485-ed262acd801f
1010	US	\N	\N	David Reo	32978173-5f32-4a42-8e26-0eef21c867e6
1011		\N	\N	Reo Voodoo	3b24d0aa-cd7c-49b5-95b6-23932daad887
1012		\N	\N	REO Speedealer	603896e0-dc0b-4ea4-aef8-539737c6a6ec
1013		\N	\N	Diamond Reo	f8b5dec0-01aa-4854-88ec-f96446acd33f
1014	LV	\N	\N	REO sieviešu vokālais ansamblis	9b14cd2f-5627-4718-98d3-f5f03136ced6
1015	JP	\N	\N	REO	16371faf-cf60-42ef-8944-eba155ab612b
1016		\N	\N	Te Reo No Te Tatarahapa	0480ab38-337f-4d96-91e5-c722dfe83698
1017		\N	\N	reo nagumo	763175c1-b72a-461b-92b5-921b763a5d5c
1018		\N	\N	Joe Reo	7615845f-782e-4189-9209-71a2ed59cd3e
1019		\N	\N	Emily Reo	1045f5b1-bfac-4493-ab9c-aca95fa81754
1020		\N	\N	Reo Grey	64d44a0c-883f-4e60-9a90-3cc73b2869bf
1021	PE	\N	\N	Reo Nerva	68fb94f8-daed-4a9f-9382-cb8179a8f7cb
1022		\N	\N	Mr. Reo	08dad40d-770b-412b-9f12-02e6a27c9bc4
1023		\N	\N	Uncle Reo	628493d1-efdb-45d9-b78b-469287a4fabe
1024		\N	\N	Reo Grand	f1cad46c-26ab-46bb-a3f7-6098cac45eaa
1025		\N	\N	Sugi & Reo	4a51009f-e1c0-4995-ad5e-eab4bc80140f
1026		\N	\N	Miryam Reo Yoshinori	0456d1f6-7fc7-415f-948a-b6fccf9eb3c4
1027		\N	\N	Cat te Reo	090ccbf3-d9b8-4754-9368-6dbcdcff8e1c
1028		\N	\N	Te Reo Takiwa Dunn	e69b2257-b194-4af0-bee1-0a9e3cfb89ee
1029		\N	\N	さくし REO うた 水木一郎	c36923e2-10a7-41b1-a510-27be5f528cab
1030		\N	\N	Cloakroom	d419f6da-298a-40ea-ba0c-1757edd218b7
1031		\N	\N	A Cloakroom Assembly	b5d7b239-edab-4618-a8d8-80550da0cf0c
1032	US	\N	\N	Underoath	674a7e8c-9682-419a-8e05-2358e28b5359
1033	US	\N	\N	Brand New	9311e2bc-bb3f-44cf-90d8-b1fe6912b60b
1034	US	\N	\N	Brand New Sin	6e37e877-f06d-4cd7-84dd-362e7fc432a5
1035	US	\N	\N	Brand New Funk	f4d560f3-8738-499d-b718-c025a0ad7ef6
1036	US	\N	\N	Brand New Idol	c532b30b-449b-4d81-9f89-9b8cdf3388dd
1037		\N	\N	Brand New	edcea99a-630e-4567-a5b8-21b4c4a01ae2
1038	GB	\N	\N	The Brand New Heavies	9b8d6e2c-2b4e-4924-82ae-226b4e701f6b
1039		\N	\N	Brand New Immortals	50c550c3-58de-4d55-a0b8-deb756961e90
1040	CA	\N	\N	Brand New Unit	0b72fc0a-c799-47d6-909f-355cce31c50b
1041		\N	\N	Brand New War	c00df249-f1ea-4420-8bfa-f832ba97abd4
1042		\N	\N	Monsieur Taylor's New Brand	40db4843-cb56-48ff-8eb6-034b00406501
1043	KR	\N	\N	Brand New Day	7dfc65d9-0ccb-4cf6-b7e6-4a3e0ac019f3
1044	JP	\N	\N	Brand new vibe	aded5486-4d52-428a-b914-9dcd0b84c3c8
1045		\N	\N	Brand New Demon	7480f5d0-3d93-490c-b98a-beb0ae81704c
1046	ID	\N	\N	Brand New Storm	7b7d833f-b1a7-405c-b9ac-21c5c810a4af
1047	US	\N	\N	Brand "X"	ab1c4a6b-6016-45f0-849b-cee9e6e1c8d3
1048		\N	\N	Design of a New Brand	e0c4aa68-eb82-47ce-a6e8-a62a4e4750a2
1049		\N	\N	Cousin Tony's Brand New Firebird	15996b0c-c15b-4e1d-b7c2-94df4c13b8dc
1050	US	\N	\N	New Breed	b8f958be-ec55-4097-917f-d7297fc5d8ae
1051	US	\N	\N	New Edition	b4b94b15-1535-48a4-aa1e-d44e55d75bc5
1052	US	\N	\N	New Mongrels	7b88eed5-e9f1-49b1-b552-2ee5f56e5369
1053	US	\N	\N	New Radicals	09a6ae88-7589-4ab2-b10c-dd50ebd526a0
1054	US	\N	\N	New Eden	376a95bd-8d12-4c74-b72e-460e6bbb273d
1055	US	\N	\N	New England	24571d05-bf4b-4f8a-944d-080321ab96af
1056	US	\N	\N	New Regime	95995583-e746-4d93-856d-490997002dc3
1057	US	\N	\N	New Brutalism	163d8ed9-95eb-4f68-ae95-394b14ea8cb4
1058	US	\N	\N	Taking Back Sunday	350bce49-c21b-4137-b50a-0766ded07e4d
1059	US	\N	\N	Everyday Sunday	901502fb-3759-47c2-afac-064cacb8d8a1
1060	US	\N	\N	Sunday Runners	f6c0e36f-2512-40b0-b998-9e401c2f415e
1061	US	\N	\N	Whiskey Sunday	cad33bb5-602f-44ef-8ffd-a089d2cda053
1062	US	\N	\N	Black Sunday	98b127b0-f211-4eff-b741-f567486cac77
1063	US	\N	\N	Sunday Down	4021868b-5bdf-4e6a-9457-5986d7b0df27
1064	US	\N	\N	Staring Back	0cad7a9b-80d5-44c9-bd18-b7a2af2bcb2d
1065	US	\N	\N	Back When	2ac12248-56da-4180-870e-980db2145dd3
1066	US	\N	\N	Low Sunday Ghost Machine	4dab55fc-749c-41ed-96a6-4a2eaded5d1c
1067	US	\N	\N	Never on Sunday	aacbebe9-267f-4cbb-a9a5-a26598f23853
1068	US	\N	\N	King Richard's Sunday Best	9d33f326-2c29-44ae-afee-9483526e01d1
1069	US	\N	\N	Every Third Sunday	6b579551-ac1b-4624-938b-914d6c939840
1070	US	\N	\N	Back Off Cupids	f63b5a21-5d3a-452a-a415-09c00968c7ec
1071	US	\N	\N	Look Back and Laugh	8573cd91-2cd6-40c2-8c24-0515fbf6aead
1072	US	\N	\N	The Back Pockets	2e471b6c-e078-48bc-8d22-33aa3e202f47
1073	US	\N	\N	Eaten Back to Life	073ab94f-30cf-40ef-8a62-1ac3e432d4a0
1074	US	\N	\N	The Back Alley Band	585a443b-5cf7-4d4d-af1c-7727329fcda3
1075	US	\N	\N	Tight Bro's From Way Back When	d9ca0787-56cc-4e08-8431-7668e502bb4a
1076	US	\N	\N	Wayne County and the Back Street Boys	f9ad2f58-17d0-4794-8656-25d8ea579d0c
1077		\N	\N	Sunday	a9eeb466-b655-4112-b641-5e73a6ba5d77
1078		\N	\N	Sunday	12da20cd-9b0f-4c87-8274-6b85cf3b49bf
1079	DE	\N	\N	Sunday	396567bf-eb03-4a8a-bce9-ea54a2154970
1080	FR	\N	\N	Sunday	61ea9af6-45e5-4048-8955-cae38aa9ef19
1081		\N	\N	Taking Sides	b8e62492-4420-407b-b731-c07bdc8dbe96
1082	GB	\N	\N	The Cure	69ee3720-a7cb-4402-b48d-a02c366f2bcf
1083	US	\N	\N	Jaiden The Cure	704268cf-e604-4533-bf53-bf8211eacd1b
1084		\N	\N	The Easy Cure	e85b76d2-5771-4a50-bd1a-2d127373eeb1
1085		\N	\N	The Permanent Cure	7364075f-52bc-4945-ad23-fa70232f8ba1
1086	GB	\N	\N	The Famous Cure	51a3641b-45ae-4523-a789-c619d1869e20
1087	CA	\N	\N	The Ocean Cure	003a049f-0562-476c-aea2-4cac7546e03c
1088	US	\N	\N	Idle Cure	19cbd131-cd3a-44e5-babc-5388b97cf685
1089		\N	\N	no cure	3429fb8f-7466-43d2-a470-d8045ce43597
1090	TW	\N	\N	Beyond Cure	16d97fd7-8a39-49bb-9daa-a1424b991c61
1091		\N	\N	Hazzard's Cure	691c3071-8173-46a8-821d-5cfae7aa506b
1092		\N	\N	How to Cure Dyslexia	9cb1f1e9-2e9c-4816-8960-822645d60e06
1093		\N	\N	Kill or Cure	48663b59-36b7-46cc-9da5-bfb080e1ce0f
1094	AT	\N	\N	Catastrophe & Cure	a9bbe9f3-aa1e-4e0b-9193-a63596f6d333
1095		\N	\N	The Cure of Mercy	eefbbe32-bc25-4814-8203-a1119067234a
1096	US	\N	\N	The Planet The	fd42b7d3-f951-4a1e-afe4-1af59fe6383d
1097	US	\N	\N	The Bunny The Bear	30181656-af83-4cde-a413-964235e27fd0
1098	US	\N	\N	The Sea The Sea	290798ea-9534-4c6f-93b1-c6ad12694c50
1099	US	\N	\N	The Days The Nights	8a4834e6-0078-4d98-8f0a-e4e0f6778c05
1100	US	\N	\N	The Morlocks	3481ac3e-638d-44c1-8382-623e3ec611e9
1101	US	\N	\N	The Freeze	37dee6ec-df31-408d-9608-64b0af97340c
1102	US	\N	\N	The Gits	b916a410-ee27-4f15-92ce-1ce2b60e7697
1103	US	\N	\N	The Badlees	20d3db63-c8ad-4077-a898-5cbf2b8dc367
1104	US	\N	\N	The Lemonheads	58a53082-a629-4ff1-a44d-7492d6f6e8fb
1105	US	\N	\N	The Cars	092b603f-eb4c-4958-b10e-02420de5885b
1106	GB	\N	\N	Jesu	ae69d81f-552d-4013-8dfc-4778d8f38742
1107		\N	\N	Omo Jesu	9f6e45b9-0a54-4521-afe6-97373fbc1808
1108	FI	\N	\N	Jesu Hämäläinen	96ea4d2e-3bbf-4d1e-bb7a-859e3b43054f
1109		\N	\N	Amanxusa Ka Jesu	78c79506-f620-48f0-ae75-0462b3c7838c
1110	GB	\N	\N	The Jesus and Mary Chain	e938a15c-b17e-4e7a-9f68-ff0d536cab44
1111	US	\N	\N	Chain and The Gang	c748666d-f105-47f6-a5e6-04eb80ab4845
1112	US	\N	\N	Teenage Jesus and the Jerks	ecb6ad66-0b12-405c-803c-e5bcc83e77df
1113	US	\N	\N	The Prayer Chain	003bcebc-3add-4819-9556-df164b527fe5
1114	US	\N	\N	The Jesus Lizard	dfebd6c0-dae7-4cc8-a8e9-0dbaa382209f
1115	US	\N	\N	Peter, Paul & Mary	3d621c94-2356-4532-ad52-79e0ef73e20c
1116	US	\N	\N	Billy & Mary Mack	6d667e92-766a-46fe-82fa-240eb7b60427
1117	US	\N	\N	"Jesus Christ." (the indie band)	e5b54303-e99e-4f76-af6c-136d352e027e
1118	US	\N	\N	The Mary Janes	f219b725-8eb3-4c06-a78e-abb6a9e295aa
1119	US	\N	\N	Les Paul & Mary Ford	7ee21fe4-f337-4a74-aebf-a69fc91809c5
1120	US	\N	\N	Mary-Kate & Ashley Olsen	e2a398af-f3e4-4032-86ea-48a277a5318e
1121		\N	\N	The Ball & Chain	1e44aeaa-50a0-4777-b444-e29664c0e8ee
1122	US	\N	\N	Chain Gang	6f9c21b3-f8b9-4e76-a755-4f95770b3963
1123	US	\N	\N	Mary Mary	6413506f-e22b-412c-9f19-239db7df21f2
1124	US	\N	\N	Chain of Strength	81a3c11e-ac20-4bb4-8614-06b157e802d8
1125	US	\N	\N	Gold Chain Military	b01b8a51-0d9d-46fe-9f95-32dcc7c98e00
1126	US	\N	\N	Jesus Wept	453a84af-bbb9-49d2-861c-9c146bbd07b6
1127	US	\N	\N	Jesus Chrust	aa4443de-cd2a-4c0a-9e1c-d8097005fa82
1128	US	\N	\N	Big Jesus	d1dd960c-04bc-4d5c-bf6f-72aed93efce9
1129	US	\N	\N	Young Jesus	09230a9f-94fc-4ce6-b4eb-99aff8a1497f
1130	US	\N	\N	Jesus Gang	4a4a5a26-4ea1-40e1-b495-46de86764e82
1131	US	\N	\N	Plastic Jesus	2c80450b-3867-4874-beb3-f9f4a22474d2
1132	US	\N	\N	Mary Prankster	239efbeb-f6f3-40d9-922c-2609bf9f7a1d
1133	US	\N	\N	Mary Butterworth	ae3b404d-df6d-4f3c-a383-51009fac3ba5
1134	CH	\N	\N	Jesus and the Gurus	6edb8642-a528-43d0-8a6e-005c27ba6b31
1135	US	\N	\N	Zozobra	a6b8ef30-1d47-4042-9b29-3963e4cd7a7a
1136	US	\N	\N	Cave In	f3c95ad4-215b-4519-8660-84c9f467da05
1137	IT	\N	\N	Quiet in The Cave	0a3f4ae2-827a-4682-8b24-efa68281a529
1138	US	\N	\N	Cold Cave	f7f32d93-0801-45cb-9f5a-e68f640649f4
1139	US	\N	\N	Cave Country	c59b9ccf-da3c-476e-a7bf-e41cb09ee848
1140	US	\N	\N	Family Cave	dc5b527b-748e-4a87-af39-3470cf89db8a
1141	US	\N	\N	Sacred Miracle Cave	b0d9873f-1de4-4518-accb-186fd68ed8c2
1142	US	\N	\N	Cave Catt Sammy	a36ec1c7-9138-4fec-bb0f-35739feff3c3
1143	US	\N	\N	The Cave Singers	bc07a2b3-807a-4dda-9c19-003553f18f45
1144	US	\N	\N	The Cave Men	82d68d48-fcc1-4910-bb89-6f61a580d7b8
1145	JP	\N	\N	CAVE	44230e7b-66fc-4a3f-a7f0-187d5643e77d
1146		\N	\N	Cave	61eb3dde-3a23-4a6f-9332-d931980e6067
1147		\N	\N	Cave	63aa2e29-4042-4256-b4ce-0cddcc104356
1148	US	\N	\N	In Pieces	55205fa1-14ce-4f23-830f-f96b5917cbb3
1149	US	\N	\N	In/Humanity	5e5e85c7-2cc3-4894-b344-4249ed16c335
1150	US	\N	\N	In Ruins	a63415ef-c8c0-4664-89a5-ac2e9a5be340
1151	US	\N	\N	In Clover	455e8de0-020c-41af-8b16-14195f167735
1152	US	\N	\N	The In	6afe7939-a031-4f34-99cf-fdcf1fce28f1
1153	US	\N	\N	In Flagranti	6a4736b5-8960-4512-98ec-dbbb87447ede
1154	US	\N	\N	In Sync	92456d37-02dc-40ae-a8e3-90697d4118e0
1155	US	\N	\N	In Ruin	9634a6b8-d556-472b-91b6-96a173da56bc
1156	US	\N	\N	In Ovo	fb37f859-0259-4403-bd5d-66a5054a00e9
1157	US	\N	\N	In Whispers	afd54dba-ff46-41a0-b58e-500c83323371
1158	US	\N	\N	In-Graved	4fe35d18-602e-40a0-921b-7ffecf03bdd7
1159	US	\N	\N	In School	d3ff96f4-8443-443a-b4fd-8635f71db76d
1160	US	\N	\N	In Circles	b60f507e-8788-45d5-92ee-731f34cff490
1161	GB	\N	\N	Led Zeppelin	678d88b2-87b0-403b-b63d-5da7465aecc3
1162	DK	\N	\N	Led Zeppelin Jam	d6e0e274-8e19-44ce-b5b2-52c12f8a674a
1163		\N	\N	Boot-Led-Zeppelin	37463bf1-d77c-4702-b4db-642af32957a9
1164		\N	\N	Led Zeppelin 2	e82374a9-d09b-4303-9bef-b346c59b9c3d
1165	GB	\N	\N	Hats Off to Led Zeppelin	c055204e-a3ba-48a6-bb76-7a4d0f19bd4f
1166	PT	\N	\N	LED ON – The Led Zeppelin Attitude Band	003ecc36-f382-4e06-a9cb-2342ae3947c1
1167	US	\N	\N	Dread Zeppelin	74e2c381-7a79-4c21-8738-20da383e14d2
1168	US	\N	\N	Lez Zeppelin	90ee221e-3c6c-4607-92ca-841f71869e11
1169	US	\N	\N	Jed Zeppelin	0795b730-3bc0-486e-95b5-6b8af964b780
1170	US	\N	\N	Led Er Est	85360045-c4c7-408f-92c4-0b0b8bd73c95
1171		\N	\N	L.E.D.	51d982a2-197e-47f4-85f9-84f8811188a3
1172		\N	\N	Zeppelin Commander	3f86e995-c2c8-4baa-ba69-437c099307d2
1173		\N	\N	Lazer Zeppelin	71f58c25-1a82-407d-8f95-0d9ff79b7d60
1174		\N	\N	Gold Zeppelin	368d7259-e529-40ef-b87d-157679aafcb4
1175	ZA	\N	\N	The LED	e9fa7a35-f2b6-4a82-a131-f6498aa8f81b
1176		\N	\N	Led Byrd	c1f1b242-2d87-4580-90de-698b20624275
1177	NL	\N	\N	Led Astray	84bcf224-7b77-4239-aa17-025fb9d5c303
1178	GB	\N	\N	Led Bib	93bc2566-2218-4f27-994f-e72d1fd1963b
1179	EE	\N	\N	Led R	1484fc6d-6af1-4cb3-b116-ff0c7b90a60c
1180		\N	\N	Led Zepagain	0c526c66-8979-4062-bc21-b9d70711c014
1181		\N	\N	Led Apple	bfbf7439-9c45-4bcf-a9c3-acd45ad9026d
1182	GB	\N	\N	The L.E.D.	1016676a-4e98-4686-9b4e-9d657a1e47b4
1183		\N	\N	Led Zeppelin2	93fc2072-7796-4c60-b937-4e724168e0a1
1184	GB	\N	\N	Whole Lotta Led	77f151b4-7513-4fd6-9f34-64da318b7daf
1185		\N	\N	Led To The Grave	f3871104-0141-4dec-9dda-8c517408a1d6
1186		\N	\N	Pity Sex	8ed03ec1-b8c7-4fe3-a0ac-23415ebbb9f7
1187	US	\N	\N	Pity Sweater	2971729a-b49f-4ba6-8ca5-5405fabb3a6f
1188	US	\N	\N	The Pity Party	e8cc23d4-8064-482a-b4e6-32eab19efae0
1189	US	\N	\N	Cheap Sex	bdba73f8-9b33-4ea9-9a97-9bfc1a8e8d57
1190	US	\N	\N	Raw Sex	f957bf77-3abe-4bb9-a014-6fef00fd243b
1191	US	\N	\N	Sex Mutants	82dcdd6f-4fc0-42a5-8f92-3d710b65ccfa
1192	US	\N	\N	Life Sex & Death	0c207df9-af85-4d90-bffc-959b2be47292
1193	US	\N	\N	Sex Clark Five	9fa198be-e19d-42de-bffd-c081dc9d1cea
1194	US	\N	\N	Aloha Sex Juice	b047fec9-115f-4b77-9b4d-ffe718b0f905
1195	US	\N	\N	Ninja Sex Party	5b2cc0d6-9075-4fc8-a88e-61d1a22199f5
1196	US	\N	\N	Cigarettes After Sex	34557d8f-ee4a-44ab-ae6e-49bb8ac604d0
1197	US	\N	\N	European Sex Machine	b3006c04-4e50-4c82-9d17-cbdaa1fffd2f
1198	US	\N	\N	Sex and the City Men's Choir	45aa6110-32eb-4b0b-a3e2-b5dcbb56d082
1199		\N	\N	Pity Party	40801b0c-1b02-4c41-ac5a-e6c47ad58e5a
1200		\N	\N	Serendhi Pity	c6db9e7f-510f-49da-b1a8-324dbaa3f635
1201		\N	\N	Mr. Pity	60359e9d-1e23-44ad-8e5d-af47f6800822
1202	FI	\N	\N	S.E.X.	413f7bb8-90d6-4a78-80c7-c10d156b541d
1203		\N	\N	The Comedy of Pity	9ad85619-4499-4516-ad39-92973a6fbcb8
1204		\N	\N	Puddles Pity Party	e551c9a5-ad3d-4f80-a049-534a0e20cc0b
1205	US	\N	\N	Sex Worker	1ec42399-ddb8-47eb-9efe-5e615aa4d056
1206	SE	\N	\N	Sex Sex Sex	d0f59f06-8637-4266-90ea-9421bd05901d
1207	GB	\N	\N	Sex Pistols	e5db18cb-4b1f-496d-a308-548b611090d3
1208		\N	\N	Sex Mob	dc533bf0-7084-40c7-adf3-cb3db1b21b9f
1209	NZ	\N	\N	Mi-Sex	e54b24dc-87cb-4497-8763-2ac5c852cc0b
1210	GB	\N	\N	Dub Sex	a3122542-38d1-458e-94db-d21e225644aa
1211	U.K.	2010-10-10	2015-12-03	Adele	00
1212	USA	2010-12-03	\N	Bruno Mars	00000
\.


--
-- Name: recordstore_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('recordstore_artist_id_seq', 1212, true);


--
-- Data for Name: recordstore_genre; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY recordstore_genre (name) FROM stdin;
\.


--
-- Data for Name: recordstore_ownedrecord; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY recordstore_ownedrecord (id, album_id, owner_id, pressing_id) FROM stdin;
20	2479	3	530
23	1688	10	21
24	3053	10	23
25	1988	10	38
27	3771	9	531
28	3488	3	532
29	2931	3	484
30	3387	3	534
31	4134	3	529
32	1636	8	24
33	2475	3	535
34	3372	10	536
35	3601	3	537
36	2335	10	33
37	2135	10	538
38	3717	10	539
39	3053	10	540
40	4145	3	542
41	1709	10	543
45	1709	11	543
46	3372	11	536
47	3053	11	23
48	1688	11	21
49	3213	11	27
50	2135	11	538
51	3053	11	540
53	1688	12	21
54	2410	10	544
55	1688	13	21
56	1708	13	22
57	1709	13	543
58	2410	13	544
59	3372	13	536
60	3601	13	537
61	1988	13	38
62	4283	10	555
65	3601	15	537
66	4134	15	529
67	3387	15	534
68	2931	15	556
\.


--
-- Name: recordstore_ownedrecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('recordstore_ownedrecord_id_seq', 68, true);


--
-- Data for Name: recordstore_pressing; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY recordstore_pressing (id, artwork, version_number, release_format, album_id, label_id) FROM stdin;
21		1		1688	6
22		1		1708	7
23		1		3053	8
24		1		1636	9
25		1		2393	10
26		1		2143	11
27		1		3213	12
28		1		3207	13
29		1		2509	14
30		1		3357	15
31		1		3115	16
32		1		2049	17
33		1		2335	18
34		1		2900	19
35		1		2896	20
36		1		3649	21
37		1		3221	22
38		1		1988	23
39		1		2556	24
40		1		3725	25
41		1		2866	26
42		1		3589	27
43		1		3591	28
44		1		2782	29
45		1		2781	30
46		1		2077	31
47		1		2794	32
48		1		3104	35
49		1		4005	36
50		1		3015	37
51		1		3698	38
52		1		3682	39
53		1		1978	40
54		1		3102	41
55		1		3695	42
56		1		2456	43
57		1		3857	47
58		1		2945	48
59		1		3172	49
60		1		3182	50
61		1		2315	51
62		1		1597	52
63		1		3970	53
64		1		2845	54
65		1		3753	55
66		1		3610	56
67		1		3155	57
68		1		2219	58
69		1		2927	59
70		1		3918	60
71		1		3934	61
72		1		2062	62
73		1		2064	63
74		1		1756	64
75		1		1737	65
76		1		2837	66
77		1		2156	67
78		1		2145	68
79		1		3283	69
80		1		1825	70
81		1		3946	71
82		1		1762	72
83		1		3366	73
84		1		2184	74
85		1		3767	76
86		1		3469	77
87		1		2066	78
88		1		2211	79
89		1		3252	80
90		1		2649	81
91		1		2621	82
92		1		2288	83
93		1		3106	84
94		1		1980	85
95		1		2975	86
96		1		1794	87
97		1		2429	88
98		1		3752	89
99		1		2761	90
100		1		2591	91
101		1		2760	92
102		1		2748	93
103		1		1744	94
104		1		1922	95
105		1		3312	96
106		1		3276	97
107		1		3352	98
108		1		3268	99
109		1		4076	100
110		1		2205	101
111		1		2249	102
112		1		1778	103
113		1		1775	104
114		1		1830	105
115		1		2108	106
116		1		2234	107
117		1		2233	108
118		1		2236	109
119		1		2235	110
120		1		2510	111
121		1		1725	112
122		1		2829	113
123		1		3522	114
124		1		3042	115
125		1		2611	116
126		1		2665	117
127		1		1946	118
128		1		1957	119
129		1		1964	120
130		1		1907	121
131		1		1635	122
132		1		3842	123
133		1		3807	124
134		1		2087	125
135		1		3802	126
136		1		3793	127
137		1		3646	128
138		1		4041	129
139		1		3674	130
140		1		3658	131
141		1		3577	132
142		1		2724	133
143		1		2868	134
144		1		2378	135
145		1		2384	136
146		1		1604	137
147		1		1836	138
148		1		3688	139
149		1		1828	140
150		1		1670	141
151		1		3056	142
152		1		3531	143
153		1		2477	144
154		1		2542	145
155		1		1681	146
156		1		2872	147
157		1		3544	148
158		1		2712	149
159		1		2338	150
160		1		2240	151
161		1		3932	152
162		1		3229	153
163		1		3491	154
164		1		2619	155
165		1		2689	156
166		1		3869	157
167		1		3863	158
168		1		2086	159
169		1		2834	160
170		1		2727	161
171		1		2744	162
172		1		2838	163
173		1		2856	164
174		1		3641	165
175		1		2177	166
176		1		3156	167
177		1		1838	168
178		1		2465	169
179		1		1787	170
180		1		3413	171
181		1		3567	172
182		1		3549	173
183		1		3628	174
184		1		1927	175
185		1		2246	176
186		1		2699	177
187		1		1841	178
188		1		2371	179
189		1		3223	180
190		1		2663	181
191		1		1771	182
192		1		1770	183
193		1		3269	184
194		1		3669	185
195		1		1968	186
196		1		3831	187
197		1		3401	188
198		1		2652	189
199		1		1713	190
200		1		2053	191
201		1		3832	192
202		1		2438	193
203		1		2120	194
204		1		2196	195
205		1		2195	196
206		1		3850	197
207		1		3845	198
208		1		2539	199
209		1		3917	200
210		1		2349	201
211		1		3274	202
212		1		1911	203
213		1		3783	204
214		1		3794	205
215		1		2715	206
216		1		3571	207
217		1		3037	208
218		1		2525	209
219		1		3426	210
220		1		3454	211
221		1		2212	212
222		1		2310	213
223		1		4022	214
224		1		2324	215
225		1		2331	216
226		1		1926	217
227		1		2093	218
228		1		3848	219
229		1		3947	220
230		1		2020	221
231		1		1717	222
232		1		1718	223
233		1		3126	224
234		1		1777	225
235		1		1774	226
236		1		1979	227
237		1		1971	228
238		1		2954	229
239		1		3471	230
240		1		3147	231
241		1		4043	232
242		1		4036	233
243		1		2646	234
244		1		2300	235
245		1		4071	236
246		1		1906	237
247		1		3296	238
248		1		3260	239
249		1		2823	240
250		1		2859	241
251		1		1802	242
252		1		2367	243
253		1		3668	244
254		1		2841	245
255		1		3524	246
256		1		3508	247
257		1		4030	248
258		1		3060	249
259		1		1764	250
260		1		4049	251
261		1		2281	252
262		1		3231	253
263		1		3810	254
264		1		3453	255
265		1		3138	256
266		1		4054	257
267		1		2463	258
268		1		3080	259
269		1		3081	260
270		1		2401	261
271		1		1742	262
272		1		1759	263
273		1		2664	264
274		1		2660	265
275		1		1705	266
276		1		3396	267
277		1		3405	268
278		1		3408	269
279		1		3073	270
280		1		3076	271
281		1		2458	272
282		1		3922	273
283		1		3521	274
284		1		3351	275
285		1		2939	276
286		1		3257	277
287		1		2024	278
288		1		2025	279
289		1		2015	280
290		1		2011	281
291		1		3131	282
292		1		3122	283
293		1		2881	284
294		1		2397	285
295		1		3776	286
296		1		3133	287
297		1		3249	288
298		1		3868	289
299		1		1728	290
300		1		2902	291
301		1		1657	292
302		1		1652	293
303		1		3819	294
304		1		1677	295
305		1		2820	296
306		1		2753	297
307		1		2765	298
308		1		2703	299
309		1		1938	300
310		1		3369	301
311		1		2597	302
312		1		1949	303
313		1		3258	304
314		1		2552	305
315		1		1596	306
316		1		3307	307
317		1		1609	308
318		1		3463	309
319		1		2582	310
320		1		3143	311
321		1		3409	312
322		1		3774	313
323		1		2768	314
324		1		1806	315
325		1		1622	316
326		1		2924	317
327		1		1845	318
328		1		2400	319
329		1		3760	320
330		1		3705	321
331		1		3971	322
332		1		2571	323
333		1		2436	324
334		1		3466	325
335		1		3145	326
336		1		2226	327
337		1		2503	328
338		1		2908	329
339		1		3061	330
340		1		1935	331
341		1		2091	332
342		1		1994	333
343		1		2977	334
344		1		2983	335
345		1		1603	336
346		1		3972	337
347		1		3724	338
348		1		3713	339
349		1		2907	340
350		1		3680	341
351		1		2040	342
352		1		1917	343
353		1		4001	344
354		1		1784	346
355		1		2427	347
356		1		2642	348
357		1		1711	349
358		1		2493	350
359		1		3709	351
360		1		3418	352
361		1		2405	353
362		1		2674	354
363		1		2291	355
364		1		3247	356
365		1		2373	357
366		1		3338	358
367		1		2634	359
368		1		2658	360
369		1		1659	361
370		1		2700	362
371		1		2377	363
372		1		2116	364
373		1		2709	365
374		1		3833	366
375		1		3200	367
376		1		2651	368
377		1		2762	369
378		1		2989	370
379		1		3537	371
380		1		1915	372
381		1		1798	373
382		1		3083	374
383		1		3099	375
384		1		1647	376
385		1		3265	377
386		1		4021	378
387		1		2614	379
388		1		1710	380
389		1		3516	381
390		1		2754	382
391		1		2121	383
392		1		3858	384
393		1		2345	385
394		1		1954	386
395		1		3355	387
396		1		2301	388
397		1		2376	389
398		1		3349	390
399		1		3139	391
400		1		1995	392
401		1		2119	393
402		1		2112	394
403		1		1769	395
404		1		2580	396
405		1		3439	397
406		1		3441	398
407		1		3514	399
408		1		3259	400
409		1		1765	401
410		1		3065	402
411		1		3064	403
412		1		3973	404
413		1		3672	405
414		1		3108	406
415		1		2790	407
416		1		2007	408
417		1		4061	409
418		1		3967	410
419		1		3380	411
420		1		1727	412
421		1		3460	413
422		1		2951	414
423		1		3202	415
424		1		3459	416
425		1		3712	417
426		1		3069	418
427		1		1619	419
428		1		1779	420
429		1		3301	421
430		1		3423	422
431		1		2272	423
432		1		2987	424
433		1		2339	425
434		1		3224	426
435		1		4019	427
436		1		1844	428
437		1		3755	429
438		1		2632	430
439		1		1953	431
440		1		3298	432
441		1		2304	433
442		1		1908	434
443		1		1910	435
444		1		2996	436
445		1		3735	437
446		1		1970	438
447		1		3653	439
448		1		2474	440
449		1		2608	442
450		1		3346	443
451		1		1936	444
452		1		3852	445
453		1		1618	446
454		1		1814	447
455		1		1822	448
456		1		3365	449
457		1		3100	450
458		1		1983	451
459		1		3865	452
460		1		3354	454
461		1		4035	455
462		1		2150	456
463		1		1674	457
464		1		3284	458
465		1		3124	459
466		1		2990	460
467		1		3070	461
468		1		3233	462
469		1		2313	463
470		1		3948	464
471		1		3425	465
472		1		2662	466
473		1		2418	467
474		1		2372	468
475		1		2832	469
476		1		1766	470
477		1		2936	471
478		1		2943	472
479		1		2085	473
480		1		2334	474
481		1		4031	475
482		1		3027	476
483		1		3389	477
484		1		2931	478
485		1		3392	479
486		1		2846	480
487		1		2329	481
488		1		2332	482
489		1		1913	483
490		1		2847	484
491		1		2852	485
492		1		3758	486
493		1		1601	487
494		1		3267	488
495		1		3820	489
496		1		3121	490
497		1		3422	491
498		1		2425	492
499		1		3113	493
500		1		3855	494
501		1		2961	495
502		1		2740	496
503		1		3167	497
504		1		3361	498
505		1		1783	499
506		1		2723	500
507		1		2999	501
508		1		3295	502
509		1		3416	503
510		1		3415	504
511		1		3417	505
512		1		3419	506
513		1		2095	507
514		1		1665	508
515		1		2423	510
516		1		2424	511
517		1		3306	512
518		1		1661	513
519		1		2771	514
520		1		1673	515
521		1		2359	516
522		1		3703	518
523		1		3636	519
524		1		3631	520
525		1		2849	521
526		1	vinyl_12	4075	2
527		1	vinyl_12	4086	\N
528		1	cd	2227	\N
529		1	vinyl_12	4134	1
530		1	vinyl_2_12	2479	2
531		1	vinyl_2_12	3771	7
532		1	vinyl_12	3488	\N
533		1	cd	2932	\N
534		1	tape	3387	\N
535		1	vinyl_2_12	2475	2
536		1	cd	3372	4
537		1	vinyl_2_12	3601	1
538		5	vinyl_12	2135	1
539		1	vinyl_12	3717	7
540		1	vinyl_7	3053	2
541		1	cd	3053	2
542		1	vinyl_12	4145	\N
543		1	cd	1709	1
544		1	cd	2410	1
545		1	cd	1688	4
546		1	vinyl_2_12	1708	\N
547		1	cd	2410	16
548		1	vinyl_2_12	2410	5
549		1	tape	2410	18
550		1	vinyl_12	1988	18
551		1	cd	2409	2
552		1	vinyl_12	2409	1
553		1	cd	2409	\N
554		1	cd	2409	6
555		1	cd	4283	1
556		1	cd	2931	\N
\.


--
-- Name: recordstore_pressing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('recordstore_pressing_id_seq', 556, true);


--
-- Data for Name: recordstore_recordlabel; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY recordstore_recordlabel (id, label_name, label_address, musicbrainz_id) FROM stdin;
1	Run For Cover		
2	Hydra Head		
4	EMI		
5	Epitaph		
6	[no label]	XW	157afde4-4bf5-4039-8ad2-5a15acc85176
7	EMI Music Netherlands	NL	e771b629-4ca1-4d6a-a5dd-26f07eb28c1e
8	Capitol Records	XW	abea2d3e-eabf-4480-ab24-9382dd642c73
9	Book Beat	US	784b3544-317f-40e3-8ffa-775b41f098f8
10	Brigand	US	446f60ce-c935-4e6b-9783-e36e19a99713
11	Big Music	IT	7dea35b7-88e8-4f51-b559-11f19728a7bb
12	Teddy Bear Records	IT	3fec06b5-76a6-4f75-9020-26d8f4a78259
13	Hawk	IT	10151632-3ad1-4eef-8fbb-92be5f5bc6e2
14	Daytrotter	US	2b65d868-31cd-43db-964f-7baad589d340
15	Everest Records	GB	000a96ed-3597-4a2d-a5f5-ab0f6fae82f3
16	KMJ Records	US	6d689c48-d761-4e18-900f-ba9b913e7983
17	RCA Victor	US	b3f4e6a5-ece0-43be-a530-68ad0d49fee8
18	Pendragon Records	US	7aa7a901-f00a-4b1b-b3b9-8c2510caa62e
19	Liberty Records	US	f1452309-a828-4665-a70c-aacdf94d154b
20	Capitol Records Nashville	US	1ff104ed-0536-4dfd-b3f4-2b053ea66f32
21	Vibration	US	dfa4b44f-14ac-4c7f-932a-6e5590f98388
22	Southern Lord	US	3b78c7e5-6292-4f6b-b921-bdcbe681ea27
23	Man’s Ruin Records	US	a6e7f5d9-89b2-45f0-a57b-58b4a4f62c3f
24	Bluurg Records	GB	539e497f-fa8f-4231-85fd-1d25b9c38322
25	Rejuvenation Records	FR	7db0cbe2-c94b-4402-85cc-c39ee18d5b0a
26	Columbia	US	011d1192-6f65-45bd-85c4-0400dd45693e
27	EPIC/SONY	JP	12c53048-be97-403d-805d-bc69c71211e4
28	Epic	US	8f638ddb-131a-4cc3-b3d4-7ebdac201b55
29	Earthology Records	US	9266837c-7609-415c-9ecc-f833382a636c
30	The Rebel Group	US	c708c97a-106b-4add-8983-0505b4a4a3ff
31	EJ Rec.	SI	7c5939c9-a374-4609-a7aa-1a9d85b7628d
32	CBS	US	b8d33bec-92cc-40d9-bd92-4eb089b401a9
35	Quannum Projects	US	650ccc99-f851-4966-9b63-137b9d84926c
36	Warner Bros. Records	US	c595c289-47ce-4fba-b999-b87503e8cb71
37	Sun Records	US	bae0a881-3151-4f15-ba78-bc84cbe57de2
38	MCA Records	US	46a3941a-c810-47a1-974f-955effec4d09
39	Geffen Records	US	0fadc2ce-f7de-4e27-bbe6-612b317e716b
40	Fonte Records	IT	ddac070b-f930-4dab-8f76-9c5ac82bc228
41	Decon	US	336ab568-d2f2-430f-b0fa-07ab018f2eb0
42	Hip-O Records	US	71f53f0e-6286-4684-8bb8-33c027397852
43	Deathwish Inc.	US	2d106e3c-96ef-433e-935f-00b6b505ae0f
47	Rite-Off Records	US	7f969656-6137-49c5-a11d-271c81e44887
48	Cantaloupe Music	US	3044afdb-c895-4f60-8e69-5796b3887c21
49	Sire Records	US	be0fec81-5c18-4494-8bbf-0d81dec006bf
50	Torso	NL	8b0f42e5-1ff7-4b1f-9ed3-9b91e96d9ea5
51	Shanachie	US	0d4fa1f8-757b-400b-86ef-4b6ad316f4d2
52	Suicide Squeeze Records	US	bb2ac3f3-baac-4e22-9b31-386691f06228
53	Brainstorm Artists International	US	cd9ab7d9-0743-481c-b871-70c6472ff28e
54	Final Nail Records	US	8b0e8586-ca97-4768-bebc-39aad92f9716
55	Flicker Records	US	01ef17b0-e2d4-4599-9c7e-7f5371fdf570
56	Solid State Records	US	b277ee1d-3f90-414e-b52b-6a559ca31c68
57	Refill Records	SE	827d1e58-0bcc-4c67-b3d5-8c1c8f487cfe
58	Blacklabworld.com	US	2ff83ccf-7758-45b8-9d3c-6dbf36c22fe3
59	Gotham Records	AU	af9bcf1a-affc-48aa-aea3-ab7a4a8b5a9d
60	Daymare Recordings	JP	c8eb07c6-f9db-4f96-b37b-8638279ffe12
61	Caldo Verde Records	US	917d7b74-49c1-4ddc-8407-5de4fa31739a
62	XL Recordings	GB	14221f01-8939-4ea0-b8f1-b5a21beae80a
63	Beggars Japan	JP	f8032cab-ace3-4276-b00e-72ac4c1fbeda
64	Touch and Go Records	US	9a2cad26-48de-4e7c-97a5-354f52c6e027
65	Epitaph Europe	NL	f15a7708-66b0-4b49-a11a-837d53380d8d
66	Dais Records	US	ba3abcfa-1808-41d6-8b8b-9bb06c0f772e
67	Homestead Records	US	3a113bbe-09e6-4e87-9055-20b488e7d361
68	Blast First	GB	e85341e2-b6ff-4832-9e87-4115fe8eac82
69	Fantasy	US	757acd4a-dade-433d-b754-53468f243220
70	Virgin Records America	US	1644d8bc-b558-447f-82eb-5d6829988156
71	Blanco y Negro	GB	dfe73666-3b14-4f75-bcad-ec311546aeff
72	Lemon Recordings	GB	44837b15-ecc6-4073-ac4a-8155e8975735
73	Decca Records	US	f18f3b31-8263-4de3-966a-fda317492d3d
74	Mercury Records	XW	995428e7-81b6-41dd-bd38-5a7a0ece8ad6
76	Drunken Fish Records	US	e0fe240e-d7e8-4fb3-b5ad-a6a76aae8bdd
77	Strange Attractors Audio House	US	12e7de13-46b5-47ca-8558-279084001f50
78	Thúy Nga	US	6219a33d-98ba-43a8-bde3-28d65742d035
79	United for Opportunity	US	2e83f603-6215-44e0-8ecb-310ad8f773ac
80	Taang! Records	US	7b95d1f1-2588-4a00-b093-e80e40a08548
81	Repertoire	DE	e6681297-3e77-4e96-a219-724d0de9c2e7
82	Vanguard Records	US	40998461-7dfe-4fe1-8ece-8547438c4938
83	Metal Blade Records	US	88aa805c-6cbe-45d2-b43e-156e94090da9
84	Zone Out Music	US	2f5d3d9f-41d9-4126-8088-d831b23633e9
85	CSR Records	ZA	cbd1265c-7eae-4d98-9ce4-017e5d1f7e29
86	Dragon Flight Recordings LLC	US	51c727ef-88a1-4ef3-af22-c2b0521fca2a
87	Panic Records	FR	79864dec-7742-43ad-8725-652bf4d92c6a
88	Ruddeger Records	US	0d7a99fc-6fe0-42c5-a39b-50f2b9b9f635
89	Inpop Records	US	6154ea5a-9d0b-40b0-89ec-30bbf736c24a
90	Beggars Banquet	GB	5917da67-b605-4a08-a5a0-a6874501dda4
91	Atlantic	US	50c384a2-0b44-401b-b893-8181173339c7
92	Elektra Entertainment	US	745f3292-03fe-44b5-babe-bc7eaa46a15d
93	Elektra	US	873f9f75-af68-4872-98e2-431058e4c9a9
94	Estrus Records	US	0e4027d6-7826-4082-b1be-41c59f30e982
95	Digital Music Products, Inc.	US	b5fc474b-81e5-4896-b2ed-b0d136a29878
96	Hi Records	US	19eeed5a-1dbe-40bc-b6e9-5979a3a903d8
97	Riverside	US	fd9ac552-7dae-42e4-98bf-d3a634bded8a
98	E1 Entertainment	US	a1696164-3f07-4c68-9c9a-3df0e0dd8c76
99	Jump Up Records	US	08e8b9a4-fd43-487f-9574-7147c9188fa7
100	Hydra Head Records	US	4d204722-f022-4b6e-8b76-0e06a45ffcdc
101	Gadfly Records	US	61b8e3ea-cc6d-4f60-a87a-7213121c0ac5
102	Tee Pee Records	US	4081ad06-da69-498c-a7bf-c119bc46684c
103	Shadow Kingdom Records	US	6bcbdc51-f2ba-4c50-8625-074d75de9093
104	Hellhound Records	DE	fd27db31-910b-41a0-aa6a-eb24881b6cd7
105	Def Jam Recordings	US	a92d1684-4edb-48aa-b913-30e9da213004
106	Vertigo	GB	1b3b52a5-ef89-4f8b-8d5f-e15a7a58863b
107	Rising Sun Productions	DE	e587648d-3118-4258-aeed-b9fa3c275880
108	СД-Максимум	RU	1fc726a1-c11f-43ac-a404-c91354c41aa2
109	Slumberland Records	US	5bf0ffc7-898d-43f0-a072-b072506fe617
110	Burger Records	US	381edd23-11e7-4572-9f62-c6134a451a21
111	New West Records	US	c1b263e3-f148-4e85-81a3-c57aefc56797
112	Sargent House	US	8e3fe8a2-3c49-4ec1-8a1f-c31c2814611f
113	Code666	IT	8c3032e1-c172-40da-a3a4-185dd4ed8b14
114	Creation Records	GB	73fc1220-d52c-478c-883c-124c1bf38b95
115	Raven Records	AU	a7c45021-ec9e-4aef-a55a-b0b87ef63f6d
116	Universal Records	US	590538e9-b183-4163-ab5a-171fb021ed12
117	Bad Blues Music	US	0ebf203f-ee8b-4775-8129-0e7e601dd6b7
118	Custom Records	US	40e1037e-bb2c-49d2-bc8a-ff214aa820df
119	Crown Records	US	22ba1931-4010-4624-873e-06f91cb976e5
120	Bluesway	US	42364815-3620-4e17-a2a9-90950068d563
121	Verve	US	99a24d71-54c1-4d3f-88cc-00fbcc4fce83
122	Cherry Red Records	GB	0a866b14-bfd8-4e74-b451-ada9fc713329
123	Lost & Found Records	DE	8b55f2f0-e16f-459d-a2a7-10e8a0140304
124	SWOM Records	DE	5a023e83-7464-4eb7-baf7-c95f3ceec504
125	Basement Tapes	US	7d5960a0-ceed-43f5-824f-aec08920d55a
126	PVC Records	US	9e98a551-f529-43a2-8513-94b2208f74a8
127	Fiction Records	GB	f6182855-aa81-453a-a460-58c0fd71635d
128	Now or Never	US	e4bcbd6e-e230-4b17-bfed-52f92e7d7b94
129	Pickwick Records	US	04441a67-2af0-4297-8851-c04be484a373
130	FFRR	GB	d51690ee-c132-41e3-bbde-bb3a4afd835a
131	Delicious Vinyl	US	fa21d4fc-2f5b-48df-9f70-066f0d8cfc3e
132	Castle Records	US	f60ac29a-2df9-4779-a22d-6510cd6f10f9
133	Kirtland Records	US	73db33e8-96f1-488c-9846-6be83735d7ff
134	Coalition Entertainment	CA	69cfe704-2c9a-4692-a7e1-da6e90d26117
135	Devotion Records	GB	ad50ee67-719a-4ce6-87e3-4796c8f73763
136	Invisible Records	US	f8f36bcb-3bb8-4d0e-86da-4a2767f6f74b
137	Havoc Records	US	0e8d4fa9-ff72-4aee-bd9a-927d0e1d4f96
138	BYO Records	US	22d95710-afed-488e-b97b-9f85c74bbe20
139	Streetwise	US	9d0dbb53-e923-413c-b434-f5a126c40d40
140	Rhino	US	c4f2cf49-b57c-4cc1-8061-f54400704ac4
141	Music for Nations	GB	70aac81c-4a9a-460f-a1bd-4d39626e1625
142	Stone Records	FR	cdbe45ca-2b20-49f9-8864-2c78855b58f2
143	Sanctuary Midline	GB	84f6693d-dfe5-470a-852a-3c21ece19439
144	Tortuga Recordings	US	64861056-d15c-48db-b66a-f3f670a5ce8a
145	DreamWorks Records	US	d4751e8e-aa7f-4670-b8a3-4a861bcffa0d
146	Ipecac Recordings	US	1ead555f-78d5-4d8a-aab5-d69f4013a0ac
147	Sony Music	XW	9e6b4d7f-4958-4db7-8504-d89e315836af
148	FXHE Records	US	a20b71c1-b906-40a0-9ced-e6d7641e3fa9
149	Darkside Records	NZ	f47a0ce2-c8c6-4895-842b-4735a7f8127a
150	Document Records	GB	118ef48e-0a1a-4826-aa87-27a5a3d3d465
151	Fantastic Records	US	24a4a3c2-5686-4ec6-aa3c-592ef9349861
152	Sonic Unyon Records	CA	529875d7-b9f8-461a-a939-1ce3d9c6f0c4
153	Safe House	US	49a65a9c-a9e1-4a50-b776-a461453a790b
154	Reprise Records	US	af6d6f49-2b4d-40fe-86d4-241906772b59
155	C3 Records	US	3a4276c1-a8df-43d3-8ea9-9a5aa250660c
156	Bloodshot Records	US	c1a4129a-95dd-4e8c-b42e-7cd9fc3c208b
157	Dojo Records	GB	dc77b425-189e-4d64-91fe-697d4a8c13b9
158	Essential! Records	GB	9351301f-8a99-41f3-96f5-9aac14bf7ac7
159	Release the Bats Records	SE	97035b42-3c46-44de-ab40-7576976d6adc
160	Mannequin	IT	b747f9dc-f60f-4e81-a8e6-cacc5f9d030d
161	Earache Records	GB	1b1e78a5-f05c-465e-b1f6-16a3b8077500
162	Rage of Achilles	GB	be34013b-0721-496e-908e-1291f57f77d6
163	Sacred Bones Records	US	dba6e089-932a-4442-9ebe-fbbceb9476ef
164	Warner Music Canada	CA	7306f7ec-97d1-45d8-bda5-d51c5c901b4c
165	Interscope Records	US	2182a316-c4bd-4605-936a-5e2fac52bdd2
166	Roadrunner Records	US	5899271b-a77a-4081-93a9-0bd05b9b4180
167	Cititrax	US	8e2e80a0-17e1-4662-86fa-883a1abe7bc4
168	Adeline Records	US	38c8c0a5-662e-4b32-b325-144ebb6ca5fc
169	Dart Records	GB	4f2f7322-2cf1-4034-8366-b5b547618c3b
170	The End Records	US	a6ccf7f5-05ac-4456-b38c-6d723d9ad873
171	Obscene Productions	CZ	9d446d95-3b66-4ee8-94bf-dd8fc48a49b2
172	Helter Skelter	GB	c88e5969-2e62-4cfc-9a13-388989c5ca45
173	Epic Records	JP	74d4bedc-649c-4855-89ec-c3ec02e68861
174	Triple Crown Records	US	e620e870-fb51-4531-90c2-23ceb8094241
175	DMP Productions	PT	543a526b-8bb9-47ab-a611-d7e481347279
176	MeteorCity Records	US	7421a39f-dfac-4f51-bfd1-7a55712b30ad
177	Ashmont Records	US	52565cfc-1e48-4d42-8cb7-fcce7a6d0109
178	Slap a Ham Records	US	43fea7a2-8d22-4767-aa3a-589806823e4d
179	Moribund Records	US	22e77afb-59de-4233-988f-a14092b69ba9
180	Headhunter Records	US	938faaec-32df-451f-a5d3-3282b8f39064
181	UNI Records	US	83dedbf0-9cd7-470a-b317-0bb724785b20
182	Enigma Records	US	d6f7f7c6-dbcf-4647-b370-b06a3b645d3d
183	Double A Records	DE	7c1eda5d-8287-47cc-9118-b8974a567b02
184	Westbound Records	US	0f6fb74a-eb83-4a02-b975-3c2e470f6aaa
185	Music Club	GB	9f3cd4d9-dd1c-4961-acfd-00315b033e50
186	Victor	JP	f31e1603-a456-4397-950e-e1a051487f75
187	Go Down Records	IT	028e69e6-1074-4662-9ee0-95a5019efcb5
188	Lazy Records	GB	ccdcc12f-d047-427c-bc8c-4a2045d87a49
189	Sundazed Music	US	ae5752fa-3dcd-470c-9c2f-8dad4fdce6ab
190	Advanced Synergy	MX	f3ed093f-dc08-4743-addf-e493a1ec1c13
191	RCA	US	1ca5ed29-e00b-4ea5-b817-0bcca0e04946
192	Area Pirata	IT	f0883965-5c6d-4e0d-b177-6be956e05ad3
193	Reflection Music Group	US	ac0d6424-ace9-498e-80cf-f44f951abc97
194	Svart Records	FI	af3204cc-0abf-41b6-9766-ae67fc8f9014
195	Wreck Records	US	5f40ad5e-6aa9-4d4e-82f9-6e3ea23deb42
196	P-VINE RECORDS	JP	f349f4ac-7fda-4d25-93a9-f148f820e143
197	Broken Rekids	US	93c2f4cd-a727-4146-b909-efd41e9eae44
198	C/Z Records	US	33dfa786-f682-47fc-897b-8de6aa686673
199	Run for Cover Records	US	9c5c93da-b877-4c50-9ae8-7c6aaaf32e51
200	Avalanche Recordings	GB	f5bfb49a-d6ed-465c-ac5a-8b511a46c1d0
201	Squint Entertainment	US	0c21fd9e-2fd5-413c-98e3-15e7a0c86726
202	Original Jazz Classics	US	4876cd23-c4ab-4ac5-9b49-e8ed14bc22f8
203	ESP-Disk’	US	8f200b94-5233-432a-9d7a-6347577dfc09
204	7 Records	AU	516c4ade-0cea-4d71-afca-9a4e6257cd47
205	Polydor	XW	ce24ab18-1bd6-4293-a486-546d13d6a5e2
206	Trustkill Records	US	33db4c64-50d3-4ffd-8f52-e8e669291f6e
207	Crystal	JM	0cd124fe-91bf-411e-8a30-c5c20eb83c4a
208	Sony Music Custom Marketing Group	US	0092f175-5aad-437b-a7ee-040c850ba804
209	Saddle Creek Records	US	006ea2fb-e616-4743-924a-8bda90fff909
210	Jive	US	79245298-c0ba-4eba-aecc-3dfe8eeb689f
211	Sympathy for the Record Industry	US	5080c956-1501-4a2b-ae59-161edab8a4f0
212	SBK Records	US	9a68bb68-c297-4478-92fa-d30389ec00f5
213	Ignition Records	GB	309d5e6b-8a40-4789-a650-4aeeaeda32cb
214	Flat Earth Records	US	97188c97-267a-49c1-8952-6a576c366ec8
215	Compass Records	US	0f2029a4-9361-447b-967f-0693d70acf0d
216	Hymen Records	DE	5d13b867-d1c6-4227-99ba-872d3ef3aa42
217	MCG Jazz	US	e2541303-10b0-4cee-b0b6-9188add5c629
218	Gnarled Forest	US	44357f81-ab34-4166-b4e8-e7fbed6803a6
219	Strong Survive Records	PL	3b2dd6cd-6854-405b-ad24-9e581c8876a1
220	El Topo	IT	e6da55a1-a5b9-44f5-bcf2-94a5cad8b2fb
221	Drag City	US	b5d3c9c7-5f73-4ebc-b400-e5075c9101a4
222	Wounded Bird Records	US	4db4d8fd-beb2-4f21-8d10-0dd747377f44
223	RoMoCo Records	US	066b5a6c-ea1e-43a0-bf40-0dd90801ef08
224	G-Maab	US	36824731-ce0a-4882-b5e0-95278f9098c7
225	Brainticket	US	b75a884e-e276-45f2-b851-3a6c71ac0b38
226	Gutter Records	DE	0013a7e0-4d19-4c03-a123-e41605c538ad
227	Pretty Pearl Records	US	07d9688c-500b-4f96-8662-f87117c7bfdb
228	PTG Records	US	48ad9d24-0c79-4052-b0d8-8d7f281f69cc
229	Arista	US	c62e3985-6370-446a-bfb8-f1f6122e9c33
230	One Little Indian Records	GB	0253505b-b0f3-4619-8ce0-6a79fe6fbc32
231	Chesky Records	US	e162b4b5-981c-45ef-b475-03fbfc9350f6
232	Primo	CZ	1c24a595-6a11-4d66-9e45-75ba5ccec2f9
233	Proper Pairs	GB	d028f6a8-79c0-4530-a537-de9ff80f718e
234	ABC Records	US	c3e5d5a2-53f2-4eab-9641-23d61e511928
235	Honest Don's Records	US	d528a684-038d-4c7e-8488-1320d95638bc
236	Fear Section	DE	e96bbf1d-d5d8-4f53-ad6f-0b6e69903baf
237	Sue Records	GB	cbba2bcd-b000-47d2-8458-82219552a185
238	Slider Music	US	aef1fe57-bd18-486e-b792-7767e3ac53e4
239	Crypt Records	US	1d85980a-80d8-4588-abdc-4ab06469c800
240	Sony Music Special Products	US	3f82f08e-8027-4995-aa64-8e338ff3805c
241	Sony BMG Music Entertainment	XW	f9ada3ae-3081-44df-8581-ca27a3462b68
242	Rise Records	US	57f4e6ff-51f9-430f-bae6-df7cbefecbf9
243	TuneCore	US	aa234697-d804-4577-ad15-ac08fc89804d
244	Acid Jazz	GB	680fd075-5121-4b2a-911a-762b5afdd99c
245	Totalrust Music	IL	49f09f9d-34f6-4225-a080-86ab8d8b0230
246	Alti Philosophi	DE	20de17bc-e31a-4a11-88b5-99f9aa9593cc
247	Ektro Records	FI	c00ad032-3a92-44d2-b38b-c003338c4590
248	Dynamic Entertainment Ltd	US	7b54376e-f7a8-4f94-ac26-3c4321b8340c
249	Marina Records	DE	dc1536b8-2e25-4e45-a3c5-11b42c75baa7
250	Play It Again Sam	BE	3ccd1270-99d3-4b83-a311-6c60e127c866
251	Lightyear Entertainment	US	202c6e3d-252b-4aee-90c8-ab36693bd89d
252	InsideOut Music	DE	af64e67e-e3e9-4bc3-bb1a-f8c23f285b31
253	Sevared Records	US	20884542-5a9e-4a4a-8008-eec4fcd01379
254	Frontline Records	US	9ab3b540-27d3-4943-9f25-3211eeae0ce5
255	Alive Records	US	4f086bbd-94fc-4957-b5b2-f56e05191aaf
256	Rap-A-Lot Records	US	8d67c905-4145-42a7-86db-d3bf6e1aaf7d
257	Integrity Music	US	3dc5bd29-a35b-45de-a62e-a36258b78d45
258	Good Fight Music	US	5eb1b342-1dd1-4c40-a9de-b9537f0c32af
259	Roc‐A‐Fella Records	US	4cccc72a-0bd0-433a-905e-dad87871397d
260	Ariola	DE	b6d68d43-4939-4d76-b0d7-ef855d9f3e6e
261	Bridge Nine Records	US	b6543dc1-9df2-4ab0-891f-07efc0c5ee91
262	Louder Records	US	36f8fb91-6ece-464a-a472-63a4d4218b7a
263	One Louder	GB	227baea2-7e56-4e4f-9a5e-5f98373bd356
264	Akarma	IT	1ae9450c-1f1d-44eb-b951-2957a885d2b6
265	Karma	US	9d7e4359-a433-4c41-9de1-68d568a020d8
266	Buddah Records	US	bc0dc38a-ad1e-4e81-bf13-ce3a94a8f9ef
267	BMG Direct Marketing, Inc.	US	9a7d39a4-a887-40f3-a645-a9a136d1f13f
268	Relativity Records	US	2bfb17b6-95da-44f8-9cd2-9cc661083901
269	Rough Trade	GB	71247f6b-fd24-4a56-89a2-23512f006f0c
270	Supreme Records	GB	2811723f-f7db-4bff-b4de-e49a9930088d
271	Profile Records	US	e832b688-546b-45e3-83e5-9f8db5dcde1d
272	Equal Vision Records	US	545c16ff-f0b6-4d00-8143-1759b641144a
273	Conspiracy Records	BE	ed83c299-a589-4123-b8e0-948a6cd4911e
274	Castle Music	GB	b151764b-7521-4063-93a8-6817f7ae670f
275	GNP Crescendo	US	bc0a353e-1f62-4f55-a2e1-d4bec38974f4
276	TKO Records	US	985cda35-1d54-4c22-80e7-d346d6c115d5
277	Acetate Records	US	40e3a8c4-b580-45af-8d7b-a3076ee5dd45
278	Luaka Bop	US	92996c02-75c4-4a12-8d90-522483c200c5
279	wea	XE	fe7ee819-e43e-4cb2-8e72-463879e4b3e7
280	Frontiers Records	IT	ef2ebb6e-aba1-41eb-80bb-ed7c585d7a44
281	New Renaissance Records	US	1da61d02-397e-4692-81a4-52c0ac625e24
282	Straight Profit Records	US	6da0b7b6-fda7-4db5-aa41-61b5ccdd7780
283	Payday Records	US	b7b491ec-5f6d-40a2-8e03-10c2471a4093
284	Truth & Soul Records	US	317d48e3-7dc8-40da-a5c2-5cecfd018f04
285	Stillborn Records	US	b357e320-636d-4a8d-96f3-89fe6897544c
286	Kill Rock Stars	US	a16c4ee6-8f6b-4314-9701-465c2e11dffe
287	Asylum Records	US	a8bea33e-67af-424a-a734-898e2dc437ed
288	TVT Records	US	c9117237-b78b-4e47-b452-c9d94fb34916
289	World Service	GB	127ceade-1841-4e9f-934f-8f9937d449fe
290	ANTI‐	US	5b8cf470-f162-4ee3-9b9f-77ff4ee0c601
291	Lucky Seven Records	GB	679013cb-2302-492f-8b10-44d26c4e7e1d
292	Projekt	US	bf75ee31-20c9-461c-9ed1-49334fad5135
293	Tess Records	US	e3815615-31f9-4489-a71b-c95edacc126d
294	Hoanzl	AT	b9a0baab-a4e3-4f46-9a79-8b39d6b15655
295	Barsuk Records	US	a4f904e0-f048-4c13-88ec-f9f31f3e6109
296	Big Break Records	GB	dedfd16a-311b-48c7-8f3b-4979ec098259
297	Trama	BR	53ba7c10-7c16-4cc2-975e-40aa30564ac1
298	Arena Rock	US	a17b6df2-ee3d-44de-b9ac-e6cb9c67951b
299	Spunk!	AU	c7a85cd3-b402-4f01-8019-6751e71f777f
300	Granary Music	US	8222cd7c-ea45-4728-b71c-a1db708b27f7
301	Acoustic Disc	US	e0bac5e4-e1a7-4bab-ae7c-e04381ff937b
302	WEA International	US	32d88056-7c80-4b64-92ed-e298f35aceca
303	ABC-Paramount	US	ef36d3a8-fcc9-4e50-bb80-27bcfd0bbdad
304	Scooch Pooch	US	da2359e5-1203-479c-a9ee-e72c63b620be
305	Red Rossetten Records	DE	20d9d580-0213-4f2a-9d8b-25566f6d0803
306	Magic Bullet Records	US	ea7c44a8-bfc8-4c11-8e6c-12f64f949e3f
307	ECM	DE	1edf842b-d727-4d27-8db6-f31882443f89
308	Superball Music	DE	4e5e22c0-0148-44ad-ad22-c841cbb6543a
309	Double Agent	US	f688c9e2-18a4-490d-9f3e-d76bef7a1b31
310	Fair Trade Services	US	715bbad8-3930-4541-9b14-36d89deb42f4
311	GRP	US	687726bf-86aa-442e-bcad-6f0ca5e6dcc7
312	Virgin France S.A.	FR	7aa3b3f7-04dc-49a5-8d6a-7c87b39ca216
313	Ripped Records	US	33b42563-8c01-440c-89c0-fb472818a139
314	Summershine	AU	c5850c32-a906-4acc-9cba-18e6f5fd60d3
315	Bella Union	GB	2e72153d-8eb0-49a3-8b18-3a054d2c7f33
316	Domino	GB	bfe26801-a86f-49b9-8502-05ae80b02594
317	FatCat Records	GB	21d42a26-b50d-4d1b-8494-ec07922919ce
318	Deep Six Records	US	0d7d0fe8-a989-41a1-8210-e3bcaa38720f
319	Fat Beats Records	US	8319a9cf-0459-4676-893e-be41069bc581
320	Lobster Records	US	f8d08d4b-496a-474b-a89a-06960e943a24
321	Columbia House	CA	0b6073f1-78a5-4078-bc01-22d7b05d0b7a
322	Rode Dog Records	US	b858d5c2-ec69-4b18-b260-ae67f2de736a
323	Lookout! Records	US	1688db48-6fb1-43df-883d-954d39477958
324	Reach Records	US	a9ad9b31-f752-44f9-b369-b5a20b5555cf
325	Thirty Ghosts Records	US	8d12ce50-0baa-4056-839d-d4b6e0646f32
326	Tone Center	US	1604b50e-b3e3-428f-87b8-a078ba2114cf
327	Rawkus Records	US	21a9343c-4a03-4768-8186-569dc03f850c
328	ATO Records	US	b63922e9-da3c-4e41-9eda-ae1b11d33a1a
329	EMI America	US	4881ac0f-1a15-4dd9-8b64-1c39a68edd33
330	Zappa Records	GB	a0b97a02-33ad-45cb-a441-deece4c1865c
331	Dynovoice Records	US	3fd14004-8fb0-4f4c-81a6-15d237616ff2
332	PsychForm Records	US	550c0295-59a9-43c5-9be7-e3f19a31cfb3
333	Instinct Records	US	dee0a0c0-eb07-47e8-aadc-f3b483cfad6c
334	Frontier Records	US	93450244-634f-4144-9f1f-8eec94999261
335	Prima Records	GB	1254c5cc-a7c6-4ee7-b32e-1683cabcee29
336	Sound Pollution	US	6e28dc9c-9574-4d57-b4a3-c4741127efce
337	Chatterbox Records	US	91062a98-2d14-46eb-b63d-627c621165d7
338	Lujo Records	US	9bf9f645-5f9d-42b7-a0db-66d2575f0523
339	Infinity Records	US	36518ece-80e7-46ec-ba5e-1ba76edaf96f
340	Almacantar Records	US	77e98fdf-a3dd-4ee6-a643-a07d8a4ef238
341	Uprok Records	US	d852bc87-b4cb-49a0-92b7-37469e6b8b1e
342	His Master’s Voice	GB	7d0162a9-2636-46f2-b0e8-a9336075eee2
343	Lost Diamonds	AR	a95d6273-ae55-4b59-9a95-17ab5bc67541
344	Gold Castle Records	US	b7d0e01a-be2b-4e1b-ba56-b842fea5d185
346	Cobraside	US	2d430eac-adf6-4373-b7d6-541a1e69c6d8
347	Datawaslost Records	US	00d295c3-316b-4ac7-9482-693ea573cc52
348	Verve Forecast	US	87607d99-1448-4c5f-b794-b67671862aa0
349	Line Records	BR	b9a0ff7e-636e-4c67-9cd3-af99ebb1514c
350	Mystic Empire	RU	a01af292-795d-4c6f-9bbb-70d34927e924
351	Nuclear Blast	DE	3bc70925-d654-4906-b7c0-5135d993495e
352	Alerta Antifascista	DE	d01dedd8-75f8-4082-b8da-088fa58ceaac
353	Level Plane Records	US	fabaf6d1-9c7c-4379-8bc7-5083adccfeb3
354	Gee Street	GB	505f2aad-aa7b-4df5-9e58-fbf3855db6db
355	Metal Blade Records GmbH	DE	10e7035d-cfff-48d9-a784-507067c2f983
356	Moon Ska Europe	XE	0d123294-ec47-42d6-9576-82377d624fe8
357	Concord Records	US	c5f3bc66-5e1e-47bf-8737-46612304aca6
358	Hydra Records	DE	a41bc0b4-b098-4900-92c3-a1a6567b781d
359	Sanctuary Records	US	0b188c03-0909-4d18-b8b6-4eb93ca1471c
360	ATCO Records	US	a9de694a-2e5b-4a1d-8d7a-a7ca620e3f80
361	Rocketstar	US	3b8c3dba-6abe-4c09-96c5-985f755322fa
362	Sub Pop Records	US	38dc88de-7720-4100-9d5b-3cdc41b0c474
363	CrackNation Records	US	785f576c-48be-49c0-9040-a48923322b13
364	Warner Bros.-Seven Arts Records	US	5fffab61-9562-4084-aa34-a34dd80e0a96
365	Ground Control Records	US	c3976601-7c9e-46f7-9540-1db9d5e747b3
366	Fargo Records	FR	30df0008-e668-43c1-a5b1-5abca9d5f0f4
367	Island	XW	dfd92cd3-4888-46d2-b968-328b1feb2642
368	Collectables	US	40193634-1615-4da6-b114-7fd796d86504
369	Teenbeat	US	434783dd-2be4-42db-a320-c53cbee540bb
370	Munich Records	NL	a71957ec-e81c-432f-b587-9648cf3bdb58
371	Music on Vinyl	NL	ba877a7c-18a9-4c68-8296-687fc3402864
372	WZ Tonträger Vertriebs GmbH	DE	66eacb91-4028-43da-89e8-7235a7f90cc6
373	Ice Grill$	JP	67670f32-4409-4973-b1d8-2d5a8c009e9d
374	Northwestside	GB	08115dd8-f877-4926-a579-fe9ce8949b2f
375	Priority Records	US	ce7a2977-c7dd-4695-97e0-5e72572bf0d3
376	n5MD	US	e2293175-8c7b-4372-9a1d-48a086e8f91a
377	Onefoot Records	CA	0f4c4595-10f5-4594-8314-0bb3b07f136f
378	Delmore Recording Society	US	978ed49c-4034-445f-9e12-f58c7632615a
379	Turnstile Records	US	c841da49-4bd7-4aa3-b940-1a6539c81de3
380	N.E.W.S.	BE	fe531366-4b73-4e43-8e67-5b439204e129
381	Holy Roar	GB	6e940f35-961d-4ac3-bc2a-569fc211c2e3
382	Jetset Records	US	859b0293-fd12-429e-af4e-0c253a86583d
383	The Ajna Offensive	US	8bffe0f3-8f22-4090-9e64-6d18d4ab7efc
384	PolyGram	DE	1fc9f71a-8d08-4c02-ab13-fa752750ae44
385	Earwig Music Company, Inc.	US	3d8c4b74-83ea-4655-a449-d219dfc6b768
386	Kent	US	38e5c668-806f-4d99-9fa7-e9f0a1d832cb
387	Hallmark Records	GB	66d6d532-0eb1-4072-92ff-9ea3108d7b75
388	London Records	GB	60a0dd34-2333-4679-9050-38c21f7bc616
389	Underground, Inc.	US	ab5caef9-1ad4-47da-bd9e-1b2c4a51f62b
390	Essex Records	US	a570fabf-aa70-4138-b1e3-521c117ab984
391	NYC Records	US	14e74689-43d1-4599-b386-c36913fee9c4
392	Important Records	US	b8c05dec-eecf-41cf-b792-f8b9cf716282
393	WWA Records	GB	79a5f6e3-f893-4725-b309-47aeabe61535
394	Nippon Phonogram Co., Ltd.	JP	73a7f8e2-3ea0-4045-9748-218637b88f1d
395	CD Presents, Ltd.	US	8514b469-6414-4074-8e80-05abd2ad34ee
396	Easy Rider Records	US	230dfc13-b3f4-4238-bb72-a0f152304116
397	BMG JAPAN	JP	3dd26d3b-7b24-4b84-a957-b43cffb0f1b6
398	GUN Records	DE	7e31c90d-09c3-4fc2-91ed-de60c4a243dc
399	Fifth Colvmn Records	US	c9b7f214-7cec-4bea-9335-2347eb8ac3dd
400	Buzzville Records	BE	fed2b280-5018-4055-afb8-e300420b567d
401	Dossier Records	DE	0d239e86-d55f-414a-976e-e2ec8f6b85e6
402	Barking Pumpkin Records	US	2493c506-942c-4f81-8a6e-fb0d0d3d6e78
403	Food for Thought	GB	f102838c-39ba-484a-b2d3-65225f73456c
404	Reunion Records	US	aabb252f-d26d-45b5-8175-a76e38eccd46
405	London Records 90	GB	2cd8a4b0-f36a-4761-8637-893024985e2f
406	Hollywood Records	US	6bb7c1b2-cb06-4381-9c59-02b1ae4aa96d
407	Sparrow Records	US	a16c5c7f-38ec-4cbf-aa4f-f354fcc88eb2
408	Southern Records	GB	b9a77795-50d2-4f38-9449-16cd044cda61
409	Strike First Records	US	7e3d3ed8-cded-4fb7-a744-50cf68cd46d8
410	Atavistic	XW	01643627-1dba-4c18-b0e9-480337630da0
411	Vocalion	US	0b7d31cb-b99a-4a79-b730-0d9155988006
412	Ace Fu Records	US	ec60a5f5-c860-497f-97fe-bb9c751d5ab4
413	Vegas Records	US	3dac1aff-9f8d-4fbb-9f79-fbe6a6dfcf40
414	Team Love	US	37fc66aa-ae91-42fa-9a7f-0c02b606c136
415	Cocomelos Records	IT	9f4de27c-2c24-4c01-98f5-366174100cb8
416	Risk Records	CZ	24e1a878-519d-467e-ba0e-a1964fba2f3c
417	Pure Steel Records	DE	65149038-d9a1-47f1-b1ce-dcdf107031a1
418	Molten Metal	US	ee84122e-6d86-4f06-aaf8-e0db35e564b3
419	Universal Music Australia	AU	58a95510-5b87-41dd-9cd1-235fc75611f3
420	Rise Above Records	GB	31a780d3-8a28-43a3-ae05-89ec1f202721
421	Criss Cross Jazz	DK	1f8f7bec-1cfe-4b94-b5c8-b7b43d793dd6
422	Soulseller Records	NL	5b8e19bb-b6bd-4812-8f3d-a2678af3cf6e
423	Armed Response Records	US	05c0e3a1-7e40-4775-938b-2c1c177aad4c
424	Festival Records	AU	85df3f99-9072-44d5-a53a-0f1b41f5b57b
425	Yazoo Records	US	0a202dda-fc09-453a-9db2-c4828f9c4de2
426	Seed Records	US	ecbde640-75b3-4df9-865c-960e988ca565
427	Interfusion	AU	63c3f42c-4fbe-4851-bf7a-b9773d1d1a29
428	Vermiform	US	49b98a7d-d472-4dfc-952f-66796215fa23
429	Machine Records	US	8d14f13d-305e-42bb-9fd2-213a38c3df18
430	429 Records	US	815aad3a-3653-4f85-afd0-d0e1536f4f40
431	United Superior Records	US	afde025b-208c-4922-b60e-4ae64717475f
432	Venus Records	JP	d07bf001-af5f-4969-8487-1c92a0e09f40
433	Flying Fish Records	US	ce559fbe-9868-4165-b6da-66a2080d7c8d
434	Koch Records	US	b85f0764-3335-4109-b15e-ac294fe305b9
435	KOCH Music	AT	39b9376f-5855-445f-a21f-e1e1fd79dff3
436	Republic Records	US	e0ecd909-0477-485f-80dc-3c27ea4837ca
437	Warner Bros.	US	17669874-e801-4e05-ac31-dcbf425df55f
438	IMC Music Ltd.	PT	6531d8db-fe5e-4ef6-aa31-734487018195
439	Metro	GB	d380b0eb-470d-4349-aba3-56422bc3adc5
440	Profound Lore Records	CA	d2c8507e-217c-4fea-8a0f-7f43288a8d5b
442	TLK international	HR	b168e7ff-ca40-47aa-8047-424f8aa4bd45
443	World Star Collection	XE	091ae694-56b5-478b-92b0-3e8511550c64
444	Fontana	XW	c69058f5-0089-464b-b574-dd44b0f7f610
445	Adrenaline Records	US	c3b0a6b3-61ae-4834-a2fb-5a25e6debffc
446	Justice Records	US	59cd9c85-cc04-4ccc-8869-d4390a2259a2
447	Lava	US	124c5a9d-73df-4973-bff8-5ebe98cc8168
448	dts Entertainment	US	7932045d-6271-4587-991d-aa631b151f92
449	MCA Nashville	US	05e216a0-c5c6-4788-a105-39efee687715
450	Universal International	JP	4ef2a03c-57ae-4571-b23a-3fb29b9caa11
451	Leaf Hound Records	JP	0a700329-b20d-407e-8fe7-cfe1675f760a
452	Living Legend Records	IT	120aa320-5f71-4fa3-9b8e-8d399f1dfe7c
454	Overseas Records	JP	aec65cf8-5245-4941-9e2f-f42d6ed0cb0a
455	The Good Music Record Company	GB	4fe7206a-f96e-426f-8645-986b914ba1b1
456	Boudisque	NL	965fbaa6-bf72-4b0c-92db-0cc77ebe227f
457	Bieler Bros. Records	US	99c682e6-0631-42ef-85ea-6e666ee0ae5a
458	West Wind Records	DE	babe1b20-02ef-4470-a333-0257600ad045
459	Rap-A-Lot 4 Life	US	d518b44e-d393-4765-a118-2dd2e0340506
460	eMusic Live	US	3eefbccf-4e3b-478f-8aa6-56edc46a881c
461	Sick Wid' It Records	US	f7097d96-1635-479e-b7c0-279380de0589
462	550 Music	US	65f85c42-92a0-489c-a921-d804acba29b1
463	Doghouse Records	US	e6ff9647-da53-4cda-adbb-f244f16a625b
464	Strange Fruit	GB	0c49508e-abff-49ad-b87c-da6270589ae3
465	Visible Noise	GB	780ea211-10d8-4d94-a654-0703ce6ee2b7
466	Eagle Records	DE	2b75b5b7-aa98-4da3-87e6-8a01cb9e5296
467	Machine Shop Recordings	US	e5600a80-fd70-4fb6-8212-1a403bcb59da
468	Concord Jazz	US	8ec4f16d-a43f-4e80-b3b0-935dbdbb598a
469	Cardinal Fuzz	GB	b939983a-389b-4eda-baa6-a33f6a13160c
470	Boutique	GB	f27794ae-aa66-4ab3-8214-25173aaf36d0
471	Bad Dog Records	DE	51cd82cf-e238-43c7-ab3c-be325ba6368f
472	Green Owl Records	US	5e48526b-93b5-4c5b-9831-05ed17f2f5c8
473	Metal Mind Records	PL	d54a56d1-0c75-4d34-992b-2f190f1062d8
474	Off Beat	DE	5f89efa5-5212-4faf-a824-47badf6405f4
475	EMI Music Australia	AU	782f5891-6952-4960-9664-3d08a07dfdb2
476	First Record	TW	384f340d-60e6-48cd-a34e-4c7959ef4721
477	Independent Music	DE	2872a7f6-147f-4e1d-b915-28254d7b5cb9
478	Come&Live!	US	a113bf9e-12f7-4c9f-bfef-dbeda47a79f0
479	Tycoon	DE	139906c4-24d6-4b69-93d8-9560b0ffbdde
480	Midgård Records	SE	28a26493-6f39-4351-a1b1-1016b2eff08c
481	Unit	US	14e7ac62-cd09-4362-8f33-908d5d6542ca
482	Zod	US	30d484ca-f69c-4433-89b0-f4903c41861a
483	Neon	DE	d646f964-9cf7-4c20-9e91-5d5a82cd0909
484	Demonhood Productions	NO	70cd0904-9c36-4a3a-8be0-f079a0623d66
485	Iron Bonehead Productions	DE	567decb7-cfac-433a-8d80-1ce379342b44
486	Dirtnap Records	US	b925bf7c-da1f-4761-bd5f-622f63960ec6
487	Monotreme Records	GB	a2318078-7ca5-4621-8c8c-c0da6f95016a
488	Macmillan Audio	US	1f68183c-2c96-476f-950b-078548e8b7a9
489	Schoenwetter Schallplatten	AT	bbcbad6e-e120-49fc-bee7-581b9bcb3b77
490	SoSouth	US	4d0697d0-b943-4866-892c-5cba4f2ade36
491	Napalm Records	AT	ad2d554f-817a-4278-9813-1b575fe3d159
492	GMM Records	US	0b669d0e-c9c1-45f2-99a5-41cb3b08267d
493	Z-Booga Records	US	14ad9a19-fe10-4852-b658-1f23165dac35
494	Ark 21 Records	US	68206548-34e8-435f-8b58-f5991a8dc708
495	Rowdy Records	US	16997775-eb1f-45ab-848f-228eab9093b1
496	Indie Recordings	NO	04bf0bc9-7823-482e-80d0-b605f79724d9
497	Arsenestre	PL	f4377e61-2e70-4c02-80a6-80553093340f
498	Varèse Vintage Records	US	2c09c705-767d-4c48-b658-b0aac7263ad2
499	Lexicon Devil	AU	4205872d-8e59-4e58-98d8-cc7e82c832be
500	Loog Records	GB	2d0344fd-3ef5-4454-8710-5f4c1544af66
501	Ultimatum Music	US	4e95d4be-cf2e-475a-9901-080419bb3962
502	Prestige	US	11847c89-4b2c-4866-84c3-f72e264c0f66
503	De Rok	US	a5b490ce-6342-43c6-9ea3-d5a2eca7d102
504	To Live a Lie	US	1c249c91-d8b8-474e-ace5-7b1cbf9ca7fe
505	625 Thrashcore	US	f14d4092-d5ab-4eb3-9ee9-f6c3df9968b5
506	Rescued From Life Records	US	c8f25f69-4c0d-4a5b-aeff-4e0c9d4d4b24
507	NEMS	GB	ac380625-521f-4176-b32c-051db62c9a9e
508	Pessimiser	US	9d7fb719-0e6f-468b-93c1-7e986d951bab
510	Step-1 Music	GB	16b8d051-fa2f-46fe-ac6a-402fc63e3913
511	Punkcore Records	US	3d2db18d-53ad-4896-9e81-99fea7cd9a8b
512	Nonesuch	US	c69cac59-f512-4edc-ab2c-d04c22dbce20
513	Fueled by Ramen	US	fc79d7ba-5f25-4e15-be09-03614faf210c
514	The Orchard	XW	426f80c6-4d24-42ac-8af6-cd8d015c64ba
515	Revelation Records	US	48ed026d-bf1a-4c6e-8860-d21cd440b60e
516	Word Entertainment	US	3d62ec4a-2af0-403f-b58c-1df90a1ac7ae
518	Central Station	AU	32f7d92c-348f-444d-941d-b67f3213505f
519	Razor & Tie	US	4b54d76e-7bf0-4988-9a17-1d9e212bb5e4
520	Bigmouth JPN	JP	ab96aaea-d871-4508-b0fe-eff9f08b9a33
521	Necroshrine Records	DE	0e6ea857-8d68-4ab4-815f-ce9966270563
\.


--
-- Name: recordstore_recordlabel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('recordstore_recordlabel_id_seq', 521, true);


--
-- Data for Name: recordstore_recordstoreuser; Type: TABLE DATA; Schema: public; Owner: adminbpcfu4q
--

COPY recordstore_recordstoreuser (id, django_user_id, profile_picture) FROM stdin;
3	1	
4	6	
5	7	
6	8	
7	9	
8	10	
9	11	
10	12	
11	13	
12	14	
13	15	
14	16	
15	17	
\.


--
-- Name: recordstore_user_friends_id_seq; Type: SEQUENCE SET; Schema: public; Owner: adminbpcfu4q
--

SELECT pg_catalog.setval('recordstore_user_friends_id_seq', 15, true);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_45f3b1d93ec8c61c_uniq; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_45f3b1d93ec8c61c_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: recordstore_album_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_album
    ADD CONSTRAINT recordstore_album_pkey PRIMARY KEY (id);


--
-- Name: recordstore_albumreview_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_albumreview
    ADD CONSTRAINT recordstore_albumreview_pkey PRIMARY KEY (id);


--
-- Name: recordstore_artist_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_artist
    ADD CONSTRAINT recordstore_artist_pkey PRIMARY KEY (id);


--
-- Name: recordstore_genre_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_genre
    ADD CONSTRAINT recordstore_genre_pkey PRIMARY KEY (name);


--
-- Name: recordstore_ownedrecord_owner_id_4bfa07596cb9b667_uniq; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_ownedrecord
    ADD CONSTRAINT recordstore_ownedrecord_owner_id_4bfa07596cb9b667_uniq UNIQUE (owner_id, album_id, pressing_id);


--
-- Name: recordstore_ownedrecord_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_ownedrecord
    ADD CONSTRAINT recordstore_ownedrecord_pkey PRIMARY KEY (id);


--
-- Name: recordstore_pressing_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_pressing
    ADD CONSTRAINT recordstore_pressing_pkey PRIMARY KEY (id);


--
-- Name: recordstore_recordlabel_label_name_237f3698b3d9cc1a_uniq; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_recordlabel
    ADD CONSTRAINT recordstore_recordlabel_label_name_237f3698b3d9cc1a_uniq UNIQUE (label_name);


--
-- Name: recordstore_recordlabel_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_recordlabel
    ADD CONSTRAINT recordstore_recordlabel_pkey PRIMARY KEY (id);


--
-- Name: recordstore_recordstoreuser_django_user_id_key; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_recordstoreuser
    ADD CONSTRAINT recordstore_recordstoreuser_django_user_id_key UNIQUE (django_user_id);


--
-- Name: recordstore_user_friends_pkey; Type: CONSTRAINT; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

ALTER TABLE ONLY recordstore_recordstoreuser
    ADD CONSTRAINT recordstore_user_friends_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_253ae2a6331666e8_like; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX auth_group_name_253ae2a6331666e8_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_51b3b110094b8aae_like; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX auth_user_username_51b3b110094b8aae_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_461cfeaa630ca218_like; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX django_session_session_key_461cfeaa630ca218_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: recordstore_album_080a38f3; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_album_080a38f3 ON recordstore_album USING btree (genre_id);


--
-- Name: recordstore_album_ca949605; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_album_ca949605 ON recordstore_album USING btree (artist_id);


--
-- Name: recordstore_albumreview_4f331e2f; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_albumreview_4f331e2f ON recordstore_albumreview USING btree (author_id);


--
-- Name: recordstore_albumreview_95c3b9df; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_albumreview_95c3b9df ON recordstore_albumreview USING btree (album_id);


--
-- Name: recordstore_genre_name_1b0552dc7a7877a1_like; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_genre_name_1b0552dc7a7877a1_like ON recordstore_genre USING btree (name varchar_pattern_ops);


--
-- Name: recordstore_ownedrecord_5e7b1936; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_ownedrecord_5e7b1936 ON recordstore_ownedrecord USING btree (owner_id);


--
-- Name: recordstore_ownedrecord_95c3b9df; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_ownedrecord_95c3b9df ON recordstore_ownedrecord USING btree (album_id);


--
-- Name: recordstore_ownedrecord_df908fba; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_ownedrecord_df908fba ON recordstore_ownedrecord USING btree (pressing_id);


--
-- Name: recordstore_pressing_95c3b9df; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_pressing_95c3b9df ON recordstore_pressing USING btree (album_id);


--
-- Name: recordstore_pressing_abec2aca; Type: INDEX; Schema: public; Owner: adminbpcfu4q; Tablespace: 
--

CREATE INDEX recordstore_pressing_abec2aca ON recordstore_pressing USING btree (label_id);


--
-- Name: auth_content_type_id_508cf46651277a81_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_content_type_id_508cf46651277a81_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djan_content_type_id_697914295151027a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT djan_content_type_id_697914295151027a_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: re_author_id_1270cf2a09b7e438_fk_recordstore_recordstoreuser_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_albumreview
    ADD CONSTRAINT re_author_id_1270cf2a09b7e438_fk_recordstore_recordstoreuser_id FOREIGN KEY (author_id) REFERENCES recordstore_recordstoreuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: records_label_id_58e3b41ed777082d_fk_recordstore_recordlabel_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_pressing
    ADD CONSTRAINT records_label_id_58e3b41ed777082d_fk_recordstore_recordlabel_id FOREIGN KEY (label_id) REFERENCES recordstore_recordlabel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recordst_pressing_id_64dd66d3f323e9b_fk_recordstore_pressing_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_ownedrecord
    ADD CONSTRAINT recordst_pressing_id_64dd66d3f323e9b_fk_recordstore_pressing_id FOREIGN KEY (pressing_id) REFERENCES recordstore_pressing(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recordstore_a_album_id_5cdcd52d3ec4e199_fk_recordstore_album_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_albumreview
    ADD CONSTRAINT recordstore_a_album_id_5cdcd52d3ec4e199_fk_recordstore_album_id FOREIGN KEY (album_id) REFERENCES recordstore_album(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recordstore_artist_id_70de56b07f844ede_fk_recordstore_artist_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_album
    ADD CONSTRAINT recordstore_artist_id_70de56b07f844ede_fk_recordstore_artist_id FOREIGN KEY (artist_id) REFERENCES recordstore_artist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recordstore_genre_id_2ee8b9928872aaf3_fk_recordstore_genre_name; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_album
    ADD CONSTRAINT recordstore_genre_id_2ee8b9928872aaf3_fk_recordstore_genre_name FOREIGN KEY (genre_id) REFERENCES recordstore_genre(name) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recordstore_ow_album_id_2282fb8c7508a1e_fk_recordstore_album_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_ownedrecord
    ADD CONSTRAINT recordstore_ow_album_id_2282fb8c7508a1e_fk_recordstore_album_id FOREIGN KEY (album_id) REFERENCES recordstore_album(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recordstore_p_album_id_58bad3aa58d7868c_fk_recordstore_album_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_pressing
    ADD CONSTRAINT recordstore_p_album_id_58bad3aa58d7868c_fk_recordstore_album_id FOREIGN KEY (album_id) REFERENCES recordstore_album(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recordstore_rec_django_user_id_7eb98ad1776250ed_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: adminbpcfu4q
--

ALTER TABLE ONLY recordstore_recordstoreuser
    ADD CONSTRAINT recordstore_rec_django_user_id_7eb98ad1776250ed_fk_auth_user_id FOREIGN KEY (django_user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

